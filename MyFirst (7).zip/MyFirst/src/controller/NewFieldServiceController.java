package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Map.Entry;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import item.FunctionData;
import item.StructureData;
import item.StructureItem;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import xml.Bean.MapBean;
/**
* Maps the Function inside the package to the Service
* 
* @author VJanarthanan
*/
public class NewFieldServiceController implements Initializable {
	public static HashMap<String, Boolean> selected = new HashMap<String, Boolean>();
	public static List<Element> elementList = new ArrayList<Element>();
	public static HashMap<String, String> nameMap = new HashMap<String, String>();
	public static Boolean newEntry = false;
	@FXML
	private VBox box;
	@FXML
	private Button ok;
	@FXML
	private Button cancel;
	EventHandler<ActionEvent> okButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			elementList.clear();
			Iterator i = null;
			if (selected != null) {
				newEntry = true;
				i = selected.entrySet().iterator();
				DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
				DocumentBuilder build = null;
				try {
					build = dFact.newDocumentBuilder();
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Document doc = build.newDocument();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					if ((Boolean) entry.getValue()) {
						Element element = doc.createElement("item");
						for (HashMap<String, FunctionData> functionMap : InServiceController.functionMapList) {
						}
						element.setAttribute("name", (String) entry.getKey());
						element.setAttribute("type", "Function");
						elementList.add((Element) element);
						System.out.println(entry.getKey());
					}
				}
			}
			Stage stage = (Stage) ok.getScene().getWindow();
			stage.close();
		}
	};
	EventHandler<ActionEvent> cancelButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			newEntry = false;
			System.out.println("AM Cancel");
			Stage stage = (Stage) cancel.getScene().getWindow();
			stage.close();
		}
	};

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println("Inside");
		System.out.println(InServiceController.functionList);
		selected.clear();
		for (String val : InServiceController.functionList) {
			CheckBox cb = new CheckBox(val);
			cb.selectedProperty().addListener(new ChangeListener<Boolean>() {
				public void changed(ObservableValue<? extends Boolean> ov, Boolean old_val, Boolean new_val) {
					System.out.println(cb.isSelected());
					if (cb.isSelected()) {
						selected.put(cb.getText(), true);
					} else
						selected.put(cb.getText(), false);
				}
			});
			cb.setStyle(" " + "-fx-font-size: 20;"
			/// + "-fx-border-insets: -5; "
			// + "-fx-border-radius: 5;"
			// + "-fx-border-style: dotted;"
					+ "-fx-border-width: 2;");
			box.getChildren().add(cb);
		}
		ok.setOnAction(okButtonHandler);
		cancel.setOnAction(cancelButtonHandler);
		/*
		 * table.setFixedCellSize(25);
		 * table.prefHeightProperty().bind(table.fixedCellSizeProperty().
		 * multiply( Bindings.size(table.getItems()).add(1.01)));
		 * table.minHeightProperty().bind(table.prefHeightProperty());
		 * table.maxHeightProperty().bind(table.prefHeightProperty());
		 */
		// getFieldProps();
	}

	public ObservableList<StructureItem> getFieldProps() {
		// System.out.println("Type Name : : :"+serviceName);
		StructureData structureData = MapBean.getStructureMap().get("service");
		ObservableList<StructureItem> itemList = FXCollections.observableArrayList(structureData.getDetailList());
		for (StructureItem item : itemList) {
			System.out.println("Am : : : :" + item.getId());
		}
		return itemList;
	}
}