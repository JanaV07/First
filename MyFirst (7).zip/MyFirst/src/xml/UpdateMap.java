package xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import javax.swing.plaf.synth.SynthSeparatorUI;
import application.MainController;
import controller.NewFieldTypeController;
import item.FunctionData;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;

/**
 *
 * 
 * @author VJanarthanan
 */
public class UpdateMap {
	public static ArrayList<String> typesList = new ArrayList<String>();

	public static void moveButtonTypeFunction(String packageName, String typeName, int index, ItemBase itemBase,
			String op) {
		HashMap<String, List<HashMap<String, TypeData>>> bulktypeMap = MainController.bulkTypeMap;
		List<HashMap<String, TypeData>> typeMapList = bulktypeMap.get(packageName);
		int size = 0;
		if (typeMapList != null) {
			for (int i = 0; i < typeMapList.size(); i++) {
				HashMap<String, TypeData> typeMap = typeMapList.get(i);
				Iterator k = null;
				boolean found = false;
				if (typeMap != null) {
					k = typeMap.entrySet().iterator();
					while (k.hasNext() && k != null) {
						Entry entry = (Entry) k.next();
						String key = entry.getKey().toString();
						if (key.equals(typeName)) {
							TypeData typeData = (TypeData) entry.getValue();
							List<ItemBase> itemList = typeData.getItemList();
							if (op.equals("U")) {
								ItemBase item = itemList.get(index);
								// System.out.println(item.getName());
								itemList.remove(index);
								itemList.add(index - 1, item);
							} else if (op.equals("D")) {
								ItemBase item = itemList.get(index);
								System.out.println("Am in" + item.getName());
								itemList.remove(index);
								itemList.add(index + 1, item);
							} else {
								ItemBase item = itemList.get(index);
								System.out.println("Am in: : " + item.getName());
								size = Integer.parseInt(item.getTotalSize());
								System.out.println(item.getTotalSize());
								int oSize = typeData.getSize();
								System.out.println(typeData.getSize());
								// oSize=oSize-size;
								size = oSize - size;
								typeData.setSize(size);
								itemList.remove(index);
								System.out.println(typeData.getSize());
							}
							typeData.setItemList(itemList);
							typeMap.put(key, typeData);
							found = true;
						}
						if (found) {
							break;
						}
					}
					if (found) {
						typeMapList.remove(i);
						typeMapList.add(i, typeMap);
						break;
					}
				}
			}
			MainController.bulkTypeMap.put(packageName, typeMapList);
		}
		if (!op.equals("D") && !op.equals("U")) {
			typesList.clear();
			triggerTypeMapChange(typeMapList, typeName, packageName, size);
			triggerFunctionMapChange(typeName, packageName, size);
		}
	}

	private static void triggerTypeMapChange(List<HashMap<String, TypeData>> typeMapList, String typeName,
			String packageName, int size) {
		if (!typesList.contains(typeName)) {
			typesList.add(typeName);
			System.out.println("TYPES LIST :triggerTypeMapChange: : " + typesList);
			if (typeMapList != null) {
				for (int i = 0; i < typeMapList.size(); i++) {
					HashMap<String, TypeData> typeMap = typeMapList.get(i);
					// System.out.println("I value: ::"+i);
					Iterator k = null;
					boolean found = false;
					if (typeMap != null) {
						k = typeMap.entrySet().iterator();
						while (k.hasNext() && k != null) {
							Entry entry = (Entry) k.next();
							String key = entry.getKey().toString();
							if (!key.equals(typeName)) {
								TypeData typeData = (TypeData) entry.getValue();
								if (typeData != null) {
									List<ItemBase> itemList = typeData.getItemList();
									// System.out.println("itemList : :
									// :"+typeData.getItemList());
									/// System.out.println("TYPE MAP: :
									// :"+typeMap);
									int size1 = 0;
									if (itemList != null)
										for (int j = 0; j < itemList.size(); j++) {
											ItemBase item = (ItemBase) itemList.get(j);
											if (item.type.equals(typeName)) {
												System.out.println("Contains the type : : :" + key);
												item.setSize(size + "");
												itemList.remove(j);
												itemList.add(j, item);
												size1 = size1 + size;
												found = true;
											} else
												size1 = size1 + Integer.parseInt(item.getTotalSize());
										}
									if (found) {
										System.out.println("SIZE CHANGED : :" + size1);
										triggerTypeMapChange(typeMapList, key, packageName, size1);
										triggerFunctionMapChange(key, packageName, size1);
									}
									typeData.setItemList(itemList);
									typeMap.put(key, typeData);
									typeMapList.remove(i);
									typeMapList.add(i, typeMap);
								}
							}
						}
					}
				}
				MainController.bulkTypeMap.put(packageName, typeMapList);
			}
		}
	}

	public static void moveButtonFunFunction(String packageName, String functionName, int index, ItemBase itemBase,
			String op, String type) {
		HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap = MainController.bulkFunctionMap;
		List<HashMap<String, FunctionData>> functionMapList = bulkFunctionMap.get(packageName);
		System.out.println("function Map" + functionMapList);
		if (functionMapList != null) {
			for (int i = 0; i < functionMapList.size(); i++) {
				HashMap<String, FunctionData> functionMap = functionMapList.get(i);
				System.out.println("Map" + functionMap);
				Iterator k = null;
				boolean found = false;
				if (functionMap != null) {
					k = functionMap.entrySet().iterator();
					while (k.hasNext() && k != null) {
						Entry entry = (Entry) k.next();
						String key = entry.getKey().toString();
						if (key.equals(functionName)) {
							FunctionData functionData = (FunctionData) entry.getValue();
							if (type.equals("I")) {
								List<ItemBase> itemList = functionData.getInputItemList();
								if (op.equals("U")) {
									ItemBase item = itemList.get(index);
									// System.out.println(item.getName());
									itemList.remove(index);
									itemList.add(index - 1, item);
								} else if (op.equals("D")) {
									ItemBase item = itemList.get(index);
									
									System.out.println("AM Deleted "+item);
									itemList.remove(index);
									itemList.add(index + 1, item);
								} else {
									itemList.remove(index);
								}
								functionData.setInputItemList(itemList);
								functionMap.put(key, functionData);
								found = true;
							} else {
								List<ItemBase> itemList = functionData.getOutputItemList();
								if (op.equals("U")) {
									ItemBase item = itemList.get(index);
									// System.out.println(item.getName());
									itemList.remove(index);
									itemList.add(index - 1, item);
								} else if (op.equals("D")) {
									ItemBase item = itemList.get(index);
									System.out.println("Am in" + item.getName());
									itemList.remove(index);
									itemList.add(index + 1, item);
								} else {
									itemList.remove(index);
								}
								functionData.setOutputItemList(itemList);
								functionMap.put(key, functionData);
								found = true;
							}
						}
						if (found) {
							break;
						}
					}
					if (found) {
						functionMapList.remove(i);
						functionMapList.add(i, functionMap);
						break;
					}
				}
			}
		}
		MainController.bulkFunctionMap.put(packageName, functionMapList);
	}

	public static int addButtonTypeFunction(String packageName, String typeName, int index,
			HashMap<String, String> newFieldMap, ItemBase itemBase, boolean edit) {
		int size1 = 0;
		HashMap<String, List<HashMap<String, TypeData>>> bulktypeMap = MainController.bulkTypeMap;
		List<HashMap<String, TypeData>> typeMapList = bulktypeMap.get(packageName);
		// System.out.println("size : : : "+typeMapList.size());
		// System.out.println("Name : : :"+itemBase.getName());
		int size = 0;
		ItemBase toremove = null;
		if (typeMapList != null) {
			for (int i = 0; i < typeMapList.size(); i++) {
				HashMap<String, TypeData> typeMap = typeMapList.get(i);
				// System.out.println("I value: ::"+i);
				TypeData typeData = typeMap.get(typeName);
				if (typeData != null) {
					List<ItemBase> itemList = typeData.getItemList();
					// System.out.println("itemList : :
					// :"+typeData.getItemList());
					/// System.out.println("TYPE MAP: : :"+typeMap);
					if (itemList != null) {
						if (index < 0)
							itemList.add(itemBase);
						else {
							if (edit) {
								toremove = itemList.get(index);
								itemList.remove(index);
								itemList.add(index, itemBase);
							} else
								itemList.add(index + 1, itemBase);
						}
					} else {
						itemList = new ArrayList<ItemBase>();
						itemList.add(itemBase);
					}
					// System.out.println("ITEM ADDED");
					 System.out.println("ITEM ADDED :: "+itemBase);
					typeData.setItemList(itemList);
					System.out.println("NEW SIZE : : : :" + itemBase.getTotalSize());
					size1 = typeData.getSize();
					System.out.println("PRVI SIZE : : :" + size1);
					if (toremove != null) {
						System.out.println("TO REMIVE SIZE::" + toremove.getTotalSize());
						size1 = size1 - Integer.parseInt(toremove.getTotalSize());
					}
					size1 = size1 + Integer.parseInt(itemBase.getTotalSize());
					typeData.setSize(size1);
					// System.out.println("itemList : :
					// :"+typeData.getItemList());
					typeMap.put(typeName, typeData);
				//	System.out.println("ITEM ADDED :"+ i +": "+itemBase);
					//System.out.println("typeMapLIST : : 1111:"+typeMapList);
					typeMapList.remove(i);
					//System.out.println("typeMapLIST : : 2222:"+typeMapList);
					typeMapList.add(i, typeMap);
					//System.out.println("typeMapLIST : :3333 :"+typeMapList);
				}
			}
			MainController.bulkTypeMap.put(packageName, typeMapList);
			typesList.clear();
			System.out.println("sizeeee from map: : :" + size1);
			triggerFunctionMapChange(typeName, packageName, size1);
			triggerTypeMapChange(typeMapList, typeName, packageName, size1);
		}
		return size1;
	}

	private static void triggerFunctionMapChange(String typeName, String packageName, int size1) {
		HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap = MainController.bulkFunctionMap;
		List<HashMap<String, FunctionData>> functionMapList = bulkFunctionMap.get(packageName);
		// System.out.println("function Map" + functionMapList);
		if (functionMapList != null) {
			for (int i = 0; i < functionMapList.size(); i++) {
				HashMap<String, FunctionData> functionMap = functionMapList.get(i);
				Iterator k = null;
				boolean found = false;
				if (functionMap != null) {
					k = functionMap.entrySet().iterator();
					while (k.hasNext() && k != null) {
						Entry entry = (Entry) k.next();
						String key = entry.getKey().toString();
						FunctionData functionData = (FunctionData) entry.getValue();
						List<ItemBase> inputItemList = functionData.getInputItemList();
						if (inputItemList != null)
							for (int j = 0; j < inputItemList.size(); j++) {
								ItemBase item = inputItemList.get(j);
								if (item.getType().equals(typeName)) {
									System.out.println("Map : :UPDATED : " + functionMap);
									item.setSize(size1 + "");
									inputItemList.remove(j);
									inputItemList.add(j, item);
								}
							}
						List<ItemBase> outputItemList = functionData.getOutputItemList();
						if (outputItemList != null)
							for (int j = 0; j < outputItemList.size(); j++) {
								ItemBase item = outputItemList.get(j);
								if (item.getType().equals(typeName)) {
									System.out.println("Map : :UPDATED : " + functionMap);
									item.setSize(size1 + "");
									outputItemList.remove(j);
									outputItemList.add(j, item);
								}
							}
						functionData.setInputItemList(inputItemList);
						functionData.setOutputItemList(outputItemList);
						functionMap.put(key, functionData);
					}
				}
				// System.out.println("TYPE MAP: : :"+typeMap);
				// System.out.println(i);
				functionMapList.remove(i);
				functionMapList.add(i, functionMap);
			}
		}
		MainController.bulkFunctionMap.put(packageName, functionMapList);
	}

	public static void addButtonFunctionFunction(String packageName, String functionName, int index,
			HashMap<String, String> newFieldMap, ItemBase itemBase, String type, boolean edit) {
		System.out.println("Am in fucntion");
		HashMap<String, List<HashMap<String, FunctionData>>> bulktypeMap = MainController.bulkFunctionMap;
		List<HashMap<String, FunctionData>> functionMapList = bulktypeMap.get(packageName);
		System.out.println("functionMapListqwqw : :1 11:"+functionMapList);
		// System.out.println("size : : : "+typeMapList.size());
		// System.out.println("Name : : :"+itemBase.getName());
		if (functionMapList != null) {
			for (int i = 0; i < functionMapList.size(); i++) {
				HashMap<String, FunctionData> functionMap = functionMapList.get(i);
				System.out.println("I value: ::" + i);
				FunctionData functionData = functionMap.get(functionName);
				 System.out.println("function Map : : "+functionMap);
				if (functionData != null) {
					//System.out.println("FUnctin no null");
					if (type.equals("Input")) {
						//System.out.println("inside input");
						List<ItemBase> itemList = functionData.getInputItemList();
						// System.out.println("itemList : :
						// :"+typeData.getItemList());
						/// System.out.println("TYPE MAP: : :"+typeMap);
						if (itemList != null) {
							//System.out.println("no null");
							if (index < 0)
								itemList.add(itemBase);
							else
								if (edit) {
									//toremove = itemList.get(index);
									itemList.remove(index);
									itemList.add(index, itemBase);
								} else
									itemList.add(index + 1, itemBase);
						} else {
							itemList = new ArrayList<ItemBase>();
							itemList.add(itemBase);
						}
						 
						functionData.setInputItemList(itemList);
						
					} else {
						List<ItemBase> itemList = functionData.getOutputItemList();
						// System.out.println("itemList : :
						// :"+typeData.getItemList());
						/// System.out.println("TYPE MAP: : :"+typeMap);
						if (itemList != null) {
							if (index < 0)
								itemList.add(itemBase);
							else
								if (edit) {
									//toremove = itemList.get(index);
									itemList.remove(index);
									itemList.add(index, itemBase);
								} else
									itemList.add(index + 1, itemBase);
							// System.out.println("ITEM ADDED");
						} else {
							itemList = new ArrayList<ItemBase>();
							itemList.add(itemBase);
						}
						functionData.setOutputItemList(itemList);
						
					}
					// System.out.println("itemList : :
					// :"+typeData.getItemList());
					functionMap.put(functionName, functionData);
					// System.out.println("TYPE MAP: : :"+typeMap);
					// System.out.println(i);
					System.out.println("ITEM ADDED :"+ i +": "+itemBase);
					System.out.println("functionMapList : :1 11:"+functionMapList);
					functionMapList.remove(i);  // Some conflict here
					
					System.out.println("functionMapList : : 2222:"+functionMapList);
					functionMapList.add(i, functionMap);
					System.out.println("functionMapList :add : :"+functionMapList);
				}
			}
			
			MainController.bulkFunctionMap.put(packageName, functionMapList);
		}
	}

	public static void addButtonServiceFunction(String packageName, String serviceName, int index, ItemBase itemBase,
			String type) {
		HashMap<String, List<HashMap<String, ServiceData>>> bulktypeMap = MainController.bulkServiceMap;
		List<HashMap<String, ServiceData>> typeMapList = bulktypeMap.get(packageName);
		System.out.println("size : : : " + typeMapList.size());
		// System.out.println("Name : : :"+itemBase.getName());
		if (typeMapList != null) {
			for (int i = 0; i < typeMapList.size(); i++) {
				HashMap<String, ServiceData> typeMap = typeMapList.get(i);
				// System.out.println("I value: ::"+i);
				ServiceData typeData = typeMap.get(serviceName);
				if (typeData != null) {
					if (type.equals("Input")) {
						List<ItemBase> itemList = typeData.getInputItemList();
						// System.out.println("itemList : :
						// :"+typeData.getItemList());
						/// System.out.println("TYPE MAP: : :"+typeMap);
						if (itemList != null) {
							if (index < 0)
								itemList.add(itemBase);
							else
								itemList.add(index + 1, itemBase);
						} else {
							itemList = new ArrayList<ItemBase>();
							itemList.add(itemBase);
						}
						// System.out.println("ITEM ADDED");
						typeData.setInputItemList(itemList);
					} else {
						List<ItemBase> itemList = typeData.getOutputItemList();
						// System.out.println("itemList : :
						// :"+typeData.getItemList());
						/// System.out.println("TYPE MAP: : :"+typeMap);
						if (itemList != null) {
							if (index < 0)
								itemList.add(itemBase);
							else
								itemList.add(index + 1, itemBase);
							// System.out.println("ITEM ADDED");
						} else {
							itemList = new ArrayList<ItemBase>();
							itemList.add(itemBase);
						}
						typeData.setOutputItemList(itemList);
					}
					// System.out.println("itemList : :
					// :"+typeData.getItemList());
					typeMap.put(serviceName, typeData);
					// System.out.println("TYPE MAP: : :"+typeMap);
					// System.out.println(i);
					typeMapList.remove(i);
					typeMapList.add(i, typeMap);
				}
			}
			MainController.bulkServiceMap.put(packageName, typeMapList);
		}
	}

	public static void updateOccursFunction(String packageName, String functionName, String value, String type) {
		HashMap<String, List<HashMap<String, FunctionData>>> bulktypeMap = MainController.bulkFunctionMap;
		List<HashMap<String, FunctionData>> typeMapList = bulktypeMap.get(packageName);
		// System.out.println("size : : : "+typeMapList.size());
		// System.out.println("Name : : :"+itemBase.getName());
		if (typeMapList != null) {
			for (int i = 0; i < typeMapList.size(); i++) {
				HashMap<String, FunctionData> functionMap = typeMapList.get(i);
				// System.out.println("I value: ::"+i);
				FunctionData functionData = functionMap.get(functionName);
				if (functionData != null) {
					if (type.equals("Input")) {
						functionData.setInputOccurs(value);
					} else {
						functionData.setOutputOccurs(value);
					}
					// System.out.println("itemList : :
					// :"+typeData.getItemList());
					functionMap.put(functionName, functionData);
					// System.out.println("TYPE MAP: : :"+typeMap);
					// System.out.println(i);
					typeMapList.remove(i);
					typeMapList.add(i, functionMap);
				}
			}
			MainController.bulkFunctionMap.put(packageName, typeMapList);
		}
	}
	/*
	 * public static int createTypeFunction(String packageName, String typeName,
	 * HashMap<String, String> newFieldMap, boolean edit) { int size1=0;
	 * HashMap<String, List<HashMap<String, TypeData>>> bulktypeMap =
	 * MainController.bulkTypeMap; List<HashMap<String, TypeData>> typeMapList =
	 * bulktypeMap.get(packageName); //
	 * System.out.println("size : : : "+typeMapList.size()); //
	 * System.out.println("Name : : :"+itemBase.getName()); int size = 0; if
	 * (typeMapList != null) { for (int i = 0; i < typeMapList.size(); i++) {
	 * HashMap<String, TypeData> typeMap = typeMapList.get(i);
	 * //System.out.println("I value:  ::"+i); TypeData
	 * typeData=typeMap.get(typeName); if(typeData!=null) { if(!edit){ } } }
	 * MainController.bulkTypeMap.put(packageName, typeMapList);
	 * typesList.clear(); System.out.println("sizeeee from map: : :"+size1);
	 * triggerFunctionMapChange(typeName,packageName,size1);
	 * triggerTypeMapChange(typeMapList,typeName,packageName,size1); } return
	 * size1; }
	 */
}