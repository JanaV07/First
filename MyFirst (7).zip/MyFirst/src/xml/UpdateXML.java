package xml;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import controller.EditFieldController;
import controller.EditFieldFunctionController;
import controller.EditTypeController;
import controller.NewFieldFunctionController;
import controller.NewFieldServiceController;
import controller.NewFieldTypeController;
import controller.NewTypeController;

/**
 *
 * 
 * @author VJanarthanan
 */
public class UpdateXML {
	public static ArrayList<String> typesList = new ArrayList<String>();

	public static void moveButtonTypeFunction(String packageName, String typeName, int index, String op) {
		/*
		 * if(NewTypeController.newTypeMap.containsKey(typeName)) {
		 * typeName=NewTypeController.newTypeMap.get(typeName); }
		 */
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + typeName + ".xml";
		File file = new File(dirName);
		System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		int size = 0;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		System.out.println(root);
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				List<Element> elements = ReadXML.getElements(top);
				for (Element element : elements) {
					// System.out.println(element.getNodeName());
					if (element.getNodeName().equals("items")) {
						List<Element> innerElements = ReadXML.getElements(element);
						for (int k = 0; k < innerElements.size(); k++) {
							if (k != index) {
								Element element1 = innerElements.get(k);
								size = size + Integer.parseInt(element1.getAttribute("size"));
							}
						}
						if (op.equals("D")) {
							// System.out.println("Am down");
							Element above = innerElements.get(index);
							// System.out.println("above :
							// :"+above.getAttribute("name"));
							Element below = innerElements.get(index + 1);
							// System.out.println("below :
							// :"+below.getAttribute("name"));
							// element.removeChild(above);
							element.insertBefore(below, above);
						} else if (op.equals("U")) {
							// System.out.println("Am up");
							Element below = innerElements.get(index);
							Element above = innerElements.get(index - 1);
							System.out.println("below : :" + below.getAttribute("name"));
							System.out.println("above : :" + above.getAttribute("name"));
							element.insertBefore(below, above);
						} else {
							System.out.println("Am Deleting");
							Element elementToDelete = innerElements.get(index);
							element.removeChild(elementToDelete);
						}
					}
				}
			}
		}
		writeXML(doc, dirName);
		if (!op.equals("D") && !op.equals("U")) {
			System.out.println("GOIN TO DELETEEEEEEEEE: : : : " + size);
			typesList.clear();
			triggerChange("C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName, typeName, size);
		}
	}

	private static void writeXML(Document doc, String dirName) {
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(dirName));
			transformer.transform(source, result);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("Done");
	}

	public static void moveButtonFunFunction(String packageName, String functionName, int index, String op,
			String type) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + functionName + ".xml";
		File file = new File(dirName);
		System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		System.out.println(root);
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				List<Element> elements = ReadXML.getElements(top);
				for (Element element : elements) {
					System.out.println(element.getNodeName());
					if (type.equals("I")) {
						if (element.getNodeName().equals("inputs")) {
							List<Element> innerElements = ReadXML.getElements(element);
							if (op.equals("D")) {
								System.out.println("Am down");
								Element above = innerElements.get(index);
								// System.out.println("above :
								// :"+above.getAttribute("name"));
								Element below = innerElements.get(index + 1);
								// System.out.println("below :
								// :"+below.getAttribute("name"));
								// element.removeChild(above);
								element.insertBefore(below, above);
							} else if (op.equals("U")) {
								System.out.println("Am up");
								Element below = innerElements.get(index);
								Element above = innerElements.get(index - 1);
								System.out.println("below : :" + below.getAttribute("name"));
								System.out.println("above : :" + above.getAttribute("name"));
								element.insertBefore(below, above);
							} else {
								System.out.println("Am Deleting");
								Element elementToDelete = innerElements.get(index);
								element.removeChild(elementToDelete);
							}
						}
					} else {
						if (element.getNodeName().equals("outputs")) {
							List<Element> innerElements = ReadXML.getElements(element);
							if (op.equals("D")) {
								System.out.println("Am down");
								Element above = innerElements.get(index);
								// System.out.println("above :
								// :"+above.getAttribute("name"));
								Element below = innerElements.get(index + 1);
								// System.out.println("below :
								// :"+below.getAttribute("name"));
								// element.removeChild(above);
								element.insertBefore(below, above);
							} else if (op.equals("U")) {
								System.out.println("Am up");
								Element below = innerElements.get(index);
								Element above = innerElements.get(index - 1);
								System.out.println("below : :" + below.getAttribute("name"));
								System.out.println("above : :" + above.getAttribute("name"));
								element.insertBefore(below, above);
							} else {
								System.out.println("Am Deleting");
								Element elementToDelete = innerElements.get(index);
								element.removeChild(elementToDelete);
							}
						}
					}
				}
			}
		}
		writeXML(doc, dirName);
	}

	public static void addButtonTypeFunction(String packageName, String typeName, int index, int size, boolean edit) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + typeName + ".xml";
		File file = new File(dirName);
		System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println(root);
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				List<Element> elements = ReadXML.getElements(top);
				for (Element element : elements) {
					// System.out.println(element.getNodeName());
					if (element.getNodeName().equals("items")) {
						List<Element> innerElements = ReadXML.getElements(element);
						// System.out.println(innerElements.size());
						Element element1;
						Node firstDocImportedNode = null;
						if (edit)
							firstDocImportedNode = doc.importNode(EditFieldController.newElement, true);
						else
							firstDocImportedNode = doc.importNode(NewFieldTypeController.newElement, true);
						System.out.println("Index : :: " + index);
						System.out.println("Inner Elements size : : : :" + innerElements.size());
						if (edit) {
							Node toremove = innerElements.get(index);
							System.out.println("REMOVING : :: " + toremove);
							innerElements.get(i).getParentNode().replaceChild(firstDocImportedNode, toremove);
						} else if (index >= 0 && index < innerElements.size() - 1) {
							// System.out.println("index to change : : "+index);
							System.out.println("in index: ::" + innerElements.get(index + 1).getAttribute("name"));
							System.out.println("INSIDE ADDD");
							innerElements.get(i).getParentNode().insertBefore(firstDocImportedNode,
									innerElements.get(index + 1));
						} else {
							// System.out.println("in index out:
							// ::"+innerElements.get(innerElements.size()-1).getAttribute("name"));
							element.appendChild(
									firstDocImportedNode);/*
															 * //insertBefore(
															 * firstDocImportedNode,
															 * innerElements.get
															 * (innerElements.
															 * size()-1));/*
															 * appendChild(
															 * firstDocImportedNode
															 * );
															 */
						}
					}
				}
			}
		}
		typesList.clear();
		triggerChange("C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName, typeName, size);
		writeXML(doc, dirName);
	}

	private static void triggerChange(String loc, String typeName, int size) {
		if (!typesList.contains(typeName)) {
			typesList.add(typeName);
			System.out.println("TYPES LIST :XML: : " + typesList);
			File structFile = new File(loc);
			File[] listOfFiles = structFile.listFiles();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					File file = listOfFiles[i];
					String key = file.getName();
					String dirName = structFile + "\\" + key;
					System.out.println("filename : XML:: " + file);
					String extension = ReadXML.getFileExtension(file);
					if (extension.equals("xml") && !key.equals("Acceptandbookblockservice.xml")
							&& !key.equals(typeName + ".xml")) {
						boolean change = false;
						DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder dBuilder;
						Document doc = null;
						try {
							dBuilder = dbFactory.newDocumentBuilder();
							doc = dBuilder.parse(file);
						} catch (Exception e) {
							e.printStackTrace();
							System.out.println("FILE NAMEEEEEE" + file.getName());
							System.out.println("Error in 28 ReadXML");
						}
						if (doc != null)
							doc.getDocumentElement().normalize();
						String root = doc.getDocumentElement().getNodeName();
						System.out.println(root);
						NodeList nL = doc.getElementsByTagName(root);
						Node node = nL.item(0);
						if (node.getNodeType() == Node.ELEMENT_NODE) {
							Element element = (Element) node;
							List<Element> elements = ReadXML.getElements(element);
							String type = null;
							String name = "";
							for (Element innerElement : elements) {
								List<Element> inElements = ReadXML.getElements(innerElement);
								if (innerElement.getNodeName().equals("header")) {
									for (Element inElement : inElements) {
										if (inElement.getNodeName().equals("name")) {
											name = inElement.getTextContent();
											System.out.println("nameeee :XML: : :" + name);
										}
									}
								}
								if (innerElement.getNodeName().equals("items")) {
									int size1 = 0;
									for (Element inElement : inElements) {
										if (inElement.getAttribute("type").equals(typeName)) {
											inElement.setAttribute("size", size + "");
											size1 = size1 + size;
											System.out.println(size);
											System.out.println("Size changed in XML: " + name);
											change = true;
										} else {
											if (inElement.getAttribute("size").length() > 0)
												size1 = size1 + Integer.parseInt(inElement.getAttribute("size"));
										}
									}
									if (change) {
										System.out.println("____________________________________________");
										System.out.println(size1);
										triggerChange(loc, name, size1);
										System.out.println("____________________________________________");
									}
								} else if (innerElement.getNodeName().equals("inputs")) {
									for (Element inElement : inElements) {
										if (inElement.getAttribute("type").equals(typeName)) {
											inElement.setAttribute("size", size + "");
											change = true;
										}
									}
								} else if (innerElement.getNodeName().equals("outputs")) {
									for (Element inElement : inElements) {
										if (inElement.getAttribute("type").equals(typeName)) {
											inElement.setAttribute("size", size + "");
											change = true;
										}
									}
								}
							}
						}
						if (change) {
							System.out.println("CHANGED : : :" + dirName);
							writeXML(doc, dirName);
						}
					}
				}
			}
		}
	}

	public static void addButtonFunctionFunction(String packageName, String functionName, int index, String type,
			boolean edit) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + functionName + ".xml";
		File file = new File(dirName);
		// System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println(root);
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				List<Element> elements = ReadXML.getElements(top);
				for (Element element : elements) {
					// System.out.println(element.getNodeName());
					if (type.equals("Input")) {
						if (element.getNodeName().equals("inputs")) {
							List<Element> innerElements = ReadXML.getElements(element);
							// System.out.println(innerElements.size());
							Element element1;
							Node firstDocImportedNode = null;
							if (edit)
								firstDocImportedNode = doc.importNode(EditFieldFunctionController.newElement, true);
							else
								firstDocImportedNode = doc.importNode(NewFieldFunctionController.newElement, true);
							// System.out.println("Index : :: "+index);
							if (edit) {
								Node toremove = innerElements.get(index);
								System.out.println("REMOVING : :: " + toremove);
								innerElements.get(i).getParentNode().replaceChild(firstDocImportedNode, toremove);
							} else if (index >= 0 && index < innerElements.size() - 1) {
								// System.out.println("in index:
								// ::"+innerElements.get(index+1).getAttribute("name"));
								innerElements.get(i).getParentNode().insertBefore(firstDocImportedNode,
										innerElements.get(index + 1));
							} else {
								// System.out.println("in index out:
								// ::"+innerElements.get(innerElements.size()-1).getAttribute("name"));
								element.appendChild(
										firstDocImportedNode);/*
																 * //
																 * insertBefore(
																 * firstDocImportedNode,
																 * innerElements
																 * .get(
																 * innerElements
																 * .size()-1)
																 * );/*
																 * appendChild(
																 * firstDocImportedNode
																 * );
																 */
							}
						}
					} else {
						if (element.getNodeName().equals("outputs")) {
							List<Element> innerElements = ReadXML.getElements(element);
							// System.out.println(innerElements.size());
							Element element1;
							Node firstDocImportedNode = null;
							if (edit)
								firstDocImportedNode = doc.importNode(EditFieldController.newElement, true);
							else
								firstDocImportedNode = doc.importNode(NewFieldFunctionController.newElement, true);
							// System.out.println("Index : :: "+index);
							if (edit) {
								Node toremove = innerElements.get(index);
								System.out.println("REMOVING : :: " + toremove);
								innerElements.get(i).getParentNode().replaceChild(firstDocImportedNode, toremove);
							} else if (index >= 0 && index < innerElements.size() - 1) {
								// System.out.println("in index:
								// ::"+innerElements.get(index+1).getAttribute("name"));
								innerElements.get(i).getParentNode().insertBefore(firstDocImportedNode,
										innerElements.get(index + 1));
							} else {
								// System.out.println("in index out:
								// ::"+innerElements.get(innerElements.size()-1).getAttribute("name"));
								element.appendChild(
										firstDocImportedNode);/*
																 * //
																 * insertBefore(
																 * firstDocImportedNode,
																 * innerElements
																 * .get(
																 * innerElements
																 * .size()-1)
																 * );/*
																 * appendChild(
																 * firstDocImportedNode
																 * );
																 */
							}
						}
					}
				}
			}
		}
		writeXML(doc, dirName);
	}

	public static int createXml(String packageName, String xmlName, Element element) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + xmlName + ".xml";
		File file = new File(dirName);
		file.delete();
		System.out.println(file.getAbsolutePath());
		if (!file.exists()) {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = null;
			try {
				docBuilder = docFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// root elements
			Document doc = element.getOwnerDocument();
			doc.appendChild(element);
			writeXML(doc, dirName);
			return 1;
		} else {
			System.out.println("FILE ALREADY EXIST");
			return 0;
		}
	}

	public static int replaceXml(String packageName, String xmlName, Element element, String oldXmlName) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + xmlName + ".xml";
		String oldDir = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + oldXmlName;
		// File old=new File(oldDir);
		// old.delete();
		System.out.println("Deleted  : :" + oldXmlName);
		File file = new File(oldDir);
		System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println(root);
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		boolean cc = true;
		for (int i = 0; i < nL.getLength(); i++) {
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				System.out.println(top.getNodeName());
				System.out.println(top.getFirstChild());
				List<Element> elements = ReadXML.getElements(top);
				for (Element inElement : elements) {
					if (cc) {
						System.out.println(inElement.getNodeName());
						if (inElement.getNodeName().equals("header")) {
							Node node1 = inElement;
							inElement.getParentNode().removeChild(node1);
							System.out.println("OUT");
							System.out.println(top.getFirstChild());
							Node firstDocImportedNode = doc.importNode(element, true);
							top.insertBefore(firstDocImportedNode, top.getFirstChild());
							// inElement.insertBefore(arg0, arg1)
							cc = false;
						}
					}
				}
			}
		}
		file.renameTo(new File(dirName));
		writeXML(doc, dirName);
		return 1;
	}

	public static void addButtonServiceFunction(String packageName, String serviceName, int index, String type) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + serviceName + ".xml";
		File file = new File(dirName);
		System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		System.out.println("++____________________________________________________________________________");
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				List<Element> elements = ReadXML.getElements(top);
				for (Element element : elements) {
					System.out.println(element.getNodeName());
					if (type.equals("Input")) {
						if (element.getNodeName().equals("inputs")) {
							List<Element> innerElements = ReadXML.getElements(element);
							// System.out.println(innerElements.size());
							Element element1;
							List<Element> elementList = NewFieldServiceController.elementList;
							System.out.println(elementList);
							for (Element elementtoadd : elementList) {
								Node firstDocImportedNode = doc.importNode(elementtoadd, true);
								// System.out.println("Index : :: "+index);
								if (index >= 0 && index < innerElements.size()) {
									// System.out.println("in index:
									// ::"+innerElements.get(index+1).getAttribute("name"));
									innerElements.get(i).getParentNode().insertBefore(firstDocImportedNode,
											innerElements.get(index + 1));
								} else {
									// System.out.println("in index out:
									// ::"+innerElements.get(innerElements.size()-1).getAttribute("name"));
									System.out.println("appending");
									element.appendChild(
											firstDocImportedNode);/*
																	 * //
																	 * insertBefore
																	 * (
																	 * firstDocImportedNode
																	 * ,
																	 * innerElements
																	 * .get(
																	 * innerElements
																	 * .size()-1
																	 * ));/*
																	 * appendChild
																	 * (
																	 * firstDocImportedNode
																	 * );
																	 */
								}
							}
						}
					} else {
						if (element.getNodeName().equals("outputs")) {
							List<Element> innerElements = ReadXML.getElements(element);
							// System.out.println(innerElements.size());
							Element element1;
							List<Element> elementList = NewFieldServiceController.elementList;
							System.out.println(elementList);
							for (Element elementtoadd : elementList) {
								Node firstDocImportedNode = doc.importNode(elementtoadd, true);
								// System.out.println("Index : :: "+index);
								if (index >= 0 && index < innerElements.size()) {
									// System.out.println("in index:
									// ::"+innerElements.get(index+1).getAttribute("name"));
									innerElements.get(i).getParentNode().insertBefore(firstDocImportedNode,
											innerElements.get(index + 1));
								} else {
									// System.out.println("in index out:
									// ::"+innerElements.get(innerElements.size()-1).getAttribute("name"));
									element.appendChild(
											firstDocImportedNode);/*
																	 * //
																	 * insertBefore
																	 * (
																	 * firstDocImportedNode
																	 * ,
																	 * innerElements
																	 * .get(
																	 * innerElements
																	 * .size()-1
																	 * ));/*
																	 * appendChild
																	 * (
																	 * firstDocImportedNode
																	 * );
																	 */
								}
							}
						}
					}
				}
			}
		}
		writeXML(doc, dirName);
	}

	public static void updateOccursFunction(String packageName, String functionName, String value, String typeOccurs) {
		String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + functionName + ".xml";
		File file = new File(dirName);
		// System.out.println(file.getAbsolutePath());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("FILE NAMEEEEEE" + file.getName());
			System.out.println("Error in 28 ReadXML");
		}
		if (doc != null)
			doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println(root);
		NodeList nL = doc.getElementsByTagName(root);
		// System.out.println("key : : : "+key);
		for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element top = (Element) node;
				List<Element> elements = ReadXML.getElements(top);
				for (Element element : elements) {
					// System.out.println(element.getNodeName());
					if (typeOccurs.equals("Input")) {
						if (element.getNodeName().equals("inputs")) {
							// System.out.println("BEFORE "+
							// element.getAttribute("minOccurs")+".."+element.getAttribute("maxOccurs"));
							String minOccurs = value.charAt(0) + "";
							String maxOccurs = value.charAt(3) + "";
							minOccurs = minOccurs.replace("N", "*");
							maxOccurs = maxOccurs.replace("N", "*");
							element.setAttribute("minOccurs", minOccurs);
							element.setAttribute("maxOccurs", maxOccurs);
							// System.out.println("AFTER "+
							// element.getAttribute("minOccurs")+".."+element.getAttribute("maxOccurs"));
						}
					} else {
						if (element.getNodeName().equals("outputs")) {
							// System.out.println("BEFORE "+
							// element.getAttribute("minOccurs")+".."+element.getAttribute("maxOccurs"));
							String minOccurs = value.charAt(0) + "";
							String maxOccurs = value.charAt(3) + "";
							minOccurs = minOccurs.replace("N", "*");
							maxOccurs = maxOccurs.replace("N", "*");
							element.setAttribute("minOccurs", minOccurs);
							element.setAttribute("maxOccurs", maxOccurs);
							// System.out.println("AFTER "+
							// element.getAttribute("minOccurs")+".."+element.getAttribute("maxOccurs"));
						}
					}
				}
			}
		}
		writeXML(doc, dirName);
	}
}