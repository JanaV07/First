package xml;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import application.MainApp;
import item.ItemBase;
import xml.Bean.BaseBean;
//import org.jdom.Document;
import xml.Bean.MapBean;

/**
 *
 * 
 * @author VJanarthanan
 */
public class ReadBase extends Object {
	public static int jana = 0;
	public BaseBean basebean = new BaseBean();

	public ReadBase() throws IOException, ParserConfigurationException, SAXException {
		// System.out.println("AM constructor");
		// new ReadXML().readTypes();
		read();
	}

	public void read() throws IOException, ParserConfigurationException, SAXException {
		File baseFile = new File("src\\Resources\\MetaData\\xmllinkApplications.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(baseFile);
		doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println("Root element :" +
		// doc.getDocumentElement().getNodeName());
		NodeList nL = doc.getElementsByTagName("item");
		// System.out.println(nL.getLength());
		List<BaseBean> baseList = new ArrayList<BaseBean>();
		List hashList = new ArrayList();
		System.out.println(nL.getLength());
		for (int i = 0; i < nL.getLength(); i++) {
			BaseBean bean = new BaseBean();
			Node nNode = nL.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				bean.setId(eElement.getAttribute("id"));
				bean.setHeader(eElement.getAttribute("header"));
				bean.setLabel(eElement.getAttribute("label"));
				bean.setHeaderList(WriteBase.constructStructure(bean));
				///// TYPE//////////////
				if (MapBean.getTypeMapList() != null)
					bean.setTypeMapList(MapBean.getTypeMapList());
				else
					bean.setTypeMapList(null);
				//////////////////// FUNCTION//////////////////////
				if (MapBean.getFunctionMapList() != null)
					bean.setFunctionMapList(MapBean.getFunctionMapList());
				else
					bean.setFunctionMapList(null);
				///////////////// SERVICE///////////////////////
				if (MapBean.getServiceMapList() != null)
					bean.setServiceMapList(MapBean.getServiceMapList());
				else
					bean.setServiceMapList(null);
				////////////////////////////////////////////////
				/*
				 * if (MapBean.getFunctionInputlist() != null)
				 * bean.setFunctionInputlist(MapBean.getFunctionInputlist());
				 * else bean.setFunctionInputlist(null); if
				 * (MapBean.getFunctionOutputlist() != null) {
				 * bean.setFunctionOutputlist(MapBean.getFunctionOutputlist());
				 * } else bean.setFunctionOutputlist(null);
				 * if(MapBean.getServiceInputlist()!=null) {
				 * bean.setServiceInputlist(MapBean.getServiceInputlist()); }
				 * else bean.setServiceInputlist(null);
				 * if(MapBean.getServiceOutputlist()!=null) {
				 * bean.setServiceOutputlist(MapBean.getServiceOutputlist()); }
				 * else bean.setServiceOutputlist(null);
				 */
				baseList.add(bean);
				// /System.out.println(eElement.getAttribute("id"));
			}
			// System.out.println(i);
			/// Preloader -values
			MainApp.progress = "Reading : :" + bean.getId() + "::" + i + 1;
			double d = Double
					.parseDouble(new DecimalFormat("##.####").format(((double) i + 1) / (double) nL.getLength()));
			// double d=Double.parseDouble(new
			// DecimalFormat("##.####").format(((double)i+1)/(double)nL.getLength()))*100;
			// System.out.println(d);
			d = d * 100;
			new MainApp().setPercent(((Double) d).intValue());
			///////////////////////////
		}
		basebean.baseList = baseList;
		// System.out.println(baseList.size());
	}

	public BaseBean getBasebean() {
		return basebean;
	}

	public void setBasebean(BaseBean basebean) {
		this.basebean = basebean;
	}
}