package xml.Bean;

import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import org.w3c.dom.Element;

import item.FunctionData;
import item.ServiceData;
import item.StructureData;
import item.TypeData;
/**
*
* 
* @author VJanarthanan
*/
public class MapBean {
//public static HashMap<String,List<ItemBase>> functionInputBean;
//public static HashMap<String,List<ItemBase>> functionOutputBean;
//public static HashMap<String,List<ItemBase>> serviceInputBean;
//public static HashMap<String,List<ItemBase>> serviceOutputBean;
//public static List<HashMap<String, List<ItemBase>>> functionInputlist;
//public static List<HashMap<String, List<ItemBase>>> functionOutputlist;
//public static List<HashMap<String, List<ItemBase>>> serviceInputlist;
//public static List<HashMap<String, List<ItemBase>>> serviceOutputlist;
public static List<HashMap<String, Object>> keyHeaderlist;
//////////////////////////////////////////////////
public static HashMap<String,TypeData> typeMap; // Maintains Type from ReadXML
public static List<HashMap<String,TypeData>> typeMapList;

public static HashMap<String,FunctionData> functionMap;
public static List<HashMap<String,FunctionData>> functionMapList;

public static HashMap<String,ServiceData> serviceMap;
public static List<HashMap<String,ServiceData>> serviceMapList;
////////////////////////////////////////////////

public static HashMap<String,StructureData> structureMap;

public static HashMap<String, HashMap<String, Element>> dataTypeMap;



public static HashMap<String, HashMap<String, Element>> getDataTypeMap() {
	return dataTypeMap;
}
public static void setDataTypeMap(HashMap<String, HashMap<String, Element>> dataTypeMap) {
	MapBean.dataTypeMap = dataTypeMap;
}
public static HashMap<String, StructureData> getStructureMap() {
	return structureMap;
}
public static void setStructureMap(HashMap<String, StructureData> structureMap) {
	MapBean.structureMap = structureMap;
}
public static HashMap<String, FunctionData> getFunctionMap() {
	return functionMap;
}
public static void setFunctionMap(HashMap<String, FunctionData> functionMap) {
	MapBean.functionMap = functionMap;
}
public static List<HashMap<String, FunctionData>> getFunctionMapList() {
	return functionMapList;
}
public static void setFunctionMapList(List<HashMap<String, FunctionData>> functionMapList) {
	MapBean.functionMapList = functionMapList;
}
public static HashMap<String, ServiceData> getServiceMap() {
	return serviceMap;
}
public static void setServiceMap(HashMap<String, ServiceData> serviceMap) {
	MapBean.serviceMap = serviceMap;
}
public static List<HashMap<String, ServiceData>> getServiceMapList() {
	return serviceMapList;
}
public static void setServiceMapList(List<HashMap<String, ServiceData>> serviceMapList) {
	MapBean.serviceMapList = serviceMapList;
}
public static List<HashMap<String, TypeData>> getTypeMapList() {
	return typeMapList;
}
public static void setTypeMapList(List<HashMap<String, TypeData>> typeMapList) {
	MapBean.typeMapList = typeMapList;
}
public static HashMap<String, TypeData> getTypeMap() {
	return typeMap;
}
public static void setTypeMap(HashMap<String, TypeData> typeMap) {
	MapBean.typeMap = typeMap;
}




}
