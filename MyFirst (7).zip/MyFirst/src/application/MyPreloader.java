package application;

import javafx.application.Platform;
import javafx.application.Preloader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.effect.Blend;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.effect.Reflection;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * 
 * @author VJanarthanan
 */
public class MyPreloader extends Preloader {
	private static final double WIDTH = 800;
	private static final double HEIGHT = 400;
	ProgressBar bar;
	private Label header;
	ProgressIndicator indicator;
	private Stage preloaderStage;
	private Scene scene;
	Label title;
	private Label progress;

	public MyPreloader() {
	}

	@Override
	public void init() throws Exception { // 2
		// System.out.println(MyApplication.STEP() + "MyPreloader#init (could be
		// used to initialize preloader view), thread: " +
		// Thread.currentThread().getName());
		// If preloader has complex UI it's initialization can be done in
		// MyPreloader#init
		Platform.runLater(() -> {
			header = new Label("MESSAGE EXPLORER");
			Image image = new Image(getClass().getResourceAsStream("/Resources/2.png"), 25, 25, false, false);
			/*
			 * header.setGraphic(new ImageView(image));
			 * header.setTextFill(Color.RED); header.setFont(new Font("Cambria",
			 * 32)); header.setId("fancytext");
			 */
			Blend blend = new Blend();
			blend.setMode(BlendMode.MULTIPLY);
			header.setFont(new Font("Cambria", 70));
			DropShadow ds = new DropShadow();
			ds.setColor(Color.rgb(254, 235, 66, 0.3));
			ds.setOffsetX(5);
			ds.setOffsetY(5);
			ds.setRadius(5);
			ds.setSpread(0.2);
			blend.setBottomInput(ds);
			DropShadow ds1 = new DropShadow();
			ds1.setColor(Color.web("#f13a00"));
			ds1.setRadius(20);
			ds1.setSpread(0.2);
			Blend blend2 = new Blend();
			blend2.setMode(BlendMode.MULTIPLY);
			InnerShadow is = new InnerShadow();
			is.setColor(Color.web("#feeb42"));
			is.setRadius(9);
			is.setChoke(0.8);
			blend2.setBottomInput(is);
			InnerShadow is1 = new InnerShadow();
			is1.setColor(Color.web("#f13a00"));
			is1.setRadius(5);
			is1.setChoke(0.4);
			blend2.setTopInput(is1);
			Blend blend1 = new Blend();
			blend1.setMode(BlendMode.MULTIPLY);
			blend1.setBottomInput(ds1);
			blend1.setTopInput(blend2);
			blend.setTopInput(blend1);
			header.setEffect(blend);

			// header.setStyle(value);
			title = new Label("Showing preloader stage!\nLoading, please wait...");
			title.setTextAlignment(TextAlignment.CENTER);
			title.setTextFill(Color.WHITE);
			title.setFont(new Font("Cambria", 32));
			progress = new Label("0%");

			progress.setTextFill(Color.WHITE);
			bar = new ProgressBar();
			bar.setProgress(0);
			Reflection r = new Reflection();
			/*
			 * DropShadow glowEffect= new DropShadow();
			 * glowEffect.setOffsetY(0f); glowEffect.setOffsetX(0f);
			 * glowEffect.setColor(Color.BLACK); glowEffect.setWidth(50);
			 * glowEffect.setHeight(50); bar.setEffect(glowEffect);
			 */
			r.setFraction(0.7f);
			bar.setEffect(r);
			bar.setPrefSize(303.0, 30.0);
			// indicator=new ProgressIndicator();
			// indicator.setStyle(" -fx-progress-color:
			// blue;-fx-background-insets: 100;-fx-background-radius: 100;");
			// indicator.setPrefHeight(33);
			// AnchorPane root=new AnchorPane(title,progress,bar,indicator);
			VBox root = new VBox(header, title, progress, bar);
			root.setMinHeight(500);
			root.setSpacing(50);
			// root.setStyle("-fx-background-color: cornsilk; -fx-padding:
			// 10;");
			root.setAlignment(Pos.CENTER);
			root.getStylesheets().add(getClass().getResource("/style/progressbar.css").toExternalForm());

			BackgroundImage myBI = new BackgroundImage(new Image("/Resources/123.jpg", 800, 400, false, true),
					BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
					BackgroundSize.DEFAULT);
			root.setBackground(new Background(myBI));
			scene = new Scene(root, WIDTH, HEIGHT);
			scene.getStylesheets().addAll(this.getClass().getResource("/style/progressbar.css").toExternalForm());

		});
	}

	@Override
	public void start(Stage primaryStage) throws Exception { // 3
		// System.out.println(MyApplication.STEP() + "MyPreloader#start (showing
		// preloader stage), thread: " + Thread.currentThread().getName());
		this.preloaderStage = primaryStage;
		// Set preloader scene and show stage.
		preloaderStage.setScene(scene);
		preloaderStage.initStyle(StageStyle.UNDECORATED);
		preloaderStage.show();
	}

	@Override
	public void handleApplicationNotification(PreloaderNotification info) {
		// Handle application notification in this point (see
		// MyApplication#init).
		if (info instanceof ProgressNotification) {
			bar.setProgress(((ProgressNotification) info).getProgress() / 100);
			progress.setText(((ProgressNotification) info).getProgress() + " : :: % : :" + MainApp.progress);
			title.setText(MainApp.progress);
		}
	}

	@Override
	public void handleStateChangeNotification(StateChangeNotification info) {
		// Handle state change notifications.
		StateChangeNotification.Type type = info.getType(); // 4
		switch (type) {
		case BEFORE_LOAD:
			// Called after MyPreloader#start is called.
			// System.out.println(MyApplication.STEP() + "BEFORE_LOAD");
			break;
		case BEFORE_INIT:
			// Called before MyApplication#init is called.
			// System.out.println(MyApplication.STEP() + "BEFORE_INIT");
			break;
		case BEFORE_START:
			// Called after MyApplication#init and before MyApplication#start is
			// called.
			// System.out.println(MyApplication.STEP() + "BEFORE_START");
			preloaderStage.hide();
			break;
		}
	}
}