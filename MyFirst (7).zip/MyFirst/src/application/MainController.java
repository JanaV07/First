package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Observer;
import java.util.ResourceBundle;
import javax.xml.parsers.ParserConfigurationException;
import org.jdom.JDOMException;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import controller.EditFunctionController;
import controller.EditServiceController;
import controller.EditTypeController;
import controller.FunctionController;
import controller.InFunctionController;
import controller.InServiceController;
import controller.InTypeController;
import controller.NewFieldTypeController;
import controller.NewFunctionController;
import controller.NewServiceController;
import controller.NewTypeController;
import controller.ServiceController;
import controller.TypeController;
import item.FunctionData;
import item.Header;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import xml.ReadBase;
import xml.UpdateMap;
import xml.UpdateXML;
import xml.Bean.BaseBean;

/**
 * Controller for the Base.fxml contains the static Maps containing all the data
 * bulkTypeMap- containing <Name of the package, Types of that package>
 * bulkFunctionMap - containing <Name of the package, Function of that package>
 * bulkServiceMap - containing <Name of the package, Service of that package>
 * 
 * @author VJanarthanan
 */
public class MainController implements Initializable {
	public static String packageName = ""; // package name where new xml get
											// creates
	public static String xmlName = ""; // new xml File name
	public static Element element; // new element to get create
	public static String application;
	@FXML
	public TreeView<String> treeview;
	public static TreeView<String> sampleTree;
	public static HashMap<String, List<HashMap<String, TypeData>>> bulkTypeMap = new HashMap<String, List<HashMap<String, TypeData>>>();
	public static HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap = new HashMap<String, List<HashMap<String, FunctionData>>>();
	public static HashMap<String, List<HashMap<String, ServiceData>>> bulkServiceMap = new HashMap<String, List<HashMap<String, ServiceData>>>();
	public static List<String> packageList = new ArrayList<String>();
	static Image foldericon = new Image("/Resources/folder_icon.png", 15, 15, false, false);
	static Image blockicon = new Image("/Resources/block.png", 10, 10, false, false);
	@FXML
	private AnchorPane dataPane;
	@FXML
	public VBox box;
	@FXML
	public MenuItem newType;
	@FXML
	public MenuItem newFunction;
	@FXML
	public MenuItem newService;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// System.out.println(sampleTree.getRoot().getValue());
		// treeview=sampleTree;
		/*
		 * BackgroundImage myBI= new BackgroundImage(new
		 * Image("/Resources/34.jpg",800,800,false,true),
		 * BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
		 * BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
		 * dataPane.setBackground(new Background(myBI));
		 * dataPane.setPrefWidth(1000);
		 */
		treeview.setRoot(sampleTree.getRoot());
		treeview.setShowRoot(false);
		treeview.setEditable(true);
		treeview.setCellFactory(new Callback<TreeView<String>, TreeCell<String>>() {
			@Override
			public TreeCell<String> call(TreeView<String> p) {
				return new TextFieldTreeCellImpl(treeview.getSelectionModel().getSelectedItem());
				// return null;
			}
		});
		// Method will create the Tree structure from reading existing schemas
		// from XML
		// constructStructure();
		try {
			newType.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					//////////////// SUB WINDOW////////////////////
					Parent parent = null;
					try {
						parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewType.fxml"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Stage stage = new Stage();
					// stage.initStyle(StageStyle.TRANSPARENT);
					stage.setTitle("New Type");
					stage.setScene(new Scene(parent));
					stage.initModality(Modality.WINDOW_MODAL);
					stage.initOwner(MainApp.getStage());
					stage.setResizable(false);
					stage.showAndWait();
					//////////////// SUB WINDOW////////////////////
					System.out.println("add  TYPE Operation");
					addNewFunction();
				}
			});
			newFunction.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					//////////////// SUB WINDOW////////////////////
					Parent parent = null;
					try {
						parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewFunction.fxml"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Stage stage = new Stage();
					// stage.initStyle(StageStyle.TRANSPARENT);
					stage.setTitle("New Function");
					stage.setScene(new Scene(parent));
					stage.initModality(Modality.WINDOW_MODAL);
					stage.initOwner(MainApp.getStage());
					stage.show();
					//////////////// SUB WINDOW////////////////////
					System.out.println("Am inside newType");
				}
			});
			newService.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					//////////////// SUB WINDOW////////////////////
					Parent parent = null;
					try {
						parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewService.fxml"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Stage stage = new Stage();
					// stage.initStyle(StageStyle.TRANSPARENT);
					stage.setTitle("New Service");
					stage.setScene(new Scene(parent));
					stage.initModality(Modality.WINDOW_MODAL);
					stage.initOwner(MainApp.getStage());
					stage.show();
					//////////////// SUB WINDOW////////////////////
					// System.out.println("Am inside newType");
				}
			});
		} catch (Exception e) {
		}
	}

	protected void addNewFunction() { // Creating a new XML
		UpdateXML.createXml(packageName, xmlName, element);
	}

	public static void constructStructure() {
		TreeItem<String> root = new TreeItem<>("Home", new ImageView(foldericon));
		try {
			ReadBase rb = new ReadBase();
			BaseBean baseBean = rb.getBasebean();
			List<BaseBean> baseList = baseBean.getBaseList();
			HashMap<String, List<Header>> typeMap = new HashMap<String, List<Header>>();
			HashMap<String, List<Header>> functionMap = new HashMap<String, List<Header>>();
			HashMap<String, List<Header>> serviceMap = new HashMap<String, List<Header>>();
			for (BaseBean base : baseList) {
				TreeItem<String> id = null;
				String key;
				List<HashMap<String, Object>> list = base.getHeaderList();
				// if (list.size() > 0) {
				id = new TreeItem<>(base.getId(), new ImageView(foldericon));
				packageList.add(base.getId());
				// }
				// System.out.println(list);
				List<String> typeList = new ArrayList<String>();
				List<String> functionList = new ArrayList<String>();
				List<String> serviceList = new ArrayList<String>();
				// for(HashMap<String,Object> hash:list) {
				List<Header> headerTypeList = new ArrayList<Header>();
				List<Header> headerFunctionList = new ArrayList<Header>();
				List<Header> headerServiceList = new ArrayList<Header>();
				// System.out.println("LIST : "+list.size());
				if (list.size() == 0) { // for new created one
					TreeItem<String> function = new TreeItem<>("function", new ImageView(foldericon));
					TreeItem<String> type = new TreeItem<>("type", new ImageView(foldericon));
					TreeItem<String> service = new TreeItem<>("service", new ImageView(foldericon));
					id.getChildren().addAll(type, function, service);
				}
				for (int j = 0; j < list.size(); j++) {
					// System.out.println("LIST : "+list.size());
					HashMap<String, Object> hash = list.get(j);
					Iterator i = null;
					if (hash != null) {
						i = hash.entrySet().iterator();
						while (i.hasNext() && i != null) {
							Entry entry = (Entry) i.next();
							key = (String) entry.getKey();
							// System.out.println(key);
							Header header = (Header) entry.getValue();
							Element type = header.getType();
							if (type.getTextContent().equals("type")) {
								typeList.add(key);
								headerTypeList.add(header);
							}
							if (type.getTextContent().equals("function")) {
								functionList.add(key);
								headerFunctionList.add(header);
							}
							if (type.getTextContent().equals("service")) {
								serviceList.add(key);
								headerServiceList.add(header);
							}
							// System.out.println(type.getTextContent());
						}
						// System.out.println(hash.size());
					}
					// System.out.println("AM in");
					TreeItem<String> function = new TreeItem<>("function", new ImageView(foldericon));
					for (String functionname : functionList) {
						TreeItem<String> subType = new TreeItem<>(functionname, new ImageView(blockicon));
						function.getChildren().add(subType);
					}
					TreeItem<String> type = new TreeItem<>("type", new ImageView(foldericon));
					for (String typename : typeList) {
						TreeItem<String> subType = new TreeItem<>(typename, new ImageView(blockicon));
						type.getChildren().add(subType);
					}
					TreeItem<String> service = new TreeItem<>("service", new ImageView(foldericon));
					for (String serviceName : serviceList) {
						TreeItem<String> subType = new TreeItem<>(serviceName, new ImageView(blockicon));
						service.getChildren().add(subType);
					}
					if (j == list.size() - 1 && id != null)
						id.getChildren().addAll(type, function, service);
				}
				typeMap.put(base.getId(), headerTypeList);
				functionMap.put(base.getId(), headerFunctionList);
				serviceMap.put(base.getId(), headerServiceList);
				if (id != null)
					root.getChildren().add(id);
				/*
				 * List<HashMap<String, List<ItemBase>>> inFunctionlist =
				 * base.getFunctionInputlist(); if (inFunctionlist != null)
				 * infunctionMap.put(base.getId(), inFunctionlist);
				 * List<HashMap<String, List<ItemBase>>> outFunctionlist =
				 * base.getFunctionOutputlist(); if (outFunctionlist != null)
				 * outputFunctionMap.put(base.getId(), outFunctionlist);
				 * List<HashMap<String, List<ItemBase>>> inputServicelist =
				 * base.getServiceInputlist(); if (inputServicelist != null)
				 * inputServiceMap.put(base.getId(), inputServicelist);
				 * List<HashMap<String, List<ItemBase>>> outputServicelist =
				 * base.getServiceOutputlist(); if (outputServicelist != null)
				 * outputServiceMap.put(base.getId(), outputServicelist);
				 */
				///////////////////////////// TYPE/////////////////////////////////
				List<HashMap<String, TypeData>> typeMapList = base.getTypeMapList();
				if (typeMapList != null)
					bulkTypeMap.put(base.getId(), typeMapList);
				//////////////////////////// FUNCTION////////////////////////////////
				List<HashMap<String, FunctionData>> functionMapList = base.getFunctionMapList();
				if (functionMapList != null)
					bulkFunctionMap.put(base.getId(), functionMapList);
				/////////////////////////// SERVICE//////////////////////////////////
				List<HashMap<String, ServiceData>> serviceMapList = base.getServiceMapList();
				if (serviceMapList != null)
					bulkServiceMap.put(base.getId(), serviceMapList);
				/////////////////////////////////////////////////////////////////////
				/*
				 * if(inFunctionlist!=null) for (int j = 0; j <
				 * inFunctionlist.size(); j++) {
				 * 
				 * HashMap<String, List<ItemBase>> hash = inFunctionlist.get(j);
				 * 
				 * //System.out.println(hash); Iterator i = null; if (hash !=
				 * null) { i = hash.entrySet().iterator(); while (i.hasNext() &&
				 * i != null) { Entry entry = (Entry) i.next(); key = (String)
				 * entry.getKey(); //System.out.println("key: : "+key);
				 * List<ItemBase> itemList=(List<ItemBase>)entry.getValue();
				 * //System.out.println(itemList.size()); } }
				 * 
				 * }
				 */// End of inFunctionList iterate
			} // End of Bean Iterate
			TypeController.setTypeMap(typeMap);
			FunctionController.setFunctionMap(functionMap);
			ServiceController.setServiceMap(serviceMap);
			MainApp.progress = "Finalizing Features";
			new MainApp().setPercent(100);
		} catch (IOException | ParserConfigurationException | SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sampleTree.setRoot(root);
	}

	public Region fadeAnimate(String url) throws IOException {
		// System.out.println(url);
		Region v = (Region) FXMLLoader.load(getClass().getResource(url));
		return v;
	}

	public TreeItem<String> makeBranch(String title, TreeItem<String> parent) {
		TreeItem<String> item = new TreeItem<>(title);
		item.setExpanded(true);
		return item;
	}

	public void setDataPane(Region node) {
		// update VBox with new form(FXML) depends on which button is clicked
		dataPane.getChildren().setAll(node);
		node.prefWidthProperty().bind(dataPane.widthProperty());
		node.prefHeightProperty().bind(dataPane.heightProperty());
	}

	public void loadFunctionScreen() throws IOException {
		setDataPane(fadeAnimate("/View/Function.fxml"));
	}

	public void loadInFunctionScreen() throws IOException {
		setDataPane(fadeAnimate("/View/inFunction.fxml"));
	}

	public void loadServiceScreen() throws IOException {
		setDataPane(fadeAnimate("/View/Service.fxml"));
	}

	public void loadInServiceScreen() throws IOException {
		setDataPane(fadeAnimate("/View/inService.fxml"));
	}

	public void loadTypeScreen() throws IOException {
		setDataPane(fadeAnimate("/View/Type.fxml"));
	}

	public void loadInTypeScreen() throws IOException {
		setDataPane(fadeAnimate("/View/inType.fxml"));
	}

	public void mouseClick(MouseEvent evnt) {
		if (evnt.getClickCount() == 2) {
			System.out.println("Twice");

			TreeItem<String> sel = treeview.getSelectionModel().getSelectedItem();
			if (sel.isLeaf()) {
				if (sel.getParent().getValue().equals("type")) {
					application = sel.getParent().getParent().getValue();
					editTypeFunction(sel);
				} else if (sel.getParent().getValue().equals("function")) {
					System.out.println("Inside FUnction");
					application = sel.getParent().getParent().getValue();
					editFunctionFunction(sel);
				} else if (sel.getParent().getValue().equals("service")) {
					System.out.println("Inside Service");
					application = sel.getParent().getParent().getValue();
					editServiceFunction(sel);
				}
			}
		} else {
			// System.out.println("Am JAnaaa");
			TreeItem<String> sel = treeview.getSelectionModel().getSelectedItem();
			// System.out.println(sel.getValue());
			// System.out.println(sel.getParent().getValue());
			try {
				if (sel != null) {
					if (sel.getParent().getValue().equals("function")) {
						application = sel.getParent().getParent().getValue();
						InFunctionController.setPackageName(sel.getParent().getParent().getValue());
						InFunctionController.setFunctionName(sel.getValue());
						System.out.println("FUNCTION LIST : : :"+bulkFunctionMap.get(sel.getParent().getParent().getValue()));
						InFunctionController
								.setFunctionMapList(bulkFunctionMap.get(sel.getParent().getParent().getValue()));
						InFunctionController.setTypeList(bulkTypeMap.get(sel.getParent().getParent().getValue()));
						loadInFunctionScreen();
					} else if (sel.getValue().equals("function")) {
						application = sel.getParent().getValue();
						FunctionController.setPackage(sel.getParent().getValue());
						try {
							loadFunctionScreen();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else if (sel.getValue().equals("type")) {
						application = sel.getParent().getValue();
						TypeController.setPackage(sel.getParent().getValue());
						try {
							loadTypeScreen();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else if (sel.getParent().getValue().equals("type")) {
						try {
							application = sel.getParent().getParent().getValue();
							InTypeController.setPackageName(sel.getParent().getParent().getValue());
							InTypeController.setTypeName(sel.getValue());
							System.out.println(bulkTypeMap);
							InTypeController.setTypeList(bulkTypeMap.get(sel.getParent().getParent().getValue()));
							loadInTypeScreen();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else if (sel.getValue().equals("service")) {
						try {
							// System.out.println("Inside Service");
							application = sel.getParent().getValue();
							ServiceController.setPackage(sel.getParent().getValue());
							loadServiceScreen();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else if (sel.getParent().getValue().equals("service")) {
						try {
							application = sel.getParent().getParent().getValue();
							System.out.println("PAKCAG NAME" + sel.getParent().getParent().getValue());
							InServiceController.setPackageName(sel.getParent().getParent().getValue());
							InServiceController.setServiceName(sel.getValue());
							InServiceController
									.setServiceMapList(bulkServiceMap.get(sel.getParent().getParent().getValue()));
							InServiceController
									.setFunctionMapList(bulkFunctionMap.get(sel.getParent().getParent().getValue()));
							loadInServiceScreen();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						application = sel.getValue();
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void editTypeFunction(TreeItem<String> sel) {
		EditTypeController.oldTypeName = sel.getValue();
		System.out.println(InTypeController.observableItemList);
		//////////////// SUB WINDOW////////////////////
		Parent parent = null;
		try {
			parent = (Parent) FXMLLoader.load(getClass().getResource("/View/EditType.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Stage stage = new Stage();
		// stage.initStyle(StageStyle.TRANSPARENT);
		stage.setTitle("New Service");
		stage.setScene(new Scene(parent));
		stage.initModality(Modality.WINDOW_MODAL);
		stage.initOwner(MainApp.getStage());
		stage.showAndWait();
		//////////////// SUB WINDOW////////////////////
		ObservableList<TreeItem<String>> list = sel.getParent().getParent().getChildren();
		// sel.getParent().getChildren()
		String toRemove = EditTypeController.oldTypeName;
		if (EditTypeController.newEntry) {

			if (EditTypeController.newFieldMap.get("name") != null) {
				int valid = addNewFunction(EditTypeController.application, EditTypeController.xmlName,
						EditTypeController.element, toRemove);
				if (valid == 1) {
					System.out.println("__________________________");
					System.out.println(toRemove);
					System.out.println(EditTypeController.newFieldMap.get("name"));
					// TreeItem removeItem = new
					// TreeItem<String>(sel.getValue(),new
					// ImageView(blockicon));
					TreeItem newItem = new TreeItem<String>(EditTypeController.newFieldMap.get("name"),
							new ImageView(blockicon));
					for (TreeItem<String> item : list) {
						// System.out.println(item.getValue());
						if (item.getValue().equals("type")) {
							// System.out.println("Removed");
							item.getChildren().remove(sel);
							item.getChildren().add(newItem);
						}
					}
					List<HashMap<String, TypeData>> typeList = MainController.bulkTypeMap
							.get(EditTypeController.application);
					TypeData type = new TypeData();
					Header header = new Header();
					System.out.println("MAP : : :" + EditTypeController.newFieldMap);
					HashMap<String, String> newFieldMap = new HashMap<String, String>();
					Iterator i = null;
					boolean con = true;
					if (EditTypeController.newFieldMap != null) {
						i = EditTypeController.newFieldMap.entrySet().iterator();
						while (i.hasNext() && i != null) {
							Entry entry = (Entry) i.next();
							if (entry != null) {
								newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
							}
						}
					}
					header.setAllElements(newFieldMap);
					type.setHeader(header);
					type.setHeaderMap(newFieldMap);
					type.setItemList(EditTypeController.itemList);
					type.setFileName(EditTypeController.xmlName + ".xml");
					List<HashMap<String, TypeData>> typeMapList = MainController.bulkTypeMap
							.get(MainController.application);
					for (HashMap<String, TypeData> typeMap : typeMapList) {
						Iterator itr = null;
						if (typeMap != null) {
							i = typeMap.entrySet().iterator();
							while (i.hasNext() && i != null) {
								Entry entry = (Entry) i.next();
								if (entry != null) {
									System.out.println("********" + entry.getKey());
									if (entry.getKey().toString().equals(sel.getValue())) {
										System.out.println("TO REMOVE : : ::  :" + sel.getValue());
										typeMap.remove(sel.getValue());
									}
								}
							}
						}
					}
					type.setSize(EditTypeController.size);
					// type.setSize(23);
					System.out.println(type.getHeader().getAllElements());
					// type.setHeaderMap(NewTypeController.newFieldMap);
					HashMap<String, TypeData> hash = new HashMap<String, TypeData>();
					hash.put(EditTypeController.newFieldMap.get("name"), type);
					if (typeList == null) {
						typeList = new ArrayList<HashMap<String, TypeData>>();
					}
					typeList.add(hash);
					System.out.println(EditTypeController.application);
					System.out.println(EditTypeController.newFieldMap.get("name"));
					MainController.bulkTypeMap.put(EditTypeController.application, typeList);
				} else {
					Text text = new Text();
					text.setText("Block Already Exist!!!!");
					text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
					text.setX(50);
					text.setY(50);
					Group root = new Group(text);
					Scene scene = new Scene(root, 350, 100);
					Stage stage1 = new Stage();
					stage1.setTitle("Warning");
					stage1.setScene(scene);
					stage1.show();
				}
			}
		}
		EditTypeController.newEntry = false;
	}

	private void editFunctionFunction(TreeItem<String> sel) {
		EditFunctionController.oldFunctionName = sel.getValue();
		//////////////// SUB WINDOW////////////////////
		Parent parent = null;
		try {
			parent = (Parent) FXMLLoader.load(getClass().getResource("/View/EditFunction.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Stage stage = new Stage();
		// stage.initStyle(StageStyle.TRANSPARENT);
		stage.setTitle("New Function");
		stage.setScene(new Scene(parent));
		stage.initModality(Modality.WINDOW_MODAL);
		stage.initOwner(MainApp.getStage());
		stage.showAndWait();
		//////////////// SUB WINDOW////////////////////
		ObservableList<TreeItem<String>> list = sel.getParent().getParent().getChildren();
		// sel.getParent().getChildren()
		String toRemove = EditFunctionController.oldFunctionName;
		System.out.println("TO RMV : : :"+toRemove);
		if (EditFunctionController.newEntry) {
			System.out.println("Inside New Entry");
			System.out.println(toRemove);
			if (EditFunctionController.newFieldMap.get("name") != null) {
				int valid = addNewFunction(EditFunctionController.application, EditFunctionController.xmlName,
						EditFunctionController.element, toRemove);
				if (valid == 1) {
					System.out.println("__________________________");
					System.out.println(toRemove);
					System.out.println(EditFunctionController.newFieldMap.get("name"));
					// TreeItem removeItem = new
					// TreeItem<String>(sel.getValue(),new
					// ImageView(blockicon));
					TreeItem newItem = new TreeItem<String>(EditFunctionController.newFieldMap.get("name"),
							new ImageView(blockicon));
					for (TreeItem<String> item : list) {
						// System.out.println(item.getValue());
						if (item.getValue().equals("function")) {
							// System.out.println("Removed");
							item.getChildren().remove(sel);
							item.getChildren().add(newItem);
						}
					}
					
					List<HashMap<String, FunctionData>> functionDataList = MainController.bulkFunctionMap
							.get(EditFunctionController.application);
					FunctionData function = new FunctionData();
					Header header = new Header();
					header.setAllElements(EditFunctionController.newFieldMap);
					function.setHeader(header);
					// function.setHeaderMap((NewFunctionController.newFieldMap));
					if (functionDataList == null) {
						functionDataList = new ArrayList<HashMap<String, FunctionData>>();
					}
					for (HashMap<String, FunctionData> functionMap : functionDataList) {
						Iterator itr = null;
						if (functionMap != null) {
							itr = functionMap.entrySet().iterator();
							while (itr.hasNext() && itr != null) {
								Entry entry = (Entry) itr.next();
								if (entry != null) {
									System.out.println("********" + entry.getKey());
									if (entry.getKey().toString().equals(sel.getValue())) {
										System.out.println("TO REMOVE : : ::  :" + sel.getValue());
										function.setInputItemList(((FunctionData)entry.getValue()).getInputItemList());
										function.setInputOccurs(((FunctionData)entry.getValue()).getInputOccurs());
										function.setOutputItemList(((FunctionData)entry.getValue()).getOutputItemList());
										function.setOutputOccurs(((FunctionData)entry.getValue()).getOutputOccurs());
										functionMap.remove(sel.getValue());
									}
								}
							}
						}
					}
					HashMap<String, FunctionData> hash = new HashMap<String, FunctionData>();
					MainController.bulkFunctionMap.put(EditFunctionController.application, functionDataList);
					HashMap<String, String> newFieldMap = new HashMap<String, String>();
					Iterator i = null;
					boolean con = true;
					if (EditFunctionController.newFieldMap != null) {
						i = EditFunctionController.newFieldMap.entrySet().iterator();
						while (i.hasNext() && i != null) {
							Entry entry = (Entry) i.next();
							if (entry != null) {
								newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
							}
						}
					}
					header.setAllElements(newFieldMap);
					function.setHeader(header);
					function.setHeaderMap(newFieldMap);
					function.setFileName(EditFunctionController.xmlName + ".xml");

					hash.put(EditFunctionController.newFieldMap.get("name"), function);
					if (functionDataList == null) {
						functionDataList = new ArrayList<HashMap<String, FunctionData>>();
					}
					functionDataList.add(hash);
					System.out.println(EditFunctionController.application);
					System.out.println(EditFunctionController.newFieldMap.get("name"));
					MainController.bulkFunctionMap.put(EditFunctionController.application, functionDataList);
				} else {
					Text text = new Text();
					text.setText("Block Already Exist!!!!");
					text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
					text.setX(50);
					text.setY(50);
					Group root = new Group(text);
					Scene scene = new Scene(root, 350, 100);
					Stage stage1 = new Stage();
					stage1.setTitle("Warning");
					stage1.setScene(scene);
					stage1.show();
				}
			}
		}
		EditFunctionController.newEntry = false;
	}

	private void editServiceFunction(TreeItem<String> sel) {
		EditServiceController.oldServiceName = sel.getValue();
		//////////////// SUB WINDOW////////////////////
		Parent parent = null;
		try {
			parent = (Parent) FXMLLoader.load(getClass().getResource("/View/EditService.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Stage stage = new Stage();
		// stage.initStyle(StageStyle.TRANSPARENT);
		stage.setTitle("New Function");
		stage.setScene(new Scene(parent));
		stage.initModality(Modality.WINDOW_MODAL);
		stage.initOwner(MainApp.getStage());
		stage.showAndWait();
		//////////////// SUB WINDOW////////////////////
		ObservableList<TreeItem<String>> list = sel.getParent().getParent().getChildren();
		// sel.getParent().getChildren()
		String toRemove = EditServiceController.oldServiceName;
		System.out.println("TO RMV : : :"+toRemove);
		if (EditServiceController.newEntry) {
			System.out.println("Inside New Entry");
			System.out.println(toRemove);
			if (EditServiceController.newFieldMap.get("name") != null) {
				int valid = addNewFunction(EditServiceController.application, EditServiceController.xmlName,
						EditServiceController.element, toRemove);
				if (valid == 1) {
					System.out.println("__________________________");
					System.out.println(toRemove);
					System.out.println(EditServiceController.newFieldMap.get("name"));
					// TreeItem removeItem = new
					// TreeItem<String>(sel.getValue(),new
					// ImageView(blockicon));
					TreeItem newItem = new TreeItem<String>(EditServiceController.newFieldMap.get("name"),
							new ImageView(blockicon));
					for (TreeItem<String> item : list) {
						// System.out.println(item.getValue());
						if (item.getValue().equals("service")) {
							// System.out.println("Removed");
							item.getChildren().remove(sel);
							item.getChildren().add(newItem);
						}
					}
					
					List<HashMap<String, ServiceData>> serviceMapList = MainController.bulkServiceMap
							.get(EditServiceController.application);
					ServiceData service = new ServiceData();
					Header header = new Header();
					header.setAllElements(EditServiceController.newFieldMap);
					service.setHeader(header);
					// function.setHeaderMap((NewFunctionController.newFieldMap));
					if (serviceMapList == null) {
						serviceMapList = new ArrayList<HashMap<String, ServiceData>>();
					}
					for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
						Iterator itr = null;
						if (serviceMap != null) {
							itr = serviceMap.entrySet().iterator();
							while (itr.hasNext() && itr != null) {
								Entry entry = (Entry) itr.next();
								if (entry != null) {
									System.out.println("********" + entry.getKey());
									if (entry.getKey().toString().equals(sel.getValue())) {
										System.out.println("TO REMOVE : : ::  :" + sel.getValue());
										serviceMap.remove(sel.getValue());
										service.setInputItemList(((ServiceData)entry.getValue()).getInputItemList());
										service.setOutputItemList(((ServiceData)entry.getValue()).getOutputItemList());
									}
								}
							}
						}
					}
					HashMap<String, ServiceData> hash = new HashMap<String, ServiceData>();
					MainController.bulkServiceMap.put(EditServiceController.application, serviceMapList);
					HashMap<String, String> newFieldMap = new HashMap<String, String>();
					Iterator i = null;
					boolean con = true;
					if (EditServiceController.newFieldMap != null) {
						i = EditServiceController.newFieldMap.entrySet().iterator();
						while (i.hasNext() && i != null) {
							Entry entry = (Entry) i.next();
							if (entry != null) {
								newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
							}
						}
					}
					header.setAllElements(newFieldMap);
					service.setHeader(header);
					service.setHeaderMap(newFieldMap);
					service.setFileName(EditServiceController.xmlName + ".xml");

					hash.put(EditServiceController.newFieldMap.get("name"), service);
					if (serviceMapList == null) {
						serviceMapList = new ArrayList<HashMap<String, ServiceData>>();
					}
					serviceMapList.add(hash);
					System.out.println(EditServiceController.application);
					System.out.println(EditServiceController.newFieldMap.get("name"));
					MainController.bulkServiceMap.put(EditServiceController.application, serviceMapList);
				} else {
					Text text = new Text();
					text.setText("Block Already Exist!!!!");
					text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
					text.setX(50);
					text.setY(50);
					Group root = new Group(text);
					Scene scene = new Scene(root, 350, 100);
					Stage stage1 = new Stage();
					stage1.setTitle("Warning");
					stage1.setScene(scene);
					stage1.show();
				}
			}
		}
		EditServiceController.newEntry = false;
	}

	
	protected int addNewFunction(String application, String xmlName, Element element, String oldXmlName) {
		// UpdateMap.updateBlock
		return UpdateXML.replaceXml(application, xmlName, element, oldXmlName);
	}
}

final class TextFieldTreeCellImpl extends TreeCell<String> {
	// public static TreeItem<String> selected;
	private TextField textField;
	Image blockicon = new Image(getClass().getResourceAsStream("/Resources/block.png"), 10, 10, false, false);
	private ContextMenu addMenu = new ContextMenu();
	EventHandler<ActionEvent> newTypeEvent = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			//////////////// SUB WINDOW////////////////////
			Parent parent = null;
			try {
				parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewType.fxml"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Stage stage = new Stage();
			// stage.initStyle(StageStyle.TRANSPARENT);
			stage.setTitle("New Type");
			stage.setScene(new Scene(parent));
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(MainApp.getStage());
			stage.setResizable(false);
			stage.showAndWait();
			System.out.println("SELECTED : : : " + getTreeItem());
			//////////////// SUB WINDOW////////////////////
			System.out.println("add  TYPE Operation");
			System.out.println(NewTypeController.application); // package name
			System.out.println(NewTypeController.arrayList);
			System.out.println(NewTypeController.newElementMap);
			System.out.println(NewTypeController.newFieldMap.get("name"));
			if (NewTypeController.newEntry) {
				TreeItem newItem = null;
				if (NewTypeController.newFieldMap.get("name") != null) {
					int valid = addNewFunction(NewTypeController.application, NewTypeController.xmlName,
							NewTypeController.element);
					if (valid == 1) {
						newItem = new TreeItem<String>(NewTypeController.newFieldMap.get("name"),
								new ImageView(blockicon));
						if (getTreeItem().getValue().equals(NewTypeController.application)) {
							ObservableList<TreeItem<String>> list = getTreeItem().getChildren();
							for (TreeItem<String> item : list) {
								if (item.getValue().equals("type")) {
									item.getChildren().add(newItem);
								}
							}
						} else if (getTreeItem().getParent().getValue().equals(NewTypeController.application)) {
							System.out.println("AM in tyep");
							ObservableList<TreeItem<String>> list = getTreeItem().getParent().getChildren();
							for (TreeItem<String> item : list) {
								if (item.getValue().equals("type")) {
									item.getChildren().add(newItem);
								}
							}
						} else {
							ObservableList<TreeItem<String>> list = getTreeItem().getParent().getParent().getChildren();
							System.out.println("Am in else");
							for (TreeItem<String> item : list) {
								System.out.println(item.getValue());
								if (item.getValue().equals("type")) {
									item.getChildren().add(newItem);
								}
							}
						}
						List<HashMap<String, TypeData>> typeList = MainController.bulkTypeMap
								.get(NewTypeController.application);
						TypeData type = new TypeData();
						Header header = new Header();
						System.out.println("MAP : : :" + NewTypeController.newFieldMap);
						HashMap<String, String> newFieldMap = new HashMap<String, String>();
						Iterator i = null;
						if (NewTypeController.newFieldMap != null) {
							i = NewTypeController.newFieldMap.entrySet().iterator();
							while (i.hasNext() && i != null) {
								Entry entry = (Entry) i.next();
								if (entry != null) {
									newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
								}
							}
						}
						header.setAllElements(newFieldMap);
						type.setHeader(header);
						type.setHeaderMap(newFieldMap);
						type.setFileName(NewTypeController.xmlName + ".xml");
						// type.setSize(23);
						System.out.println(type.getHeader().getAllElements());
						// type.setHeaderMap(NewTypeController.newFieldMap);
						HashMap<String, TypeData> hash = new HashMap<String, TypeData>();
						hash.put(NewTypeController.newFieldMap.get("name"), type);
						if (typeList == null) {
							typeList = new ArrayList<HashMap<String, TypeData>>();
						}
						typeList.add(hash);
						System.out.println(NewTypeController.application);
						System.out.println(NewTypeController.newFieldMap.get("name"));
						MainController.bulkTypeMap.put(NewTypeController.application, typeList);
						// addNewFunction(NewTypeController.application,
						// NewTypeController.xmlName,
						// NewTypeController.element);
					} else {
						Text text = new Text();
						text.setText("Block Already Exist!!!!");
						text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
						text.setX(50);
						text.setY(50);
						Group root = new Group(text);
						Scene scene = new Scene(root, 350, 100);
						Stage stage1 = new Stage();
						stage1.setTitle("Warning");
						stage1.setScene(scene);
						stage1.show();
					}
				}
				NewTypeController.newFieldMap.clear();
			}
			NewTypeController.newEntry = false;
			System.out.println(MainController.application);
			System.out.println("++++#+#+#+#+#+#+#+#+@+!+@: : :: : : "
					+ MainController.bulkTypeMap.get(MainController.application));
		}
	};
	EventHandler<ActionEvent> newFunctionEvent = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			//////////////// SUB WINDOW////////////////////
			Parent parent = null;
			try {
				parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewFunction.fxml"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Stage stage = new Stage();
			// stage.initStyle(StageStyle.TRANSPARENT);
			stage.setTitle("New Function");
			stage.setScene(new Scene(parent));
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(MainApp.getStage());
			stage.showAndWait();
			//////////////// SUB WINDOW////////////////////
			System.out.println("Am inside newFuntion");
			System.out.println("add  Function Operation");
			System.out.println(NewFunctionController.application); // package
																	// name
			System.out.println(NewFunctionController.arrayList);
			System.out.println(NewFunctionController.newElementMap);
			System.out.println(NewFunctionController.newFieldMap.get("name"));
			if (NewFunctionController.newEntry) {
				TreeItem newItem = null;
				if (NewFunctionController.newFieldMap.get("name") != null) {
					int valid = addNewFunction(NewFunctionController.application, NewFunctionController.xmlName,
							NewFunctionController.element);
					if (valid == 1) {
						newItem = new TreeItem<String>(NewFunctionController.newFieldMap.get("name"),
								new ImageView(blockicon));
						if (getTreeItem().getValue().equals(NewFunctionController.application)) {
							ObservableList<TreeItem<String>> list = getTreeItem().getChildren();
							for (TreeItem<String> item : list) {
								if (item.getValue().equals("function")) {
									item.getChildren().add(newItem);
								}
							}
						} else if (getTreeItem().getParent().getValue().equals(NewFunctionController.application)) {
							System.out.println("AM in tyep");
							ObservableList<TreeItem<String>> list = getTreeItem().getParent().getChildren();
							for (TreeItem<String> item : list) {
								if (item.getValue().equals("function")) {
									item.getChildren().add(newItem);
								}
							}
						} else {
							ObservableList<TreeItem<String>> list = getTreeItem().getParent().getParent().getChildren();
							System.out.println("Am in else");
							for (TreeItem<String> item : list) {
								System.out.println(item.getValue());
								if (item.getValue().equals("function")) {
									item.getChildren().add(newItem);
								}
							}
						}
						List<HashMap<String, FunctionData>> functionData = MainController.bulkFunctionMap
								.get(NewFunctionController.application);
						FunctionData function = new FunctionData();
						Header header = new Header();
						HashMap<String, String> newFieldMap = new HashMap<String, String>();
						Iterator i = null;
						if (NewFunctionController.newFieldMap != null) {
							i = NewFunctionController.newFieldMap.entrySet().iterator();
							while (i.hasNext() && i != null) {
								Entry entry = (Entry) i.next();
								if (entry != null) {
									newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
								}
							}
						}
						header.setAllElements(newFieldMap);
						function.setHeader(header);
						function.setFileName(NewFunctionController.xmlName + ".xml");
						// function.setHeaderMap((NewFunctionController.newFieldMap));
						if (functionData == null) {
							functionData = new ArrayList<HashMap<String, FunctionData>>();
						}
						HashMap<String, FunctionData> hash = new HashMap<String, FunctionData>();
						hash.put(newFieldMap.get("name"), function);
						functionData.add(hash);
						MainController.bulkFunctionMap.put(NewFunctionController.application, functionData);
						// addNewFunction(NewFunctionController.application,
						// NewFunctionController.xmlName,
						// NewFunctionController.element);
					} else {
						Text text = new Text();
						text.setText("Block Already Exist!!!!");
						text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
						text.setX(50);
						text.setY(50);
						Group root = new Group(text);
						Scene scene = new Scene(root, 350, 100);
						Stage stage1 = new Stage();
						stage1.setTitle("Warning");
						stage1.setScene(scene);
						stage1.show();
					}
				}
				NewFunctionController.newFieldMap.clear();
			}
			NewFunctionController.newEntry = false;
		}
	};
	EventHandler<ActionEvent> newServiceEvent = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			//////////////// SUB WINDOW////////////////////
			Parent parent = null;
			try {
				parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewService.fxml"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Stage stage = new Stage();
			// stage.initStyle(StageStyle.TRANSPARENT);
			stage.setTitle("New Service");
			stage.setScene(new Scene(parent));
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(MainApp.getStage());
			stage.showAndWait();
			//////////////// SUB WINDOW////////////////////
			System.out.println("Am inside NewServiceController");
			System.out.println("add  NewServiceController Operation");
			System.out.println(NewServiceController.application); // package
																	// name
			System.out.println(NewServiceController.arrayList);
			System.out.println(NewServiceController.newElementMap);
			System.out.println(NewServiceController.newFieldMap.get("name"));
			if (NewServiceController.newEntry) {
				TreeItem newItem = null;
				if (NewServiceController.newFieldMap.get("name") != null) {
					int valid = addNewFunction(NewServiceController.application, NewServiceController.xmlName,
							NewServiceController.element);
					if (valid == 1) {
						newItem = new TreeItem<String>(NewServiceController.newFieldMap.get("name"),
								new ImageView(blockicon));
						if (getTreeItem().getValue().equals(NewServiceController.application)) {
							ObservableList<TreeItem<String>> list = getTreeItem().getChildren();
							for (TreeItem<String> item : list) {
								if (item.getValue().equals("service")) {
									item.getChildren().add(newItem);
								}
							}
						} else if (getTreeItem().getParent().getValue().equals(NewServiceController.application)) {
							System.out.println("AM in tyep");
							ObservableList<TreeItem<String>> list = getTreeItem().getParent().getChildren();
							for (TreeItem<String> item : list) {
								if (item.getValue().equals("service")) {
									item.getChildren().add(newItem);
								}
							}
						} else {
							ObservableList<TreeItem<String>> list = getTreeItem().getParent().getParent().getChildren();
							System.out.println("Am in else");
							for (TreeItem<String> item : list) {
								System.out.println(item.getValue());
								if (item.getValue().equals("service")) {
									item.getChildren().add(newItem);
								}
							}
						}
						List<HashMap<String, ServiceData>> serviceDataList = MainController.bulkServiceMap
								.get(NewServiceController.application);
						ServiceData service = new ServiceData();
						Header header = new Header();
						HashMap<String, String> newFieldMap = new HashMap<String, String>();
						Iterator i = null;
						if (NewServiceController.newFieldMap != null) {
							i = NewServiceController.newFieldMap.entrySet().iterator();
							while (i.hasNext() && i != null) {
								Entry entry = (Entry) i.next();
								if (entry != null) {
									newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
								}
							}
						}
						header.setAllElements(newFieldMap);
						service.setHeader(header);
						service.setFileName(NewServiceController.xmlName + ".xml");
						// service.setHeaderMap((NewServiceController.newFieldMap));
						HashMap<String, ServiceData> hash = new HashMap<String, ServiceData>();
						hash.put(newFieldMap.get("name"), service);
						if (serviceDataList == null) {
							serviceDataList = new ArrayList<HashMap<String, ServiceData>>();
						}
						serviceDataList.add(hash);
						MainController.bulkServiceMap.put(NewServiceController.application, serviceDataList);
					} else {
						Text text = new Text();
						text.setText("Block Already Exist!!!!");
						text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
						text.setX(50);
						text.setY(50);
						Group root = new Group(text);
						Scene scene = new Scene(root, 350, 100);
						Stage stage1 = new Stage();
						stage1.setTitle("Warning");
						stage1.setScene(scene);
						stage1.show();
					}
				}
				NewServiceController.newFieldMap.clear();
			}
			NewServiceController.newEntry = false;
		}
	};

	protected int addNewFunction(String application, String xmlName, Element element) {
		return UpdateXML.createXml(application, xmlName, element);
	}

	public TextFieldTreeCellImpl(TreeItem<String> selected) {
		if (selected != null)
			System.out.println(selected.getValue());
		MenuItem type = new MenuItem("New Type");
		type.setOnAction(newTypeEvent);
		MenuItem function = new MenuItem("New Function");
		function.setOnAction(newFunctionEvent);
		MenuItem service = new MenuItem("New Service");
		service.setOnAction(newServiceEvent);
		// System.out.println("AM sa");
		Menu paf = new Menu("PAF");
		Image userIcon = new Image(getClass().getResourceAsStream("/Resources/block.png"));
		ImageView userView = new ImageView(userIcon);
		userView.setFitWidth(15);
		userView.setFitHeight(15);
		paf.setGraphic(userView);
		paf.getItems().addAll(type, function, service);
		addMenu.getItems().add(paf);
		addMenu.setOnAction(newTypeEvent);
		/*
		 * addMenuItem.setOnAction(new EventHandler() { public void handle(Event
		 * t) { TreeItem newEmployee = new
		 * TreeItem<String>(NewTypeController.newFieldMap.get("name"));
		 * getTreeItem().getChildren().add(newEmployee); } });
		 */
	}

	@Override
	public void updateItem(String item, boolean empty) {
		// System.out.println("UpdateItem");
		super.updateItem(item, empty);
		if (empty) {
			setText(null);
			setGraphic(null);
		} else {
			if (isEditing()) {
			} else {
				setText(getString());
				setGraphic(getTreeItem().getGraphic());
				// if (!getTreeItem().isLeaf() && getTreeItem().getParent() !=
				// null) {
				setContextMenu(addMenu);
				// }
			}
		}
	}

	private String getString() {
		return getItem() == null ? "" : getItem().toString();
	}
}