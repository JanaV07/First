/**
 * This is auto-generated via ValueProcess.vm template file in Web Service Framework
 * Please do not make modification to this file
 *
 */


package arch.amps_sipi.value;

import java.util.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import arch.transformation.*;
import arch.transformation.validation.*;
import arch.transformation.xml.*;
import arch.webservice.*;
import javax.xml.namespace.QName;
import java.text.SimpleDateFormat;
import arch.util.DateTime;
import arch.util.Date;
import java.math.BigDecimal;

import arch.webservice.soap.SOAPTransformationContext;
import arch.amps_sipi.value.CreatePIInput;


public class CreatePIInputProcess extends ObjectProcessImpl 
{
  private static arch.log.Log log = arch.log.Log.instance("ValueProcess");
  static final String isoDateTimeFormat =  "yyyy-MM-dd'T'HH:mm:ss" ;
  static final String isoDateFormat = "yyyy-MM-dd";
  private static final String NAMESPACE = "urn:pershing.amps_sipi.types";
  private String parentElement = null;
  private Object currentMapKey = null;
  public static final String href="href";
  public static final String xsnil="xsi:nil";
//  public static final String repeated="repeated";
//  public static final String item="item";
  public static final char sharp='#';
  public static final boolean bfalse=false,btrue=true;
                                                                                                                                                                                                                                                                                                                                                                                                                           




  
  public CreatePIInputProcess() {

      
	 if(attriList ==null)
     {
     try{
     attriList=new CreatePIInput().getAttributeNames();
     }
     catch(Exception e)
     {
     }
  }

}
//#
  public Object newObject()
  {
     initObject();
     
     valueClassName = "CreatePIInput"; 
     _internalData = new CreatePIInput();
	if(attriList ==null)
     {
     try
     {
     attriList=((CreatePIInput)_internalData).getAttributeNames();
     }
     catch(Exception e)
     {
     }
     }
	
     return _internalData;
  }

 //#
	String attrValue=null;
	 XmlStructureHandler handler =null;
	 boolean bTagInSchema = false;
  public XmlStructureHandler startChild(String namespace, String elementName, Attributes attributes, TransformationContext context)
    throws SAXException
  {
  
  			            handler = super.startChild(namespace, elementName, attributes, context);
	bTagInSchema = false;
      try{
   indx=attriList.indexOf(elementName);
   if(indx > -1)
   {
    switch (indx)
    {
     case 0: 
       bTagInSchema = true;
      	arch.amps_sipi.value.HeaderInfoPITypeProcess p0 = new arch.amps_sipi.value.HeaderInfoPITypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p0.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p0.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p0);
			      attrValue=null;
			       return null;
   		   }
             return p0;
         }  // here
     case 1: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p1 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p1.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p1.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p1);
			      attrValue=null;
			       return null;
   		   }
             return p1;
         }  // here
     case 2: 
       bTagInSchema = true;
      	arch.amps_sipi.value.FedFundSIBlockTypeProcess p2 = new arch.amps_sipi.value.FedFundSIBlockTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p2.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p2.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p2);
			      attrValue=null;
			       return null;
   		   }
             return p2;
         }  // here
     case 3: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p3 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p3.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p3.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p3);
			      attrValue=null;
			       return null;
   		   }
             return p3;
         }  // here
     case 4: 
       bTagInSchema = true;
      	arch.amps_sipi.value.JournalsSIBlockTypeProcess p4 = new arch.amps_sipi.value.JournalsSIBlockTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p4.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p4.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p4);
			      attrValue=null;
			       return null;
   		   }
             return p4;
         }  // here
     case 5: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p5 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p5.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p5.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p5);
			      attrValue=null;
			       return null;
   		   }
             return p5;
         }  // here
     case 6: 
       bTagInSchema = true;
      	arch.amps_sipi.value.ChecksSIBlockTypeProcess p6 = new arch.amps_sipi.value.ChecksSIBlockTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p6.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p6.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p6);
			      attrValue=null;
			       return null;
   		   }
             return p6;
         }  // here
     case 7: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p7 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p7.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p7.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p7);
			      attrValue=null;
			       return null;
   		   }
             return p7;
         }  // here
     case 8: 
       bTagInSchema = true;
      	arch.amps_sipi.value.AchSIBlockTypeProcess p8 = new arch.amps_sipi.value.AchSIBlockTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p8.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p8.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p8);
			      attrValue=null;
			       return null;
   		   }
             return p8;
         }  // here
     case 9: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p9 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p9.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p9.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p9);
			      attrValue=null;
			       return null;
   		   }
             return p9;
         }  // here
     case 10: 
       bTagInSchema = true;
      	arch.amps_sipi.value.NonUSDSiCreateBlockTypeProcess p10 = new arch.amps_sipi.value.NonUSDSiCreateBlockTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p10.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p10.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p10);
			      attrValue=null;
			       return null;
   		   }
             return p10;
         }  // here
     case 11: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p11 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p11.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p11.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p11);
			      attrValue=null;
			       return null;
   		   }
             return p11;
         }  // here
     case 12: 
       bTagInSchema = true;
      	arch.amps_sipi.value.RtwSIBlockTypeProcess p12 = new arch.amps_sipi.value.RtwSIBlockTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p12.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p12.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p12);
			      attrValue=null;
			       return null;
   		   }
             return p12;
         }  // here
     case 13: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p13 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p13.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p13.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p13);
			      attrValue=null;
			       return null;
   		   }
             return p13;
         }  // here
     case 14: 
       bTagInSchema = true;
      	arch.amps_sipi.value.BankSendReceiveTypeProcess p14 = new arch.amps_sipi.value.BankSendReceiveTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p14.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p14.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p14);
			      attrValue=null;
			       return null;
   		   }
             return p14;
         }  // here
     case 15: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p15 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p15.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p15.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p15);
			      attrValue=null;
			       return null;
   		   }
             return p15;
         }  // here
     case 16: 
       bTagInSchema = true;
      	arch.amps_sipi.value.PiInstructionDetailsTypeProcess p16 = new arch.amps_sipi.value.PiInstructionDetailsTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p16.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p16.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p16);
			      attrValue=null;
			       return null;
   		   }
             return p16;
         }  // here
     case 17: 
       bTagInSchema = true;
      	arch.amps_sipi.value.PiTaxDetailsTypeProcess p17 = new arch.amps_sipi.value.PiTaxDetailsTypeProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p17.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p17.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p17);
			      attrValue=null;
			       return null;
   		   }
             return p17;
         }  // here
     case 18: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p18 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p18.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p18.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p18);
			      attrValue=null;
			       return null;
   		   }
             return p18;
         }  // here
     case 19: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p19 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p19.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p19.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p19);
			      attrValue=null;
			       return null;
   		   }
             return p19;
         }  // here
     case 20: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p20 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p20.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p20.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p20);
			      attrValue=null;
			       return null;
   		   }
             return p20;
         }  // here
     case 22: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p22 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p22.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p22.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p22);
			      attrValue=null;
			       return null;
   		   }
             return p22;
         }  // here
     case 24: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p24 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p24.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p24.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p24);
			      attrValue=null;
			       return null;
   		   }
             return p24;
         }  // here
     case 25: 
       bTagInSchema = true;
      	arch.transformation.xml.IntegerProcess p25 = new arch.transformation.xml.IntegerProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p25.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p25.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p25);
			      attrValue=null;
			       return null;
   		   }
             return p25;
         }  // here
}
    }
    }
    catch(Exception e)
    {
    	log.error("Error in startChild:"+e.getMessage());
    }
     // Handling List items and Map key value pairs
     if("ruleEngineError".equals(elementName) && 
    	   attributes.getIndex("href") != -1 && attributes.getValue("href").charAt(0) == '#')
	  {
	       // defer processing for List
	       bTagInSchema = true;
	       arch.transformation.xml.ListProcess lp;
    	   lp = new arch.transformation.xml.ListProcess();
    	   
           CreatePIInput value = (CreatePIInput)_internalData;
           value.setRuleEngineError((java.util.List)lp.getObject());
	      
	       String attrValue = attributes.getValue("href");
	       String refId = attrValue.substring(1, attrValue.length());
	       ((SOAPTransformationContext)context).setHandlerForMultiRefId(refId, lp);
	       return null;
      }
     // arch.rep.value.types.ValueType</arch/amps_sipi/value/RuleEngineErrorType:1>
                if("item".equals(elementName) && "ruleEngineError".equals(parentElement))
           {
             bTagInSchema = true;
             arch.amps_sipi.value.RuleEngineErrorTypeProcess p
                 = new arch.amps_sipi.value.RuleEngineErrorTypeProcess();
             p.newObject();
             return p;       
           }
           if("ruleEngineError".equals(elementName))
           {
             bTagInSchema = true;
                                                    super.validate(elementName, "", "x", 0, false);
			 			 			 if(context.containsAttribute("ignoreItemTag"))
			 {
			   arch.amps_sipi.value.RuleEngineErrorTypeProcess p
                 = new arch.amps_sipi.value.RuleEngineErrorTypeProcess();
             p.newObject();
             return p;       
			 }
			            }
          // Handling List items and Map key value pairs
     if("cusipBlock".equals(elementName) && 
    	   attributes.getIndex("href") != -1 && attributes.getValue("href").charAt(0) == '#')
	  {
	       // defer processing for List
	       bTagInSchema = true;
	       arch.transformation.xml.ListProcess lp;
    	   lp = new arch.transformation.xml.ListProcess();
    	   
           CreatePIInput value = (CreatePIInput)_internalData;
           value.setCusipBlock((java.util.List)lp.getObject());
	      
	       String attrValue = attributes.getValue("href");
	       String refId = attrValue.substring(1, attrValue.length());
	       ((SOAPTransformationContext)context).setHandlerForMultiRefId(refId, lp);
	       return null;
      }
     // arch.rep.value.types.ValueType</arch/amps_sipi/value/CusipBlockType:1>
                if("item".equals(elementName) && "cusipBlock".equals(parentElement))
           {
             bTagInSchema = true;
             arch.amps_sipi.value.CusipBlockTypeProcess p
                 = new arch.amps_sipi.value.CusipBlockTypeProcess();
             p.newObject();
             return p;       
           }
           if("cusipBlock".equals(elementName))
           {
             bTagInSchema = true;
                                                    super.validate(elementName, "", "x", 0, false);
			 			 			 if(context.containsAttribute("ignoreItemTag"))
			 {
			   arch.amps_sipi.value.CusipBlockTypeProcess p
                 = new arch.amps_sipi.value.CusipBlockTypeProcess();
             p.newObject();
             return p;       
			 }
			            }
          // Handling List items and Map key value pairs
     if("feeBlock".equals(elementName) && 
    	   attributes.getIndex("href") != -1 && attributes.getValue("href").charAt(0) == '#')
	  {
	       // defer processing for List
	       bTagInSchema = true;
	       arch.transformation.xml.ListProcess lp;
    	   lp = new arch.transformation.xml.ListProcess();
    	   
           CreatePIInput value = (CreatePIInput)_internalData;
           value.setFeeBlock((java.util.List)lp.getObject());
	      
	       String attrValue = attributes.getValue("href");
	       String refId = attrValue.substring(1, attrValue.length());
	       ((SOAPTransformationContext)context).setHandlerForMultiRefId(refId, lp);
	       return null;
      }
     // arch.rep.value.types.ValueType</arch/amps_sipi/value/FeeBlockType:1>
                if("item".equals(elementName) && "feeBlock".equals(parentElement))
           {
             bTagInSchema = true;
             arch.amps_sipi.value.FeeBlockTypeProcess p
                 = new arch.amps_sipi.value.FeeBlockTypeProcess();
             p.newObject();
             return p;       
           }
           if("feeBlock".equals(elementName))
           {
             bTagInSchema = true;
                                                    super.validate(elementName, "", "x", 0, false);
			 			 			 if(context.containsAttribute("ignoreItemTag"))
			 {
			   arch.amps_sipi.value.FeeBlockTypeProcess p
                 = new arch.amps_sipi.value.FeeBlockTypeProcess();
             p.newObject();
             return p;       
			 }
			            }
        if (bTagInSchema == false && handler == null) {
       //super.validate(elementName, bTagInSchema); 
       //PN. Commented above code to safeguard against code built with new core package. 
       ValidationHelper.setValidationStatus("Undefined tag name [" + elementName + "] encountered from request. Please check schema documentation. \n");
    }
    return handler;
  }
  
  public void startElement(String namespace, String elementName, Attributes attributes, TransformationContext context)
    throws SAXException
  {    
    super.startElement(namespace, elementName, attributes, context);    
    CreatePIInput     value = (CreatePIInput)_internalData;
    // Handle List , Map  and Attachment 
        if("ruleEngineError".equals(elementName))
    {
      parentElement = elementName;

      //context.setAttribute( "CURRENT_MAP_KEY", "ruleEngineError" );	
      if (attributes.getIndex("xsi:nil") != -1)
         ;
      else
         value.setRuleEngineError(new java.util.ArrayList());

    }
    if("cusipBlock".equals(elementName))
    {
      parentElement = elementName;

      //context.setAttribute( "CURRENT_MAP_KEY", "cusipBlock" );	
      if (attributes.getIndex("xsi:nil") != -1)
         ;
      else
         value.setCusipBlock(new java.util.ArrayList());

    }
    if("feeBlock".equals(elementName))
    {
      parentElement = elementName;

      //context.setAttribute( "CURRENT_MAP_KEY", "feeBlock" );	
      if (attributes.getIndex("xsi:nil") != -1)
         ;
      else
         value.setFeeBlock(new java.util.ArrayList());

    }
  }
  
  public void endElement(String namespace, String elementName, String contents, TransformationContext context)
      throws SAXException
  {
  	super.endElement(namespace, elementName, contents, context);
  	super.endChild( namespace, elementName, contents, context);
  	

  	
                                                                                                                                                                                                                                                      
  }
  
  public void endChild(String namespace, String elementName, String contents, TransformationContext context)
    throws SAXException
  {
        //super.validate(elementName, "", "x", 0, true);
        super.endChild( namespace, elementName, contents, context);
    CreatePIInput value = (CreatePIInput)_internalData;
    // Handling Object memebers
    // Handling List items and Map key value pairs
  }
CreatePIInput value = null;
public static java.util.List<String> attriList=null;
int indx=-1;
  public void endStructuredChild(String namespace, String elementName, XmlStructureHandler handler, TransformationContext context)
    throws SAXException
  {
    //CreatePIInput 
    value = (CreatePIInput)_internalData;
                     try{
   indx=attriList.indexOf(elementName);
   if(indx > -1)
   {
    switch (indx)
    {
	 case 0:
	 	                                   //2 .Tyep
         pHeaderInfoPIType =(arch.amps_sipi.value.HeaderInfoPITypeProcess)handler; //the process class..
                                                                                                                                                                                                     
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pHeaderInfoPIType.toString(), "x", 1000,  bfalse);
                                                                       				 				       value.setHeaderInfoPI((arch.amps_sipi.value.HeaderInfoPIType)pHeaderInfoPIType.getObject());
          break;
          	 case 1:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setFedFundsCount((Integer)pInteger.getObject());
          break;
          	 case 2:
	 	                                   //2 .Tyep
         pFedFundSIBlockType =(arch.amps_sipi.value.FedFundSIBlockTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pFedFundSIBlockType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setFedFundSIBlock((arch.amps_sipi.value.FedFundSIBlockType)pFedFundSIBlockType.getObject());
          break;
          	 case 3:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setJournalsCount((Integer)pInteger.getObject());
          break;
          	 case 4:
	 	                                   //2 .Tyep
         pJournalsSIBlockType =(arch.amps_sipi.value.JournalsSIBlockTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pJournalsSIBlockType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setJournalsSIBlock((arch.amps_sipi.value.JournalsSIBlockType)pJournalsSIBlockType.getObject());
          break;
          	 case 5:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setChecksCount((Integer)pInteger.getObject());
          break;
          	 case 6:
	 	                                   //2 .Tyep
         pChecksSIBlockType =(arch.amps_sipi.value.ChecksSIBlockTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pChecksSIBlockType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setChecksSIBlock((arch.amps_sipi.value.ChecksSIBlockType)pChecksSIBlockType.getObject());
          break;
          	 case 7:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setAchCount((Integer)pInteger.getObject());
          break;
          	 case 8:
	 	                                   //2 .Tyep
         pAchSIBlockType =(arch.amps_sipi.value.AchSIBlockTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pAchSIBlockType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setAchSIBlock((arch.amps_sipi.value.AchSIBlockType)pAchSIBlockType.getObject());
          break;
          	 case 9:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setNonUsdStandingInstructionCount((Integer)pInteger.getObject());
          break;
          	 case 10:
	 	                                   //2 .Tyep
         pNonUSDSiCreateBlockType =(arch.amps_sipi.value.NonUSDSiCreateBlockTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pNonUSDSiCreateBlockType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setNonUsdStandingInstructionBlock((arch.amps_sipi.value.NonUSDSiCreateBlockType)pNonUSDSiCreateBlockType.getObject());
          break;
          	 case 11:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setRetirementTaxWithHoldingCount((Integer)pInteger.getObject());
          break;
          	 case 12:
	 	                                   //2 .Tyep
         pRtwSIBlockType =(arch.amps_sipi.value.RtwSIBlockTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pRtwSIBlockType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setRetirementTaxWitholdingStandingInstructionBlock((arch.amps_sipi.value.RtwSIBlockType)pRtwSIBlockType.getObject());
          break;
          	 case 13:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setBankSendReceiveCount((Integer)pInteger.getObject());
          break;
          	 case 14:
	 	                                   //2 .Tyep
         pBankSendReceiveType =(arch.amps_sipi.value.BankSendReceiveTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pBankSendReceiveType.toString(), "x", 999,  bfalse);
                                                                       				 				       value.setBankSendReceiveBlock((arch.amps_sipi.value.BankSendReceiveType)pBankSendReceiveType.getObject());
          break;
          	 case 15:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 1, bfalse );
                                                                      				 				       value.setPamCount((Integer)pInteger.getObject());
          break;
          	 case 16:
	 	                                   //2 .Tyep
         pPiInstructionDetailsType =(arch.amps_sipi.value.PiInstructionDetailsTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pPiInstructionDetailsType.toString(), "x", 441,  bfalse);
                                                                       				 				       value.setPiInstructionDetails((arch.amps_sipi.value.PiInstructionDetailsType)pPiInstructionDetailsType.getObject());
          break;
          	 case 17:
	 	                                   //2 .Tyep
         pPiTaxDetailsType =(arch.amps_sipi.value.PiTaxDetailsTypeProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pPiTaxDetailsType.toString(), "x", 560,  bfalse);
                                                                       				 				       value.setPiTaxDetails((arch.amps_sipi.value.PiTaxDetailsType)pPiTaxDetailsType.getObject());
          break;
          	 case 18:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... String type
                                	 // //there 2
                    			   super.validate(elementName, pString.toString(), strString, 1, bfalse );
                                                                      				 				       value.setRulesEngineIndicator((java.lang.String)pString.getObject());
          break;
          	 case 19:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... String type
                                	 // //there 2
                    			   super.validate(elementName, pString.toString(), strString, 255, bfalse );
                                                                      				 				       value.setRulesEngineComment((java.lang.String)pString.getObject());
          break;
          	 case 20:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 4, bfalse );
                                                                      				 				       value.setRuleCount((Integer)pInteger.getObject());
          break;
          	 case 21:
	 	                                   //2 .Tyep
         pList =(arch.transformation.xml.ListProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pList.toString(), "x", 82,  bfalse);
                                                                       				 			 			if(!context.containsAttribute("ignoreItemTag"))
							       value.setRuleEngineError((java.util.List<arch.amps_sipi.value.RuleEngineErrorType>)pList.getObject());
          break;
          	 case 22:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 2, bfalse );
                                                                      				 				       value.setCusipCount((Integer)pInteger.getObject());
          break;
          	 case 23:
	 	                                   //2 .Tyep
         pList =(arch.transformation.xml.ListProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pList.toString(), "x", 60,  bfalse);
                                                                       				 			 			if(!context.containsAttribute("ignoreItemTag"))
							       value.setCusipBlock((java.util.List<arch.amps_sipi.value.CusipBlockType>)pList.getObject());
          break;
          	 case 24:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... String type
                                	 // //there 2
                    			   super.validate(elementName, pString.toString(), strString, 1, bfalse );
                                                                      				 				       value.setFeeAvailable((java.lang.String)pString.getObject());
          break;
          	 case 25:
	 	                                   //2 .Tyep
         pInteger =(arch.transformation.xml.IntegerProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... Integer type
                                	 // //there 2
                    			   super.validate(elementName, pInteger.toString(), strInteger, 2, bfalse );
                                                                      				 				       value.setFeeCount((Integer)pInteger.getObject());
          break;
          	 case 26:
	 	                                   //2 .Tyep
         pList =(arch.transformation.xml.ListProcess)handler; //the process class..
                                                                                                                                                                                   
                                    //validating 2... x type
                                	 // //there 2
                   //Complex type for soap and SP.
                  super.validate(elementName, pList.toString(), "x", 116,  bfalse);
                                                                       				 			 			if(!context.containsAttribute("ignoreItemTag"))
							       value.setFeeBlock((java.util.List<arch.amps_sipi.value.FeeBlockType>)pList.getObject());
          break;
          	}
    }
    }
    catch(Exception e)
    {
    log.error("Error in endStructuredChild:"+e.getMessage());		
//	e.printStackTrace();
    }























    if( "ruleEngineError".equals(elementName))
		parentElement = elementName;

    if("item".equals(elementName) && "ruleEngineError".equals(parentElement) )
    {
      arch.amps_sipi.value.RuleEngineErrorTypeProcess pHndl;
      pHndl = (arch.amps_sipi.value.RuleEngineErrorTypeProcess)handler;
      value.getRuleEngineError().add((arch.amps_sipi.value.RuleEngineErrorType)pHndl.getObject());   
    }
				 			 if("ruleEngineError".equals(elementName) && context.containsAttribute("ignoreItemTag"))
			 { 
			 arch.amps_sipi.value.RuleEngineErrorTypeProcess pHndl;
		pHndl = (arch.amps_sipi.value.RuleEngineErrorTypeProcess)handler;
	  if(value.getRuleEngineError() ==null)
      {
    	  value.setRuleEngineError(new java.util.ArrayList());
      }
		value.getRuleEngineError().add((arch.amps_sipi.value.RuleEngineErrorType)pHndl.getObject());   
			 
			 }
			 

    if( "cusipBlock".equals(elementName))
		parentElement = elementName;

    if("item".equals(elementName) && "cusipBlock".equals(parentElement) )
    {
      arch.amps_sipi.value.CusipBlockTypeProcess pHndl;
      pHndl = (arch.amps_sipi.value.CusipBlockTypeProcess)handler;
      value.getCusipBlock().add((arch.amps_sipi.value.CusipBlockType)pHndl.getObject());   
    }
				 			 if("cusipBlock".equals(elementName) && context.containsAttribute("ignoreItemTag"))
			 { 
			 arch.amps_sipi.value.CusipBlockTypeProcess pHndl;
		pHndl = (arch.amps_sipi.value.CusipBlockTypeProcess)handler;
	  if(value.getCusipBlock() ==null)
      {
    	  value.setCusipBlock(new java.util.ArrayList());
      }
		value.getCusipBlock().add((arch.amps_sipi.value.CusipBlockType)pHndl.getObject());   
			 
			 }
			 


    if( "feeBlock".equals(elementName))
		parentElement = elementName;

    if("item".equals(elementName) && "feeBlock".equals(parentElement) )
    {
      arch.amps_sipi.value.FeeBlockTypeProcess pHndl;
      pHndl = (arch.amps_sipi.value.FeeBlockTypeProcess)handler;
      value.getFeeBlock().add((arch.amps_sipi.value.FeeBlockType)pHndl.getObject());   
    }
				 			 if("feeBlock".equals(elementName) && context.containsAttribute("ignoreItemTag"))
			 { 
			 arch.amps_sipi.value.FeeBlockTypeProcess pHndl;
		pHndl = (arch.amps_sipi.value.FeeBlockTypeProcess)handler;
	  if(value.getFeeBlock() ==null)
      {
    	  value.setFeeBlock(new java.util.ArrayList());
      }
		value.getFeeBlock().add((arch.amps_sipi.value.FeeBlockType)pHndl.getObject());   
			 
			 }
			   }
  
  public void serializeRPCStyle( java.io.OutputStream out, QName name, Object object, TransformationContext context)
    throws java.io.IOException, TransformationException
  {
    if(object == null)
      return;
    boolean bOuterTagRequired = false;
    
    CreatePIInput valObj = (CreatePIInput)object;
    UrlPrefixRegistry reg = (UrlPrefixRegistry)context.getAttribute(TransformationContext.PREFIX_REGISTRY);
    String pfx = reg.getPrefix(NAMESPACE);
    StringBuffer outContent = new StringBuffer("");
    
    if (name!= null && !name.getLocalPart().trim().equals("")) {
       bOuterTagRequired = true;
    }
    
    if (bOuterTagRequired) {
       outContent.append("<");
       outContent.append(name.getLocalPart());
    }
    
    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	        
    if (bOuterTagRequired) {
        outContent.append(" xsi:type=\"").append(pfx).append(":CreatePIInput\"").append(" xmlns:").append(pfx)
        .append("=\"").append(NAMESPACE).append("\">");
    }
    
    out.write(outContent.toString().getBytes());
    outContent = null;
    serializeChildren(out, name, object, context);        

    // serialize super	 
    if (bOuterTagRequired) {
       out.write(("</" + name.getLocalPart() + ">").getBytes());
    }
  }

  public void serializeDocStyle( java.io.OutputStream out, QName name, Object object, TransformationContext context)
    throws java.io.IOException, TransformationException
  {
    if(object == null)
      return;
    boolean bOuterTagRequired  = false;
    
    CreatePIInput valObj = (CreatePIInput)object;  

    StringBuilder outContent = new StringBuilder("");
    
    if (name!= null && !name.getLocalPart().trim().equals("")) {
       bOuterTagRequired = true;
    }
    if (bOuterTagRequired) {
        outContent = new StringBuilder("<");
        outContent.append(name.getLocalPart());

    }
   
    if(bOuterTagRequired && (name.getNamespaceURI() != null && !name.getNamespaceURI().equals("")))
    {
        //PN. 07/15/2008. Prevent other services to fail when built against new code.  
        boolean version2 = false;
       
		if(arch.transformation.xml.XMLTransformation.getImplVersion().equals("2"))
		    version2 = true;
        
        if (!version2) 
           outContent.append(" xmlns=\"").append(name.getNamespaceURI()).append("\"");

    }

    
    if (bOuterTagRequired) {  


                  	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                  // $ForceNameSpace
        



        outContent.append(">");

                                                                                     }

    writeContents(out,outContent.toString(),context);
    outContent = null;
    // serialize children
    serializeChildren(out, name, object, context);
    if (bOuterTagRequired) {        
       //out.write(("</" + name.getLocalPart() + ">").getBytes());    
	   writeContents(out,("</" + name.getLocalPart() + ">"),context);

    }
  }
  
private static final String headerInfoPI="headerInfoPI";
private static final QName qheaderInfoPI=new QName(NAMESPACE, headerInfoPI);
static final ObjectProcessInterface objectProcessHeaderInfoPIType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.HeaderInfoPIType");
static final boolean bProcessHeaderInfoPIType = objectProcessHeaderInfoPIType !=null ? true :false;
static final String strHeaderInfoPIType = "HeaderInfoPIType" ;
//lowerFirstLetter
       arch.amps_sipi.value.HeaderInfoPITypeProcess pHeaderInfoPIType = null;//new arch.amps_sipi.value.HeaderInfoPITypeProcess();
       // pHeaderInfoPIType.setParent(this);
private static final String fedFundsCount="fedFundsCount";
private static final QName qfedFundsCount=new QName(NAMESPACE, fedFundsCount);
static final ObjectProcessInterface objectProcessInteger = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
static final boolean bProcessInteger = objectProcessInteger !=null ? true :false;
static final String strInteger = "Integer" ;
//lowerFirstLetter
       arch.transformation.xml.IntegerProcess pInteger = null;//new arch.transformation.xml.IntegerProcess();
       // pInteger.setParent(this);
private static final String fedFundSIBlock="fedFundSIBlock";
private static final QName qfedFundSIBlock=new QName(NAMESPACE, fedFundSIBlock);
static final ObjectProcessInterface objectProcessFedFundSIBlockType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.FedFundSIBlockType");
static final boolean bProcessFedFundSIBlockType = objectProcessFedFundSIBlockType !=null ? true :false;
static final String strFedFundSIBlockType = "FedFundSIBlockType" ;
//lowerFirstLetter
       arch.amps_sipi.value.FedFundSIBlockTypeProcess pFedFundSIBlockType = null;//new arch.amps_sipi.value.FedFundSIBlockTypeProcess();
       // pFedFundSIBlockType.setParent(this);
private static final String journalsCount="journalsCount";
private static final QName qjournalsCount=new QName(NAMESPACE, journalsCount);
private static final String journalsSIBlock="journalsSIBlock";
private static final QName qjournalsSIBlock=new QName(NAMESPACE, journalsSIBlock);
static final ObjectProcessInterface objectProcessJournalsSIBlockType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.JournalsSIBlockType");
static final boolean bProcessJournalsSIBlockType = objectProcessJournalsSIBlockType !=null ? true :false;
static final String strJournalsSIBlockType = "JournalsSIBlockType" ;
//lowerFirstLetter
       arch.amps_sipi.value.JournalsSIBlockTypeProcess pJournalsSIBlockType = null;//new arch.amps_sipi.value.JournalsSIBlockTypeProcess();
       // pJournalsSIBlockType.setParent(this);
private static final String checksCount="checksCount";
private static final QName qchecksCount=new QName(NAMESPACE, checksCount);
private static final String checksSIBlock="checksSIBlock";
private static final QName qchecksSIBlock=new QName(NAMESPACE, checksSIBlock);
static final ObjectProcessInterface objectProcessChecksSIBlockType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.ChecksSIBlockType");
static final boolean bProcessChecksSIBlockType = objectProcessChecksSIBlockType !=null ? true :false;
static final String strChecksSIBlockType = "ChecksSIBlockType" ;
//lowerFirstLetter
       arch.amps_sipi.value.ChecksSIBlockTypeProcess pChecksSIBlockType = null;//new arch.amps_sipi.value.ChecksSIBlockTypeProcess();
       // pChecksSIBlockType.setParent(this);
private static final String achCount="achCount";
private static final QName qachCount=new QName(NAMESPACE, achCount);
private static final String achSIBlock="achSIBlock";
private static final QName qachSIBlock=new QName(NAMESPACE, achSIBlock);
static final ObjectProcessInterface objectProcessAchSIBlockType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.AchSIBlockType");
static final boolean bProcessAchSIBlockType = objectProcessAchSIBlockType !=null ? true :false;
static final String strAchSIBlockType = "AchSIBlockType" ;
//lowerFirstLetter
       arch.amps_sipi.value.AchSIBlockTypeProcess pAchSIBlockType = null;//new arch.amps_sipi.value.AchSIBlockTypeProcess();
       // pAchSIBlockType.setParent(this);
private static final String nonUsdStandingInstructionCount="nonUsdStandingInstructionCount";
private static final QName qnonUsdStandingInstructionCount=new QName(NAMESPACE, nonUsdStandingInstructionCount);
private static final String nonUsdStandingInstructionBlock="nonUsdStandingInstructionBlock";
private static final QName qnonUsdStandingInstructionBlock=new QName(NAMESPACE, nonUsdStandingInstructionBlock);
static final ObjectProcessInterface objectProcessNonUSDSiCreateBlockType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.NonUSDSiCreateBlockType");
static final boolean bProcessNonUSDSiCreateBlockType = objectProcessNonUSDSiCreateBlockType !=null ? true :false;
static final String strNonUSDSiCreateBlockType = "NonUSDSiCreateBlockType" ;
//lowerFirstLetter
       arch.amps_sipi.value.NonUSDSiCreateBlockTypeProcess pNonUSDSiCreateBlockType = null;//new arch.amps_sipi.value.NonUSDSiCreateBlockTypeProcess();
       // pNonUSDSiCreateBlockType.setParent(this);
private static final String retirementTaxWithHoldingCount="retirementTaxWithHoldingCount";
private static final QName qretirementTaxWithHoldingCount=new QName(NAMESPACE, retirementTaxWithHoldingCount);
private static final String retirementTaxWitholdingStandingInstructionBlock="retirementTaxWitholdingStandingInstructionBlock";
private static final QName qretirementTaxWitholdingStandingInstructionBlock=new QName(NAMESPACE, retirementTaxWitholdingStandingInstructionBlock);
static final ObjectProcessInterface objectProcessRtwSIBlockType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.RtwSIBlockType");
static final boolean bProcessRtwSIBlockType = objectProcessRtwSIBlockType !=null ? true :false;
static final String strRtwSIBlockType = "RtwSIBlockType" ;
//lowerFirstLetter
       arch.amps_sipi.value.RtwSIBlockTypeProcess pRtwSIBlockType = null;//new arch.amps_sipi.value.RtwSIBlockTypeProcess();
       // pRtwSIBlockType.setParent(this);
private static final String bankSendReceiveCount="bankSendReceiveCount";
private static final QName qbankSendReceiveCount=new QName(NAMESPACE, bankSendReceiveCount);
private static final String bankSendReceiveBlock="bankSendReceiveBlock";
private static final QName qbankSendReceiveBlock=new QName(NAMESPACE, bankSendReceiveBlock);
static final ObjectProcessInterface objectProcessBankSendReceiveType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.BankSendReceiveType");
static final boolean bProcessBankSendReceiveType = objectProcessBankSendReceiveType !=null ? true :false;
static final String strBankSendReceiveType = "BankSendReceiveType" ;
//lowerFirstLetter
       arch.amps_sipi.value.BankSendReceiveTypeProcess pBankSendReceiveType = null;//new arch.amps_sipi.value.BankSendReceiveTypeProcess();
       // pBankSendReceiveType.setParent(this);
private static final String pamCount="pamCount";
private static final QName qpamCount=new QName(NAMESPACE, pamCount);
private static final String piInstructionDetails="piInstructionDetails";
private static final QName qpiInstructionDetails=new QName(NAMESPACE, piInstructionDetails);
static final ObjectProcessInterface objectProcessPiInstructionDetailsType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.PiInstructionDetailsType");
static final boolean bProcessPiInstructionDetailsType = objectProcessPiInstructionDetailsType !=null ? true :false;
static final String strPiInstructionDetailsType = "PiInstructionDetailsType" ;
//lowerFirstLetter
       arch.amps_sipi.value.PiInstructionDetailsTypeProcess pPiInstructionDetailsType = null;//new arch.amps_sipi.value.PiInstructionDetailsTypeProcess();
       // pPiInstructionDetailsType.setParent(this);
private static final String piTaxDetails="piTaxDetails";
private static final QName qpiTaxDetails=new QName(NAMESPACE, piTaxDetails);
static final ObjectProcessInterface objectProcessPiTaxDetailsType = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.PiTaxDetailsType");
static final boolean bProcessPiTaxDetailsType = objectProcessPiTaxDetailsType !=null ? true :false;
static final String strPiTaxDetailsType = "PiTaxDetailsType" ;
//lowerFirstLetter
       arch.amps_sipi.value.PiTaxDetailsTypeProcess pPiTaxDetailsType = null;//new arch.amps_sipi.value.PiTaxDetailsTypeProcess();
       // pPiTaxDetailsType.setParent(this);
private static final String rulesEngineIndicator="rulesEngineIndicator";
private static final QName qrulesEngineIndicator=new QName(NAMESPACE, rulesEngineIndicator);
static final ObjectProcessInterface objectProcessString = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
static final boolean bProcessString = objectProcessString !=null ? true :false;
static final String strString = "String" ;
//lowerFirstLetter
       arch.transformation.xml.StringProcess pString = null;//new arch.transformation.xml.StringProcess();
       // pString.setParent(this);
private static final String rulesEngineComment="rulesEngineComment";
private static final QName qrulesEngineComment=new QName(NAMESPACE, rulesEngineComment);
private static final String ruleCount="ruleCount";
private static final QName qruleCount=new QName(NAMESPACE, ruleCount);
private static final String ruleEngineError="ruleEngineError";
private static final QName qruleEngineError=new QName(NAMESPACE, ruleEngineError);
static final ObjectProcessInterface objectProcessList = ObjectProcessRegistry.getProcessRegistry("java.util.List");
static final boolean bProcessList = objectProcessList !=null ? true :false;
static final String strList = "List" ;
//lowerFirstLetter
       arch.transformation.xml.ListProcess pList = null;//new arch.transformation.xml.ListProcess();
       // pList.setParent(this);
private static final String cusipCount="cusipCount";
private static final QName qcusipCount=new QName(NAMESPACE, cusipCount);
private static final String cusipBlock="cusipBlock";
private static final QName qcusipBlock=new QName(NAMESPACE, cusipBlock);
private static final String feeAvailable="feeAvailable";
private static final QName qfeeAvailable=new QName(NAMESPACE, feeAvailable);
private static final String feeCount="feeCount";
private static final QName qfeeCount=new QName(NAMESPACE, feeCount);
private static final String feeBlock="feeBlock";
private static final QName qfeeBlock=new QName(NAMESPACE, feeBlock);
//  CreatePIInput valObj = null;

  public void serializeChildren(java.io.OutputStream out, QName name, Object object, TransformationContext context)
    throws java.io.IOException, TransformationException
  {



	// ObjectProcessInterface objectProcess;
     CreatePIInput valObj = (CreatePIInput)object;

   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.HeaderInfoPIType");
//if(  bProcessHeaderInfoPIType)
{

	

	     objectProcessHeaderInfoPIType.serialize(out, qheaderInfoPI, valObj.getHeaderInfoPI(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.HeaderInfoPIType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qfedFundsCount, valObj.getFedFundsCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.FedFundSIBlockType");
//if(  bProcessFedFundSIBlockType)
{

	

	     objectProcessFedFundSIBlockType.serialize(out, qfedFundSIBlock, valObj.getFedFundSIBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.FedFundSIBlockType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qjournalsCount, valObj.getJournalsCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.JournalsSIBlockType");
//if(  bProcessJournalsSIBlockType)
{

	

	     objectProcessJournalsSIBlockType.serialize(out, qjournalsSIBlock, valObj.getJournalsSIBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.JournalsSIBlockType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qchecksCount, valObj.getChecksCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.ChecksSIBlockType");
//if(  bProcessChecksSIBlockType)
{

	

	     objectProcessChecksSIBlockType.serialize(out, qchecksSIBlock, valObj.getChecksSIBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.ChecksSIBlockType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qachCount, valObj.getAchCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.AchSIBlockType");
//if(  bProcessAchSIBlockType)
{

	

	     objectProcessAchSIBlockType.serialize(out, qachSIBlock, valObj.getAchSIBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.AchSIBlockType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qnonUsdStandingInstructionCount, valObj.getNonUsdStandingInstructionCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.NonUSDSiCreateBlockType");
//if(  bProcessNonUSDSiCreateBlockType)
{

	

	     objectProcessNonUSDSiCreateBlockType.serialize(out, qnonUsdStandingInstructionBlock, valObj.getNonUsdStandingInstructionBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.NonUSDSiCreateBlockType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qretirementTaxWithHoldingCount, valObj.getRetirementTaxWithHoldingCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.RtwSIBlockType");
//if(  bProcessRtwSIBlockType)
{

	

	     objectProcessRtwSIBlockType.serialize(out, qretirementTaxWitholdingStandingInstructionBlock, valObj.getRetirementTaxWitholdingStandingInstructionBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.RtwSIBlockType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qbankSendReceiveCount, valObj.getBankSendReceiveCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.BankSendReceiveType");
//if(  bProcessBankSendReceiveType)
{

	

	     objectProcessBankSendReceiveType.serialize(out, qbankSendReceiveBlock, valObj.getBankSendReceiveBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.BankSendReceiveType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qpamCount, valObj.getPamCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.PiInstructionDetailsType");
//if(  bProcessPiInstructionDetailsType)
{

	

	     objectProcessPiInstructionDetailsType.serialize(out, qpiInstructionDetails, valObj.getPiInstructionDetails(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.PiInstructionDetailsType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("arch.amps_sipi.value.PiTaxDetailsType");
//if(  bProcessPiTaxDetailsType)
{

	

	     objectProcessPiTaxDetailsType.serialize(out, qpiTaxDetails, valObj.getPiTaxDetails(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - arch.amps_sipi.value.PiTaxDetailsType skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qrulesEngineIndicator, valObj.getRulesEngineIndicator(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qrulesEngineComment, valObj.getRulesEngineComment(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qruleCount, valObj.getRuleCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.util.List");
//if(  bProcessList)
{

	

	     objectProcessList.serialize(out, qruleEngineError, valObj.getRuleEngineError(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.util.List skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qcusipCount, valObj.getCusipCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.util.List");
//if(  bProcessList)
{

	

	     objectProcessList.serialize(out, qcusipBlock, valObj.getCusipBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.util.List skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qfeeAvailable, valObj.getFeeAvailable(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.Integer");
//if(  bProcessInteger)
{

	

	     objectProcessInteger.serialize(out, qfeeCount, valObj.getFeeCount(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.Integer skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.util.List");
//if(  bProcessList)
{

	

	     objectProcessList.serialize(out, qfeeBlock, valObj.getFeeBlock(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.util.List skipping serialization for this");
   }
/*Arun:
*Need this to support the builds against the new core until the core change is promoted to PROD.
*/
public static boolean isThrowable=false;   
public static void writeContents( java.io.OutputStream out, String obj, TransformationContext context )
throws java.io.IOException, TransformationException
  {
  try{
  		if(!isThrowable)
   			{
			if (context.writeToBuffer)
			context.appendToDataBuffer(obj);
			else
			{
			out.write(obj.getBytes());
			context.initDataBuffer();
			}
			}
   		else
   			out.write(obj.toString().getBytes());
   			
    	}catch(Throwable th)
    	{
    	isThrowable=true;   
    	out.write(obj.toString().getBytes());
    	}
  }
public static void writeContents( java.io.OutputStream out, Object obj, TransformationContext context )
throws java.io.IOException, TransformationException
  {
  try{
  		if(!isThrowable)
   			writeContents(  out,  String.valueOf(obj),  context );
   		else
   			out.write(obj.toString().getBytes());
   			
    	}catch(Throwable th)
    	{
    	isThrowable=true;   
    	out.write(obj.toString().getBytes());
    	}
  }   


}
