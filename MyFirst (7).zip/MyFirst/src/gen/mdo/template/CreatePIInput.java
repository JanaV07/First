package arch.amps_sipi.value;





public class CreatePIInput
  implements arch.value.ValueObject
{
private long __id;
public arch.amps_sipi.value.HeaderInfoPIType headerInfoPI;
public java.lang.Integer fedFundsCount;
public arch.amps_sipi.value.FedFundSIBlockType fedFundSIBlock;
public java.lang.Integer journalsCount;
public arch.amps_sipi.value.JournalsSIBlockType journalsSIBlock;
public java.lang.Integer checksCount;
public arch.amps_sipi.value.ChecksSIBlockType checksSIBlock;
public java.lang.Integer achCount;
public arch.amps_sipi.value.AchSIBlockType achSIBlock;
public java.lang.Integer nonUsdStandingInstructionCount;
public arch.amps_sipi.value.NonUSDSiCreateBlockType nonUsdStandingInstructionBlock;
public java.lang.Integer retirementTaxWithHoldingCount;
public arch.amps_sipi.value.RtwSIBlockType retirementTaxWitholdingStandingInstructionBlock;
public java.lang.Integer bankSendReceiveCount;
public arch.amps_sipi.value.BankSendReceiveType bankSendReceiveBlock;
public java.lang.Integer pamCount;
public arch.amps_sipi.value.PiInstructionDetailsType piInstructionDetails;
public arch.amps_sipi.value.PiTaxDetailsType piTaxDetails;
public java.lang.String rulesEngineIndicator;
public java.lang.String rulesEngineComment;
public java.lang.Integer ruleCount;
public java.util.List<arch.amps_sipi.value.RuleEngineErrorType> ruleEngineError;
public java.lang.Integer cusipCount;
public java.util.List<arch.amps_sipi.value.CusipBlockType> cusipBlock;
public java.lang.String feeAvailable;
public java.lang.Integer feeCount;
public java.util.List<arch.amps_sipi.value.FeeBlockType> feeBlock;

  static final long serialVersionUID = 1L;

  public CreatePIInput()
    {
      _initDefaults();
    }

  private void _initDefaults()
    {
    }



  public CreatePIInput(java.util.Map fields)
    throws arch.dabble.EvaluationException
    {
      fromObject(fields);
    }

  public CreatePIInput(arch.dabble.Attributable another)
    throws arch.dabble.EvaluationException
    {
      fromObject(another);
    }


  public void setHeaderInfoPI(arch.amps_sipi.value.HeaderInfoPIType headerInfoPI)
    {
      this.headerInfoPI = headerInfoPI;
    }

  public arch.amps_sipi.value.HeaderInfoPIType getHeaderInfoPI()
    {
      return headerInfoPI;
    }

  public void setFedFundsCount(java.lang.Integer fedFundsCount)
    {
      this.fedFundsCount = fedFundsCount;
    }

  public java.lang.Integer getFedFundsCount()
    {
      return fedFundsCount;
    }

  public void setFedFundSIBlock(arch.amps_sipi.value.FedFundSIBlockType fedFundSIBlock)
    {
      this.fedFundSIBlock = fedFundSIBlock;
    }

  public arch.amps_sipi.value.FedFundSIBlockType getFedFundSIBlock()
    {
      return fedFundSIBlock;
    }

  public void setJournalsCount(java.lang.Integer journalsCount)
    {
      this.journalsCount = journalsCount;
    }

  public java.lang.Integer getJournalsCount()
    {
      return journalsCount;
    }

  public void setJournalsSIBlock(arch.amps_sipi.value.JournalsSIBlockType journalsSIBlock)
    {
      this.journalsSIBlock = journalsSIBlock;
    }

  public arch.amps_sipi.value.JournalsSIBlockType getJournalsSIBlock()
    {
      return journalsSIBlock;
    }

  public void setChecksCount(java.lang.Integer checksCount)
    {
      this.checksCount = checksCount;
    }

  public java.lang.Integer getChecksCount()
    {
      return checksCount;
    }

  public void setChecksSIBlock(arch.amps_sipi.value.ChecksSIBlockType checksSIBlock)
    {
      this.checksSIBlock = checksSIBlock;
    }

  public arch.amps_sipi.value.ChecksSIBlockType getChecksSIBlock()
    {
      return checksSIBlock;
    }

  public void setAchCount(java.lang.Integer achCount)
    {
      this.achCount = achCount;
    }

  public java.lang.Integer getAchCount()
    {
      return achCount;
    }

  public void setAchSIBlock(arch.amps_sipi.value.AchSIBlockType achSIBlock)
    {
      this.achSIBlock = achSIBlock;
    }

  public arch.amps_sipi.value.AchSIBlockType getAchSIBlock()
    {
      return achSIBlock;
    }

  public void setNonUsdStandingInstructionCount(java.lang.Integer nonUsdStandingInstructionCount)
    {
      this.nonUsdStandingInstructionCount = nonUsdStandingInstructionCount;
    }

  public java.lang.Integer getNonUsdStandingInstructionCount()
    {
      return nonUsdStandingInstructionCount;
    }

  public void setNonUsdStandingInstructionBlock(arch.amps_sipi.value.NonUSDSiCreateBlockType nonUsdStandingInstructionBlock)
    {
      this.nonUsdStandingInstructionBlock = nonUsdStandingInstructionBlock;
    }

  public arch.amps_sipi.value.NonUSDSiCreateBlockType getNonUsdStandingInstructionBlock()
    {
      return nonUsdStandingInstructionBlock;
    }

  public void setRetirementTaxWithHoldingCount(java.lang.Integer retirementTaxWithHoldingCount)
    {
      this.retirementTaxWithHoldingCount = retirementTaxWithHoldingCount;
    }

  public java.lang.Integer getRetirementTaxWithHoldingCount()
    {
      return retirementTaxWithHoldingCount;
    }

  public void setRetirementTaxWitholdingStandingInstructionBlock(arch.amps_sipi.value.RtwSIBlockType retirementTaxWitholdingStandingInstructionBlock)
    {
      this.retirementTaxWitholdingStandingInstructionBlock = retirementTaxWitholdingStandingInstructionBlock;
    }

  public arch.amps_sipi.value.RtwSIBlockType getRetirementTaxWitholdingStandingInstructionBlock()
    {
      return retirementTaxWitholdingStandingInstructionBlock;
    }

  public void setBankSendReceiveCount(java.lang.Integer bankSendReceiveCount)
    {
      this.bankSendReceiveCount = bankSendReceiveCount;
    }

  public java.lang.Integer getBankSendReceiveCount()
    {
      return bankSendReceiveCount;
    }

  public void setBankSendReceiveBlock(arch.amps_sipi.value.BankSendReceiveType bankSendReceiveBlock)
    {
      this.bankSendReceiveBlock = bankSendReceiveBlock;
    }

  public arch.amps_sipi.value.BankSendReceiveType getBankSendReceiveBlock()
    {
      return bankSendReceiveBlock;
    }

  public void setPamCount(java.lang.Integer pamCount)
    {
      this.pamCount = pamCount;
    }

  public java.lang.Integer getPamCount()
    {
      return pamCount;
    }

  public void setPiInstructionDetails(arch.amps_sipi.value.PiInstructionDetailsType piInstructionDetails)
    {
      this.piInstructionDetails = piInstructionDetails;
    }

  public arch.amps_sipi.value.PiInstructionDetailsType getPiInstructionDetails()
    {
      return piInstructionDetails;
    }

  public void setPiTaxDetails(arch.amps_sipi.value.PiTaxDetailsType piTaxDetails)
    {
      this.piTaxDetails = piTaxDetails;
    }

  public arch.amps_sipi.value.PiTaxDetailsType getPiTaxDetails()
    {
      return piTaxDetails;
    }

  public void setRulesEngineIndicator(java.lang.String rulesEngineIndicator)
    {
      this.rulesEngineIndicator = rulesEngineIndicator;
    }

  public java.lang.String getRulesEngineIndicator()
    {
      return rulesEngineIndicator;
    }

  public void setRulesEngineComment(java.lang.String rulesEngineComment)
    {
      this.rulesEngineComment = rulesEngineComment;
    }

  public java.lang.String getRulesEngineComment()
    {
      return rulesEngineComment;
    }

  public void setRuleCount(java.lang.Integer ruleCount)
    {
      this.ruleCount = ruleCount;
    }

  public java.lang.Integer getRuleCount()
    {
      return ruleCount;
    }

  public void setRuleEngineError(java.util.List<arch.amps_sipi.value.RuleEngineErrorType> ruleEngineError)
    {
      this.ruleEngineError = ruleEngineError;
    }

  public java.util.List<arch.amps_sipi.value.RuleEngineErrorType> getRuleEngineError()
    {
      return ruleEngineError;
    }

  public void setCusipCount(java.lang.Integer cusipCount)
    {
      this.cusipCount = cusipCount;
    }

  public java.lang.Integer getCusipCount()
    {
      return cusipCount;
    }

  public void setCusipBlock(java.util.List<arch.amps_sipi.value.CusipBlockType> cusipBlock)
    {
      this.cusipBlock = cusipBlock;
    }

  public java.util.List<arch.amps_sipi.value.CusipBlockType> getCusipBlock()
    {
      return cusipBlock;
    }

  public void setFeeAvailable(java.lang.String feeAvailable)
    {
      this.feeAvailable = feeAvailable;
    }

  public java.lang.String getFeeAvailable()
    {
      return feeAvailable;
    }

  public void setFeeCount(java.lang.Integer feeCount)
    {
      this.feeCount = feeCount;
    }

  public java.lang.Integer getFeeCount()
    {
      return feeCount;
    }

  public void setFeeBlock(java.util.List<arch.amps_sipi.value.FeeBlockType> feeBlock)
    {
      this.feeBlock = feeBlock;
    }

  public java.util.List<arch.amps_sipi.value.FeeBlockType> getFeeBlock()
    {
      return feeBlock;
    }

  private static arch.transport.marshal.types.ValueTypeMarshaler __typeIO;
  protected arch.transport.marshal.types.ValueTypeMarshaler __getTypeIO()
    {
      if ( __typeIO == null )
        __typeIO = (arch.transport.marshal.types.ValueTypeMarshaler)
          arch.CORBA.marshal.Helper.getInstance().getValueTypeMarshaler(this);
      return __typeIO;
    }

                                                      

  public void setAttribute(String __name, Object __value)
    throws arch.dabble.EvaluationException
    {
      try
        {
            if ( __name.equals("headerInfoPI") )
            {
                      this.headerInfoPI = (arch.amps_sipi.value.HeaderInfoPIType)__value;
            }
              else if ( __name.equals("fedFundsCount") )
            {
                      this.fedFundsCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("fedFundSIBlock") )
            {
                      this.fedFundSIBlock = (arch.amps_sipi.value.FedFundSIBlockType)__value;
            }
              else if ( __name.equals("journalsCount") )
            {
                      this.journalsCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("journalsSIBlock") )
            {
                      this.journalsSIBlock = (arch.amps_sipi.value.JournalsSIBlockType)__value;
            }
              else if ( __name.equals("checksCount") )
            {
                      this.checksCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("checksSIBlock") )
            {
                      this.checksSIBlock = (arch.amps_sipi.value.ChecksSIBlockType)__value;
            }
              else if ( __name.equals("achCount") )
            {
                      this.achCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("achSIBlock") )
            {
                      this.achSIBlock = (arch.amps_sipi.value.AchSIBlockType)__value;
            }
              else if ( __name.equals("nonUsdStandingInstructionCount") )
            {
                      this.nonUsdStandingInstructionCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("nonUsdStandingInstructionBlock") )
            {
                      this.nonUsdStandingInstructionBlock = (arch.amps_sipi.value.NonUSDSiCreateBlockType)__value;
            }
              else if ( __name.equals("retirementTaxWithHoldingCount") )
            {
                      this.retirementTaxWithHoldingCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("retirementTaxWitholdingStandingInstructionBlock") )
            {
                      this.retirementTaxWitholdingStandingInstructionBlock = (arch.amps_sipi.value.RtwSIBlockType)__value;
            }
              else if ( __name.equals("bankSendReceiveCount") )
            {
                      this.bankSendReceiveCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("bankSendReceiveBlock") )
            {
                      this.bankSendReceiveBlock = (arch.amps_sipi.value.BankSendReceiveType)__value;
            }
              else if ( __name.equals("pamCount") )
            {
                      this.pamCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("piInstructionDetails") )
            {
                      this.piInstructionDetails = (arch.amps_sipi.value.PiInstructionDetailsType)__value;
            }
              else if ( __name.equals("piTaxDetails") )
            {
                      this.piTaxDetails = (arch.amps_sipi.value.PiTaxDetailsType)__value;
            }
              else if ( __name.equals("rulesEngineIndicator") )
            {
                      this.rulesEngineIndicator = (java.lang.String)__value;
            }
              else if ( __name.equals("rulesEngineComment") )
            {
                      this.rulesEngineComment = (java.lang.String)__value;
            }
              else if ( __name.equals("ruleCount") )
            {
                      this.ruleCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("ruleEngineError") )
            {
                      this.ruleEngineError = (java.util.List<arch.amps_sipi.value.RuleEngineErrorType>)__value;
            }
              else if ( __name.equals("cusipCount") )
            {
                      this.cusipCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("cusipBlock") )
            {
                      this.cusipBlock = (java.util.List<arch.amps_sipi.value.CusipBlockType>)__value;
            }
              else if ( __name.equals("feeAvailable") )
            {
                      this.feeAvailable = (java.lang.String)__value;
            }
              else if ( __name.equals("feeCount") )
            {
                      this.feeCount = (java.lang.Integer)__value;
            }
              else if ( __name.equals("feeBlock") )
            {
                      this.feeBlock = (java.util.List<arch.amps_sipi.value.FeeBlockType>)__value;
            }
            else if ( __name.equals("__id") )
            {
              this.__id = (Long)__value;
            }
          else
            {
              throw new arch.dabble.AttributeException(this, __name);
            }
        }
      catch ( ClassCastException e )
        {
          throw new arch.dabble
            .EvaluationException("invalid type for "
                                 + "attribute " + __name
                                 + ": " + __value.getClass().getName(),
                                 e);
        }
    }

  public Object getAttribute(String __name)
    throws arch.dabble.EvaluationException
    {
        if ( __name.equals("headerInfoPI") )
        {
          return headerInfoPI;
        }
          else if ( __name.equals("fedFundsCount") )
        {
          return fedFundsCount;
        }
          else if ( __name.equals("fedFundSIBlock") )
        {
          return fedFundSIBlock;
        }
          else if ( __name.equals("journalsCount") )
        {
          return journalsCount;
        }
          else if ( __name.equals("journalsSIBlock") )
        {
          return journalsSIBlock;
        }
          else if ( __name.equals("checksCount") )
        {
          return checksCount;
        }
          else if ( __name.equals("checksSIBlock") )
        {
          return checksSIBlock;
        }
          else if ( __name.equals("achCount") )
        {
          return achCount;
        }
          else if ( __name.equals("achSIBlock") )
        {
          return achSIBlock;
        }
          else if ( __name.equals("nonUsdStandingInstructionCount") )
        {
          return nonUsdStandingInstructionCount;
        }
          else if ( __name.equals("nonUsdStandingInstructionBlock") )
        {
          return nonUsdStandingInstructionBlock;
        }
          else if ( __name.equals("retirementTaxWithHoldingCount") )
        {
          return retirementTaxWithHoldingCount;
        }
          else if ( __name.equals("retirementTaxWitholdingStandingInstructionBlock") )
        {
          return retirementTaxWitholdingStandingInstructionBlock;
        }
          else if ( __name.equals("bankSendReceiveCount") )
        {
          return bankSendReceiveCount;
        }
          else if ( __name.equals("bankSendReceiveBlock") )
        {
          return bankSendReceiveBlock;
        }
          else if ( __name.equals("pamCount") )
        {
          return pamCount;
        }
          else if ( __name.equals("piInstructionDetails") )
        {
          return piInstructionDetails;
        }
          else if ( __name.equals("piTaxDetails") )
        {
          return piTaxDetails;
        }
          else if ( __name.equals("rulesEngineIndicator") )
        {
          return rulesEngineIndicator;
        }
          else if ( __name.equals("rulesEngineComment") )
        {
          return rulesEngineComment;
        }
          else if ( __name.equals("ruleCount") )
        {
          return ruleCount;
        }
          else if ( __name.equals("ruleEngineError") )
        {
          return ruleEngineError;
        }
          else if ( __name.equals("cusipCount") )
        {
          return cusipCount;
        }
          else if ( __name.equals("cusipBlock") )
        {
          return cusipBlock;
        }
          else if ( __name.equals("feeAvailable") )
        {
          return feeAvailable;
        }
          else if ( __name.equals("feeCount") )
        {
          return feeCount;
        }
          else if ( __name.equals("feeBlock") )
        {
          return feeBlock;
        }
            else if ( __name.equals("__id") )
            {
              return __id;
            }
      else 
        {
          throw new arch.dabble.AttributeException(this, __name);
        }
    }

  private static String[] __attributeNames = new String[]
    {
      "headerInfoPI",
      "fedFundsCount",
      "fedFundSIBlock",
      "journalsCount",
      "journalsSIBlock",
      "checksCount",
      "checksSIBlock",
      "achCount",
      "achSIBlock",
      "nonUsdStandingInstructionCount",
      "nonUsdStandingInstructionBlock",
      "retirementTaxWithHoldingCount",
      "retirementTaxWitholdingStandingInstructionBlock",
      "bankSendReceiveCount",
      "bankSendReceiveBlock",
      "pamCount",
      "piInstructionDetails",
      "piTaxDetails",
      "rulesEngineIndicator",
      "rulesEngineComment",
      "ruleCount",
      "ruleEngineError",
      "cusipCount",
      "cusipBlock",
      "feeAvailable",
      "feeCount",
      "feeBlock",
    };

  private static java.util.List<String> __attributeNamesList = 
    java.util.Collections.unmodifiableList(
        java.util.Arrays.asList(__attributeNames));

  public java.util.List<String> getAttributeNames ()
    throws arch.dabble.EvaluationException
    {
      return __attributeNamesList;
    }


  public boolean hasAttribute (String name)
    throws arch.dabble.EvaluationException
    {
      return __attributeNamesList.contains(name);
    }

  public void deleteAttribute (String name)
    throws arch.dabble.EvaluationException
    {
      throw new arch.dabble.EvaluationException("unsupported operation: deleteAttribute");
    }

  private static final String[] __ids =
    new String[] {
      "/arch/amps_sipi/value/CreatePIInput:1",
    };

  public String[] __ids()
    {
      return __ids;
    }

  public String getRepositoryKey()
    {
      return __ids[0];
    }

  
  public Object getValueObjectKey()
    {
      return new Integer(System.identityHashCode(this));
    }

  public void fromObject(Object object)
    throws arch.dabble.EvaluationException
    {
      __getTypeIO().fromObject(this, object);
    }

  public void toObject(Object object)
    throws arch.dabble.EvaluationException
    {
      __getTypeIO().toObject(this, object);
    }

  public static arch.value.ValueObject from(Object object)
    throws arch.dabble.EvaluationException
    {
      CreatePIInput res = new CreatePIInput();
      res.fromObject(object);
      return res;
    }

  
  public void _wasRead()
    {
    }
}
