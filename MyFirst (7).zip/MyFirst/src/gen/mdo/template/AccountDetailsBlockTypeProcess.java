/**
 * This is auto-generated via ValueProcess.vm template file in Web Service Framework
 * Please do not make modification to this file
 *
 */


package arch.amps_sipi.value;

import java.util.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import arch.transformation.*;
import arch.transformation.validation.*;
import arch.transformation.xml.*;
import arch.webservice.*;
import javax.xml.namespace.QName;
import java.text.SimpleDateFormat;
import arch.util.DateTime;
import arch.util.Date;
import java.math.BigDecimal;

import arch.webservice.soap.SOAPTransformationContext;
import arch.amps_sipi.value.AccountDetailsBlockType;


public class AccountDetailsBlockTypeProcess extends ObjectProcessImpl 
{
  private static arch.log.Log log = arch.log.Log.instance("ValueProcess");
  static final String isoDateTimeFormat =  "yyyy-MM-dd'T'HH:mm:ss" ;
  static final String isoDateFormat = "yyyy-MM-dd";
  private static final String NAMESPACE = "urn:pershing.amps_sipi.types";
  private String parentElement = null;
  private Object currentMapKey = null;
  public static final String href="href";
  public static final String xsnil="xsi:nil";
//  public static final String repeated="repeated";
//  public static final String item="item";
  public static final char sharp='#';
  public static final boolean bfalse=false,btrue=true;
                                                                                                                                                                                                                                                                                                                                                




  
  public AccountDetailsBlockTypeProcess() {

      
	 if(attriList ==null)
     {
     try{
     attriList=new AccountDetailsBlockType().getAttributeNames();
     }
     catch(Exception e)
     {
     }
  }

}
//#
  public Object newObject()
  {
     initObject();
     
     valueClassName = "accountDetailsBlockType"; 
     _internalData = new AccountDetailsBlockType();
	if(attriList ==null)
     {
     try
     {
     attriList=((AccountDetailsBlockType)_internalData).getAttributeNames();
     }
     catch(Exception e)
     {
     }
     }
	
     return _internalData;
  }

 //#
	String attrValue=null;
	 XmlStructureHandler handler =null;
	 boolean bTagInSchema = false;
  public XmlStructureHandler startChild(String namespace, String elementName, Attributes attributes, TransformationContext context)
    throws SAXException
  {
  
  			            handler = super.startChild(namespace, elementName, attributes, context);
	bTagInSchema = false;
      try{
   indx=attriList.indexOf(elementName);
   if(indx > -1)
   {
    switch (indx)
    {
     case 0: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p0 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p0.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p0.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p0);
			      attrValue=null;
			       return null;
   		   }
             return p0;
         }  // here
     case 1: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p1 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p1.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p1.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p1);
			      attrValue=null;
			       return null;
   		   }
             return p1;
         }  // here
     case 2: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p2 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p2.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p2.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p2);
			      attrValue=null;
			       return null;
   		   }
             return p2;
         }  // here
     case 3: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p3 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p3.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p3.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p3);
			      attrValue=null;
			       return null;
   		   }
             return p3;
         }  // here
     case 4: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p4 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p4.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p4.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p4);
			      attrValue=null;
			       return null;
   		   }
             return p4;
         }  // here
     case 5: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p5 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p5.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p5.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p5);
			      attrValue=null;
			       return null;
   		   }
             return p5;
         }  // here
     case 6: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p6 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p6.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p6.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p6);
			      attrValue=null;
			       return null;
   		   }
             return p6;
         }  // here
     case 7: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p7 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p7.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p7.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p7);
			      attrValue=null;
			       return null;
   		   }
             return p7;
         }  // here
     case 8: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p8 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p8.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p8.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p8);
			      attrValue=null;
			       return null;
   		   }
             return p8;
         }  // here
     case 9: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p9 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p9.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p9.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p9);
			      attrValue=null;
			       return null;
   		   }
             return p9;
         }  // here
     case 10: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p10 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p10.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p10.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p10);
			      attrValue=null;
			       return null;
   		   }
             return p10;
         }  // here
     case 11: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p11 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p11.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p11.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p11);
			      attrValue=null;
			       return null;
   		   }
             return p11;
         }  // here
     case 12: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p12 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p12.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p12.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p12);
			      attrValue=null;
			       return null;
   		   }
             return p12;
         }  // here
     case 13: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p13 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p13.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p13.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p13);
			      attrValue=null;
			       return null;
   		   }
             return p13;
         }  // here
     case 14: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p14 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p14.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p14.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p14);
			      attrValue=null;
			       return null;
   		   }
             return p14;
         }  // here
     case 15: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p15 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p15.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p15.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p15);
			      attrValue=null;
			       return null;
   		   }
             return p15;
         }  // here
     case 16: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p16 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p16.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p16.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p16);
			      attrValue=null;
			       return null;
   		   }
             return p16;
         }  // here
     case 17: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p17 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p17.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p17.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p17);
			      attrValue=null;
			       return null;
   		   }
             return p17;
         }  // here
     case 18: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p18 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p18.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p18.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p18);
			      attrValue=null;
			       return null;
   		   }
             return p18;
         }  // here
     case 19: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p19 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p19.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p19.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p19);
			      attrValue=null;
			       return null;
   		   }
             return p19;
         }  // here
     case 20: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p20 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p20.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p20.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p20);
			      attrValue=null;
			       return null;
   		   }
             return p20;
         }  // here
     case 21: 
       bTagInSchema = true;
      	arch.transformation.xml.StringProcess p21 = new arch.transformation.xml.StringProcess();
         if (attributes.getIndex(xsnil) != -1) 
            return null;
         else {
         p21.newObject();
             if (attributes.getIndex(href) != -1 && attributes.getValue(href).charAt(0) == sharp)
		      {
			      attrValue = attributes.getValue(href);
			      p21.setParent(this);
			      ((ObjectTransformationContext)context).setHandlerForMultiRefId(attrValue.substring(1, attrValue.length()), p21);
			      attrValue=null;
			       return null;
   		   }
             return p21;
         }  // here
}
    }
    }
    catch(Exception e)
    {
    	log.error("Error in startChild:"+e.getMessage());
    }
   if (bTagInSchema == false && handler == null) {
       //super.validate(elementName, bTagInSchema); 
       //PN. Commented above code to safeguard against code built with new core package. 
       ValidationHelper.setValidationStatus("Undefined tag name [" + elementName + "] encountered from request. Please check schema documentation. \n");
    }
    return handler;
  }
  
  public void startElement(String namespace, String elementName, Attributes attributes, TransformationContext context)
    throws SAXException
  {    
    super.startElement(namespace, elementName, attributes, context);    
    AccountDetailsBlockType     value = (AccountDetailsBlockType)_internalData;
    // Handle List , Map  and Attachment 
      }
  
  public void endElement(String namespace, String elementName, String contents, TransformationContext context)
      throws SAXException
  {
  	super.endElement(namespace, elementName, contents, context);
  	super.endChild( namespace, elementName, contents, context);
  	

  	
                                                                                                                                                                                                         
  }
  
  public void endChild(String namespace, String elementName, String contents, TransformationContext context)
    throws SAXException
  {
        super.endChild( namespace, elementName, contents, context);
    AccountDetailsBlockType value = (AccountDetailsBlockType)_internalData;
    // Handling Object memebers
    // Handling List items and Map key value pairs
  }
AccountDetailsBlockType value = null;
public static java.util.List<String> attriList=null;
int indx=-1;
  public void endStructuredChild(String namespace, String elementName, XmlStructureHandler handler, TransformationContext context)
    throws SAXException
  {
    //AccountDetailsBlockType 
    value = (AccountDetailsBlockType)_internalData;
                     try{
   indx=attriList.indexOf(elementName);
   if(indx > -1)
   {
    switch (indx)
    {
	 case 0:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setUserId((java.lang.String)pString.getObject());
          break;
          	 case 1:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setInitiatorType((java.lang.String)pString.getObject());
          break;
          	 case 2:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAmpsMode((java.lang.String)pString.getObject());
          break;
          	 case 3:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setDescription((java.lang.String)pString.getObject());
          break;
          	 case 4:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setRequestType((java.lang.String)pString.getObject());
          break;
          	 case 5:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setSequenceNumber((java.lang.String)pString.getObject());
          break;
          	 case 6:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountNumber((java.lang.String)pString.getObject());
          break;
          	 case 7:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountRegistrationType((java.lang.String)pString.getObject());
          break;
          	 case 8:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountName((java.lang.String)pString.getObject());
          break;
          	 case 9:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setJointAccountName((java.lang.String)pString.getObject());
          break;
          	 case 10:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountAddressLine1((java.lang.String)pString.getObject());
          break;
          	 case 11:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountAddressLine2((java.lang.String)pString.getObject());
          break;
          	 case 12:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountAddressLine3((java.lang.String)pString.getObject());
          break;
          	 case 13:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountAddressLine4((java.lang.String)pString.getObject());
          break;
          	 case 14:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountRetirementPlanType((java.lang.String)pString.getObject());
          break;
          	 case 15:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountRetirmentPlanTypeDesc((java.lang.String)pString.getObject());
          break;
          	 case 16:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountRetirementAccountType((java.lang.String)pString.getObject());
          break;
          	 case 17:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setAccountRetirementAccountTypeDesc((java.lang.String)pString.getObject());
          break;
          	 case 18:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setEnterpriseId((java.lang.String)pString.getObject());
          break;
          	 case 19:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setSiStatus((java.lang.String)pString.getObject());
          break;
          	 case 20:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setRePaperingExpirationDateFlag((java.lang.String)pString.getObject());
          break;
          	 case 21:
	 	                                   //2 .Tyep
         pString =(arch.transformation.xml.StringProcess)handler; //the process class..
                                   				 				       value.setRePaperingExpirationDate((java.lang.String)pString.getObject());
          break;
          	}
    }
    }
    catch(Exception e)
    {
    log.error("Error in endStructuredChild:"+e.getMessage());		
//	e.printStackTrace();
    }























  }
  
  public void serializeRPCStyle( java.io.OutputStream out, QName name, Object object, TransformationContext context)
    throws java.io.IOException, TransformationException
  {
    if(object == null)
      return;
    boolean bOuterTagRequired = false;
    
    AccountDetailsBlockType valObj = (AccountDetailsBlockType)object;
    UrlPrefixRegistry reg = (UrlPrefixRegistry)context.getAttribute(TransformationContext.PREFIX_REGISTRY);
    String pfx = reg.getPrefix(NAMESPACE);
    StringBuffer outContent = new StringBuffer("");
    
    if (name!= null && !name.getLocalPart().trim().equals("")) {
       bOuterTagRequired = true;
    }
    
    if (bOuterTagRequired) {
       outContent.append("<");
       outContent.append(name.getLocalPart());
    }
    
    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	    	        
    if (bOuterTagRequired) {
        outContent.append(" xsi:type=\"").append(pfx).append(":AccountDetailsBlockType\"").append(" xmlns:").append(pfx)
        .append("=\"").append(NAMESPACE).append("\">");
    }
    
    out.write(outContent.toString().getBytes());
    outContent = null;
    serializeChildren(out, name, object, context);        

    // serialize super	 
    if (bOuterTagRequired) {
       out.write(("</" + name.getLocalPart() + ">").getBytes());
    }
  }

  public void serializeDocStyle( java.io.OutputStream out, QName name, Object object, TransformationContext context)
    throws java.io.IOException, TransformationException
  {
    if(object == null)
      return;
    boolean bOuterTagRequired  = false;
    
    AccountDetailsBlockType valObj = (AccountDetailsBlockType)object;  

    StringBuilder outContent = new StringBuilder("");
    
    if (name!= null && !name.getLocalPart().trim().equals("")) {
       bOuterTagRequired = true;
    }
    if (bOuterTagRequired) {
        outContent = new StringBuilder("<");
        outContent.append(name.getLocalPart());

    }
   
    if(bOuterTagRequired && (name.getNamespaceURI() != null && !name.getNamespaceURI().equals("")))
    {
        //PN. 07/15/2008. Prevent other services to fail when built against new code.  
        boolean version2 = false;
       
		if(arch.transformation.xml.XMLTransformation.getImplVersion().equals("2"))
		    version2 = true;
        
        if (!version2) 
           outContent.append(" xmlns=\"").append(name.getNamespaceURI()).append("\"");

    }

    
    if (bOuterTagRequired) {  


                  	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                 	                  // $ForceNameSpace
        



        outContent.append(">");

                                                                      }

    writeContents(out,outContent.toString(),context);
    outContent = null;
    // serialize children
    serializeChildren(out, name, object, context);
    if (bOuterTagRequired) {        
       //out.write(("</" + name.getLocalPart() + ">").getBytes());    
	   writeContents(out,("</" + name.getLocalPart() + ">"),context);

    }
  }
  
private static final String userId="userId";
private static final QName quserId=new QName(NAMESPACE, userId);
static final ObjectProcessInterface objectProcessString = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
static final boolean bProcessString = objectProcessString !=null ? true :false;
static final String strString = "String" ;
//lowerFirstLetter
       arch.transformation.xml.StringProcess pString = null;//new arch.transformation.xml.StringProcess();
       // pString.setParent(this);
private static final String initiatorType="initiatorType";
private static final QName qinitiatorType=new QName(NAMESPACE, initiatorType);
private static final String ampsMode="ampsMode";
private static final QName qampsMode=new QName(NAMESPACE, ampsMode);
private static final String description="description";
private static final QName qdescription=new QName(NAMESPACE, description);
private static final String requestType="requestType";
private static final QName qrequestType=new QName(NAMESPACE, requestType);
private static final String sequenceNumber="sequenceNumber";
private static final QName qsequenceNumber=new QName(NAMESPACE, sequenceNumber);
private static final String accountNumber="accountNumber";
private static final QName qaccountNumber=new QName(NAMESPACE, accountNumber);
private static final String accountRegistrationType="accountRegistrationType";
private static final QName qaccountRegistrationType=new QName(NAMESPACE, accountRegistrationType);
private static final String accountName="accountName";
private static final QName qaccountName=new QName(NAMESPACE, accountName);
private static final String jointAccountName="jointAccountName";
private static final QName qjointAccountName=new QName(NAMESPACE, jointAccountName);
private static final String accountAddressLine1="accountAddressLine1";
private static final QName qaccountAddressLine1=new QName(NAMESPACE, accountAddressLine1);
private static final String accountAddressLine2="accountAddressLine2";
private static final QName qaccountAddressLine2=new QName(NAMESPACE, accountAddressLine2);
private static final String accountAddressLine3="accountAddressLine3";
private static final QName qaccountAddressLine3=new QName(NAMESPACE, accountAddressLine3);
private static final String accountAddressLine4="accountAddressLine4";
private static final QName qaccountAddressLine4=new QName(NAMESPACE, accountAddressLine4);
private static final String accountRetirementPlanType="accountRetirementPlanType";
private static final QName qaccountRetirementPlanType=new QName(NAMESPACE, accountRetirementPlanType);
private static final String accountRetirmentPlanTypeDesc="accountRetirmentPlanTypeDesc";
private static final QName qaccountRetirmentPlanTypeDesc=new QName(NAMESPACE, accountRetirmentPlanTypeDesc);
private static final String accountRetirementAccountType="accountRetirementAccountType";
private static final QName qaccountRetirementAccountType=new QName(NAMESPACE, accountRetirementAccountType);
private static final String accountRetirementAccountTypeDesc="accountRetirementAccountTypeDesc";
private static final QName qaccountRetirementAccountTypeDesc=new QName(NAMESPACE, accountRetirementAccountTypeDesc);
private static final String enterpriseId="enterpriseId";
private static final QName qenterpriseId=new QName(NAMESPACE, enterpriseId);
private static final String siStatus="siStatus";
private static final QName qsiStatus=new QName(NAMESPACE, siStatus);
private static final String rePaperingExpirationDateFlag="rePaperingExpirationDateFlag";
private static final QName qrePaperingExpirationDateFlag=new QName(NAMESPACE, rePaperingExpirationDateFlag);
private static final String rePaperingExpirationDate="rePaperingExpirationDate";
private static final QName qrePaperingExpirationDate=new QName(NAMESPACE, rePaperingExpirationDate);
//  AccountDetailsBlockType valObj = null;

  public void serializeChildren(java.io.OutputStream out, QName name, Object object, TransformationContext context)
    throws java.io.IOException, TransformationException
  {



	// ObjectProcessInterface objectProcess;
     AccountDetailsBlockType valObj = (AccountDetailsBlockType)object;

   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, quserId, valObj.getUserId(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qinitiatorType, valObj.getInitiatorType(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qampsMode, valObj.getAmpsMode(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qdescription, valObj.getDescription(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qrequestType, valObj.getRequestType(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qsequenceNumber, valObj.getSequenceNumber(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountNumber, valObj.getAccountNumber(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountRegistrationType, valObj.getAccountRegistrationType(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountName, valObj.getAccountName(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qjointAccountName, valObj.getJointAccountName(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountAddressLine1, valObj.getAccountAddressLine1(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountAddressLine2, valObj.getAccountAddressLine2(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountAddressLine3, valObj.getAccountAddressLine3(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountAddressLine4, valObj.getAccountAddressLine4(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountRetirementPlanType, valObj.getAccountRetirementPlanType(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountRetirmentPlanTypeDesc, valObj.getAccountRetirmentPlanTypeDesc(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountRetirementAccountType, valObj.getAccountRetirementAccountType(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qaccountRetirementAccountTypeDesc, valObj.getAccountRetirementAccountTypeDesc(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qenterpriseId, valObj.getEnterpriseId(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qsiStatus, valObj.getSiStatus(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qrePaperingExpirationDateFlag, valObj.getRePaperingExpirationDateFlag(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   //  objectProcess = ObjectProcessRegistry.getProcessRegistry("java.lang.String");
//if(  bProcessString)
{

	

	     objectProcessString.serialize(out, qrePaperingExpirationDate, valObj.getRePaperingExpirationDate(), context);
		       } //    else
 //       log.warning("Unable to find the object process for - java.lang.String skipping serialization for this");
   }
/*Arun:
*Need this to support the builds against the new core until the core change is promoted to PROD.
*/
public static boolean isThrowable=false;   
public static void writeContents( java.io.OutputStream out, String obj, TransformationContext context )
throws java.io.IOException, TransformationException
  {
  try{
  		if(!isThrowable)
   			{
			if (context.writeToBuffer)
			context.appendToDataBuffer(obj);
			else
			{
			out.write(obj.getBytes());
			context.initDataBuffer();
			}
			}
   		else
   			out.write(obj.toString().getBytes());
   			
    	}catch(Throwable th)
    	{
    	isThrowable=true;   
    	out.write(obj.toString().getBytes());
    	}
  }
public static void writeContents( java.io.OutputStream out, Object obj, TransformationContext context )
throws java.io.IOException, TransformationException
  {
  try{
  		if(!isThrowable)
   			writeContents(  out,  String.valueOf(obj),  context );
   		else
   			out.write(obj.toString().getBytes());
   			
    	}catch(Throwable th)
    	{
    	isThrowable=true;   
    	out.write(obj.toString().getBytes());
    	}
  }   


}
