package gen.odsc;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import item.Header;
import item.ItemBase;
import item.TypeData;
import javafx.collections.ObservableList;

/**
 *
 * 
 * @author VJanarthanan
 */
public class ODSCGenerator {
	private  Header header = null;
	public  HashMap<String, TypeData> completeTypeMap = new HashMap<String, TypeData>(); // contains all the types
																								// and typeData of
																								// corresponding type
																								// inside that package
	public  LinkedHashMap<String, ItemBase> completeItems = new LinkedHashMap<String, ItemBase>(); // Containg all
																											// the items
																											// to ODSC
																											// <Name,ItemBase>
	public  ObservableList<String> fieldTypeList = null; // contains the types inside package
	private  String packageName;
	public String type;
	private  String functionName;
	private  ObservableList<ItemBase> observableitemList;
	private  String ocurs;

	public ODSCGenerator(String type,String packageName, String functionName, Header header, String occurs,ObservableList<String> fieldTypeList, ObservableList<ItemBase> observableitemList,
			HashMap<String, TypeData> completeTypeMap) {
		this.type=type;
		this.packageName = packageName;
		this.functionName = functionName;
		this.header = header;
		this.ocurs = occurs;
		this.fieldTypeList = fieldTypeList;
		this.observableitemList = observableitemList;
		this.completeTypeMap = completeTypeMap;

	}

	public static String makeFirstLetterCapital(String input) {
		input = input.toLowerCase();
		return input.substring(0, 1).toUpperCase() + input.substring(1);

	}
	public static String makeOnlyFirstLetterCapital(String input) {
		input = input.toLowerCase();
		if (!input.contains("|"))
			return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
		else {
			String str = "";
			String[] in = input.split("\\|");
			for (int i = 0; i < in.length; i++) {
				System.out.println(in[i]);
				str = str + makeOnlyFirstLetterCapital(in[i]);
			}
			return str;

		}
	}

	public static String getFieldAttribute(ItemBase item, int initial, String type) {
		String name = item.getName(), size = item.getSize(), format = item.getFormat();
		if (format.length() > 0)
			return "      new OdscMetaData(\"" + item.getName() + "\"," + initial + "," + (Integer.parseInt(size))
					+ ",\'" + type + "\',\'" + item.getFormat() + "\'),\n";
		else
			return "      new OdscMetaData(\"" + item.getName() + "\"," + initial + "," + (Integer.parseInt(size))
					+ ",\'" + type + "\'),\n";
	}

	public  String retrieveType(ItemBase item) {
		String type;
		if (fieldTypeList.contains(item.getType()))
			type = "x";
		else if (item.getType().equals("String"))
			type = "s";
		else if (item.getType().contains("Reserved"))
			type = "r";
		else if (item.getType().contains("Integer"))
			type = "i";
		else if (item.getType().contains("Decimal"))
			type = "d";
		else if (item.getType().equals("Date"))
			type = "e";
		else if (item.getType().contains("Date"))
			type = "g";
		else if (item.getType().equals("Time"))
			type = "t";
		else if (item.getType().contains("Time"))
			type = "h";
		else if (item.getType().contains("Long"))
			type = "l";
		else
			type = "undefined";
		return type;
	}

	public  String generateInputODSC() {
		completeItems.clear();
		System.out.println("INSIDE **********generateInputODSC*********");
		StringBuffer buf = new StringBuffer();
		System.out.println("PACKAGE NAME : :" + packageName);
		System.out.println("FUnction NAme : :" + functionName);
		String importStatemnt = "package arch.webservice.pdoservices." + packageName
				+ ".inparm;\nimport arch.webservice.odsc.*;" ;
		String className="";
		if(type.equals("input")){
				className="\npublic class " + makeFirstLetterCapital(functionName)
				+ "_In extends MqMessage{";
		}
		else className="\npublic class " + makeFirstLetterCapital(functionName)
		+ "_Out extends MqMessage{";
		String constructor= "\nprivate final static OdscMetaData[] parameterInfo = new OdscMetaData[] {\n";
		buf.append(importStatemnt+className+constructor);
		int j = 0;
		for (int i = 0; i < observableitemList.size(); i++) {
			ItemBase item = observableitemList.get(i);
			String type = retrieveType(item);

			if (fieldTypeList.contains(item.getType())) {
				// type = "x";
				System.out.println(item.getType());
				// System.out.println(completeTypeMap);
				TypeData typeData = completeTypeMap.get(item.getType());
				System.out.println(completeTypeMap.get(item.getType()));
				System.out.println(typeData.size);

				buf.append(getFieldAttribute(item, j, type));
				/*
				 * buf.append("      new OdscMetaData(\"" + item.getName() + "\"," + j + "," +
				 * (Integer.parseInt(item.getSize())) + ",\'" + type + "\'),\n");
				 */
				completeItems.put(item.getName(), item);
				buf = retrieveTypeFields(item.getName(), j, typeData, buf);
				// buf.append(retrieveTypeFields(j,typeData,buf));
				j = j + typeData.getSize();
			} else {

				completeItems.put(item.getName(), item);

				buf.append(getFieldAttribute(item, j, type));

				j = j + Integer.parseInt((item.getSize()));
			}
		}
		buf.append("};\nprivate static final int\n");
		Iterator i;
		if (completeItems != null) {
			i = completeItems.entrySet().iterator();
			for (int k = 0; i.hasNext() && i != null; k++) {
				// while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				String key = (String) entry.getKey();
				key = key.replace("|", "");
				buf.append("$" + key.toUpperCase() + "=" + k + ",\n");
				// buf.append(arg0)
			}
		}

		/*
		 * for (int i = 0; i < completeInputItems.size(); i++) { buf.append("$" +
		 * completeInputItems.get(i).getName().toUpperCase() + "=" + i + ",\n"); }
		 */
		buf.append("$LENGTH = " + j + ";\n");
		buf.append(retrieveHeader());
		buf.append(retrieveOccurs());
		buf.append(retrieveGetters());
		buf.append(retrieveSetters(completeItems));
		buf.append("\n}");
		System.out.println(header.getAuthor());
		HashMap<String, String> headerMap = header.getAllElements();
		System.out.println(header.getAllElements());
		System.out.println("EXITNING *********generateInputODSC*************");
		System.out.println(completeItems);
		return buf.toString();
	}

	private  Object retrieveSetters(LinkedHashMap<String, ItemBase> completeInputItems) {
		String str = "";
		Iterator i;
		if (completeInputItems != null) {
			i = completeInputItems.entrySet().iterator();
			for (int k = 0; i.hasNext() && i != null; k++) {
				// while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				String key = (String) entry.getKey();
				ItemBase item = (ItemBase) entry.getValue();
				String type;
				if (fieldTypeList.contains(item.getType()))
					type = "block";
				else if (item.getType().equals("String"))
					type = "String";
				else if (item.getType().contains("Integer"))
					type = "int";
				else if (item.getType().contains("Decimal"))
					type = "decimal";
				else if (item.getType().equals("Date"))
					type = "e";
				else if (item.getType().contains("Date"))
					type = "g";
				else if (item.getType().equals("Time"))
					type = "t";
				else if (item.getType().contains("Time"))
					type = "h";
				else
					type = "undefined";

				System.out.println("key: : :: : : : : : : :" + key);
				// key=key.replace("|", "");
				if (!type.equals("block")) {
					String value = key.replace("|", "");
					String head = getHead(key);
					System.out.println("HEAD : : : : :: : " + head);
					System.out.println(value);
					if(key.contains("|")) {
					str = str + "public void set" + makeOnlyFirstLetterCapital(key) + "(" + type
							+ " value) throws OdscException {\r\n" + "		setValue($" + head.toUpperCase() + ",$"
							+ value.toUpperCase() + ",0,value);\r\n" + "	}\r\n";
					}
					else
						str = str + "public void set" + makeOnlyFirstLetterCapital(key) + "(" + type
						+ " value) throws OdscException {\r\n" + "		setValue($"
						+ value.toUpperCase() + ",value);\r\n" + "	}\r\n";
				} else {
					String value = key.replace("|", "");
					if(key.contains("|")) {
					str = str + "public void set" + makeOnlyFirstLetterCapital(key)
							+ "(String[] value) throws OdscException {\r\n" + "		setValue($" + value.toUpperCase()
							+ ",0,value);\r\n" + "	}\r\n";
					}
					else
						str = str + "public void set" + makeOnlyFirstLetterCapital(key)
						+ "(String[] value) throws OdscException {\r\n" + "		setValue($" + value.toUpperCase()
						+ ",value);\r\n" + "	}\r\n";
				}
				// buf.append("$" + key.toUpperCase()+ "=" + k + ",\n");
				// buf.append(arg0)
			}
		}
		return str;
	}

	private static String getHead(String input) {
		String str = "";
		String[] in = input.split("\\|");
		for (int i = 0; i < (in.length - 1); i++) {
			System.out.println(in[i]);
			str = str + in[i];
		}
		return str;

	}

	public  String retrieveGetters() {
		String str = "public String getSystemId(){\r\n" + "		return SystemId;\r\n" + "	}\r\n"
				+ "public String getReqType(){\r\n" + "		return ReqType;\r\n" + "	}\r\n"
				+ "public String getTag(){\r\n" + "		return Tag;\r\n" + "	}\r\n"
				+ "public String getNullString(){\r\n" + "		return NullString;\r\n" + "	}\r\n"
				+ "public String getFunctionName(){\r\n" + "		return Name;\r\n" + "	}\r\n"
				+ "public char getMinOccurs(){\r\n" + "		return MinOccurs;\r\n" + "	}\r\n"
				+ "public char getMaxOccurs(){\r\n" + "		return MaxOccurs;\r\n" + "	}\r\n" + "public "
				+ makeFirstLetterCapital(functionName) + "_In(){\r\n" + "		super($LENGTH);\r\n"
				+ "		metaData = parameterInfo;\r\n" + "	}\r\n" + "public void init() throws OdscException {\r\n"
				+ "	}\r\n";
		return str;
	}

	public  String retrieveOccurs() {
		String str = "private static final char\r\n";
		String occurs = ocurs;
		System.out.println(occurs);
		String min = occurs.charAt(0) + "";
		String max = occurs.charAt((occurs.length() - 1)) + "";
		if (max.equals("N"))
			max = "*";

		System.out.println(min);
		System.out.println(max);
		str = str + "            MinOccurs = \'" + min + "\',\n";
		str = str + "            MaxOccurs = \'" + max + "\';\n";
		return str;
	}

	public  String retrieveHeader() {
		HashMap<String, String> headerMap = header.getAllElements();
		String str = "private static final String\r\n";
		if (headerMap.get("systemid")!=null && headerMap.get("systemid").length() > 0) {
			str = str + "            SystemId =\"" + headerMap.get("systemid") + "\",\n";
		} else
			str = str + "            SystemId = \"\",\n";
		if (headerMap.get("requesttype")!=null && headerMap.get("requesttype").length() > 0) {
			str = str + "            ReqType  =\"" + headerMap.get("requesttype") + "\",\n";
		} else
			str = str + "			 ReqType = \"\",\n";
		if (headerMap.get("tag")!=null && headerMap.get("tag").length() > 0) {
			str = str + "            Tag  =\"" + headerMap.get("tag") + "\",\n";
		} else
			str = str + "			 Tag = \"\",\n";
		if (headerMap.get("nullString")!=null && headerMap.get("nullString").length() > 0) {
			str = str + "            NullString =\"" + headerMap.get("nullString") + "\";\n";
		} else
			str = str + "			 NullString = \"\",\n";
		if (headerMap.get("functionKey")!=null && headerMap.get("functionKey").length() > 0) {
			str = str + "            Name =\"" + headerMap.get("functionKey") + "\";\n";
		} else
			str = str + "			 Name = \"\";\n";
		System.out.println(str);
		return str;
	}

	public StringBuffer retrieveTypeFields(String fieldName, int j, TypeData typeData, StringBuffer buf) {
		int i = 0;
		for (ItemBase item : typeData.itemList) {
			String type;
			type = retrieveType(item);
			/*
			 * if (item.getType().equals("String")) type = "s"; else if
			 * (item.getType().equals("Integer")) type = "i"; else type = "undefined";
			 */
			if (fieldTypeList.contains(item.getType())) {
				type = "x";
				System.out.println("____________");
				System.out.println(item.getType());
				System.out.println(completeTypeMap);
				TypeData typeData1 = completeTypeMap.get(item.getType());
				System.out.println(completeTypeMap.get(item.getType()));
				System.out.println(typeData1.size);
				completeItems.put(fieldName + "|" + item.getName(), item);
				buf.append(getFieldAttribute(item, i, type));
				buf = retrieveTypeFields(fieldName + "|" + item.getName(), i, typeData1, buf);
				// buf.append(retrieveTypeFields(j,typeData,buf));
				i = i + typeData.getSize();
			} else {
				/*
				 * if (item.getType().equals("String")) type = "s"; else if
				 * (item.getType().equals("Integer")) type = "i"; else type = "undefined";
				 */

				buf.append(getFieldAttribute(item, i, type));
				/*
				 * buf.append("      new OdscMetaData(\"" + item.getName() + "\"," + i + "," +
				 * (Integer.parseInt(item.getSize())) + ",\'" + type + "\'),\n");
				 */
				i = i + Integer.parseInt(item.getSize());
			}
			System.out.println(fieldName + "|" + item.getName());
			completeItems.put(fieldName + "|" + item.getName(), item);
		}
		return buf;
	}
}