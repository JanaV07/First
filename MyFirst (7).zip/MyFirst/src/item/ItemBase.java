package item;

import java.util.HashMap;

import org.w3c.dom.Element;
/**
*
* 
* @author VJanarthanan
*/
public class ItemBase {
public String name;
public String type;
public String size;
public String required;
public String nillable;
public String attribute;
public String description;
public String maxOccurs;
public String precision;
public String functionOccurs;
public String totalSize;
public String format;
public Element element;

@Override
public String toString()
{
	return "Name :: :"+name+"::format::"+format+"::size::"+size;
}
public String getFormat() {
	return format;
}
public void setFormat(String format) {
	this.format = format;
}
public String getTotalSize() {
	return totalSize;
}
public void setTotalSize(String totalSize) {
	this.totalSize = totalSize;
}
public Element getElement() {
	return element;
}
public void setElement(Element element) {
	this.element = element;
}
HashMap<String, String> allAttributes;

public String getMaxOccurs() {
	return maxOccurs;
}
public void setMaxOccurs(String maxOccurs) {
	this.maxOccurs = maxOccurs;
}
public String getPrecision() {
	return precision;
}
public void setPrecision(String precision) {
	this.precision = precision;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getSize() {
	return size;
}
public void setSize(String size) {
	this.size = size;
}
public String getRequired() {
	return required;
}
public void setRequired(String required) {
	this.required = required;
}
public String getNillable() {
	return nillable;
}
public void setNillable(String nillable) {
	this.nillable = nillable;
}
public String getAttribute() {
	return attribute;
}
public void setAttribute(String attribute) {
	this.attribute = attribute;
}
public HashMap<String, String> getAllAttributes() {
	return allAttributes;
}
public void setAllAttributes(HashMap<String, String> allAttributes) {
	this.allAttributes = allAttributes;
}
}
