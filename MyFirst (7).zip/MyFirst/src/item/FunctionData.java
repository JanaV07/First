package item;

import java.util.HashMap;
import java.util.List;
/**
*
* 
* @author VJanarthanan
*/
public class FunctionData {
	public Header header;
	public List<ItemBase> inputItemList;
	public List<ItemBase> outputItemList;
	public String inputOccurs;
	public String outputOccurs;
	public HashMap<String, String> headerMap;
	public String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public HashMap<String, String> getHeaderMap() {
		return headerMap;
	}

	public void setHeaderMap(HashMap<String, String> headerMap) {
		this.headerMap = headerMap;
	}
	public String getOutputOccurs() {
		return outputOccurs;
	}
	public void setOutputOccurs(String outputOccurs) {
		this.outputOccurs = outputOccurs;
	}
	public String getInputOccurs() {
		return inputOccurs;
	}
	public void setInputOccurs(String occurs) {
		this.inputOccurs = occurs;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public List<ItemBase> getInputItemList() {
		return inputItemList;
	}
	public void setInputItemList(List<ItemBase> inputItemList) {
		this.inputItemList = inputItemList;
	}
	public List<ItemBase> getOutputItemList() {
		return outputItemList;
	}
	public void setOutputItemList(List<ItemBase> outputItemList) {
		this.outputItemList = outputItemList;
	}
	
}
