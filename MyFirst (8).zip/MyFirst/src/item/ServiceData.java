package item;

import java.util.HashMap;
import java.util.List;
/**
*
* 
* @author VJanarthanan
*/
public class ServiceData {
	public Header header;
	public List<ItemBase> inputItemList;
	public List<ItemBase> outputItemList;
	public HashMap<String,String> headerMap;
	public String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public HashMap<String, String> getHeaderMap() {
		return headerMap;
	}
	public void setHeaderMap(HashMap<String, String> headerMap) {
		this.headerMap = headerMap;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public List<ItemBase> getInputItemList() {
		return inputItemList;
	}
	public void setInputItemList(List<ItemBase> inputItemList) {
		this.inputItemList = inputItemList;
	}
	public List<ItemBase> getOutputItemList() {
		return outputItemList;
	}
	public void setOutputItemList(List<ItemBase> outputItemList) {
		this.outputItemList = outputItemList;
	}
	
}
