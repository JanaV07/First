package item;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import org.w3c.dom.Element;
/**
*
* 
* @author VJanarthanan
*/
public class ItemBase {
public String name;
public String type;
public String size;
public String required;
public String nillable;
public String attribute;
public String description;
public String maxOccurs;
public String precision;
public String functionOccurs;
public String totalSize;
public String format;
public Element element;
public HashMap fieldPropertyMap=null;
HashMap<String, String> allAttributes;

public HashMap getPropertyMap() {
	System.out.println("Retreiveing property Map1");
	fieldPropertyMap=new HashMap();
	
	HashMap propertyMap=new HashMap();
	Iterator i =allAttributes.entrySet().iterator();
	String name="";
	while (i.hasNext() && i != null) {
		Entry entry = (Entry) i.next();
		if (entry != null) {
			if(entry.getKey().equals("name"))
				name=entry.getValue().toString();
			else
			{
				String key=null;
				key=entry.getKey().toString();
				if(key.equals("type"))
					key="mqtype";
				else if(key.equals("size"))
					key="length";
				propertyMap.put(key, entry.getValue().toString());
			}
			
		}		
	}
	//System.out.println(propertyMap);
	fieldPropertyMap.put(name, propertyMap);
	return fieldPropertyMap;
}

@Override
public String toString()
{
	return "Name :: :"+name+"::Type::"+type+"::size::"+size;
}
public String getFormat() {
	return format;
}
public void setFormat(String format) {
	this.format = format;
}
public String getTotalSize() {
	return totalSize;
}
public void setTotalSize(String totalSize) {
	this.totalSize = totalSize;
}
public Element getElement() {
	return element;
}
public void setElement(Element element) {
	this.element = element;
}


public String getMaxOccurs() {
	return maxOccurs;
}
public void setMaxOccurs(String maxOccurs) {
	this.maxOccurs = maxOccurs;
}
public String getPrecision() {
	return precision;
}
public void setPrecision(String precision) {
	this.precision = precision;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getSize() {
	return size;
}
public void setSize(String size) {
	this.size = size;
}
public String getRequired() {
	return required;
}
public void setRequired(String required) {
	this.required = required;
}
public String getNillable() {
	return nillable;
}
public void setNillable(String nillable) {
	this.nillable = nillable;
}
public String getAttribute() {
	return attribute;
}
public void setAttribute(String attribute) {
	this.attribute = attribute;
}
public HashMap<String, String> getAllAttributes() {
	return allAttributes;
}
public void setAllAttributes(HashMap<String, String> allAttributes) {
	this.allAttributes = allAttributes;
}
}
