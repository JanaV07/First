package item;

import java.util.List;
/**
*
* 
* @author VJanarthanan
*/
public class StructureData {
	public List<StructureItem> headerList;
	public List<StructureItem> detailList;
	public List<StructureItem> getHeaderList() {
		return headerList;
	}
	public void setHeaderList(List<StructureItem> header) {
		this.headerList = header;
	}
	public List<StructureItem> getDetailList() {
		return detailList;
	}
	public void setDetailList(List<StructureItem> detailList) {
		this.detailList = detailList;
	}	
}
