package item;

import javafx.scene.control.TextField;
/**
*
* 
* @author VJanarthanan
*/
public class StructureItem {
	public String id;
	public String tag;
	public String label;
	public String type;
	public String required;
	public String listSubItem;
	public String validChars;
	public String state;
	public TextField value;
	
	public TextField getValue() {
		return value;
	}
	public void setValue(TextField value) {
		this.value = value;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	public String getListSubItem() {
		return listSubItem;
	}
	public void setListSubItem(String listSubItem) {
		this.listSubItem = listSubItem;
	}
	public String getValidChars() {
		return validChars;
	}
	public void setValidChars(String validChars) {
		this.validChars = validChars;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String toString() {
		return label;
		
	}
}
