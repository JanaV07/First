package item;

import java.util.HashMap;

import org.w3c.dom.Element;

import javafx.scene.control.CheckBox;
/**
*
* 
* @author VJanarthanan
*/
public class Header {
	public Element category;
	public Element type;
	public Element name;
	public Element application;
	public Element created;
	public Element author;
	public Element description;
	public Element soapTag;
	public Element tapClassName;
	public HashMap <String,String> allElements;
	public CheckBox  select=new CheckBox();
	public CheckBox getSelect() {
		return select;
	}
	public void setSelect(CheckBox select) {
		this.select = select;
	}
	public HashMap<String, String> getAllElements() {
		return allElements;
	}
	public void setAllElements(HashMap<String, String> allElements) {
		this.allElements = allElements;
	}
	public Element getCategory() {
		return category;
	}
	public void setCategory(Element category) {
		this.category = category;
	}
	public Element getType() {
		return type;
	}
	public void setType(Element type) {
		this.type = type;
	}
	public Element getName() {
		return name;
	}
	public void setName(Element name) {
		this.name = name;
	}
	public Element getApplication() {
		return application;
	}
	public void setApplication(Element application) {
		this.application = application;
	}
	public Element getCreated() {
		return created;
	}
	public void setCreated(Element created) {
		this.created = created;
	}
	public Element getAuthor() {
		return author;
	}
	public void setAuthor(Element author) {
		this.author = author;
	}
	public Element getDescription() {
		return description;
	}
	public void setDescription(Element description) {
		this.description = description;
	}
	public Element getSoapTag() {
		return soapTag;
	}
	public void setSoapTag(Element soapTag) {
		this.soapTag = soapTag;
	}
	public Element getTapClassName() {
		return tapClassName;
	}
	public void setTapClassName(Element tapClassName) {
		this.tapClassName = tapClassName;
	}
	
}
