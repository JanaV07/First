package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;

/**
 * For now - we are not using this class
 * 
 * @author VJanarthanan
 */
public class PreLoaderController implements Initializable {
	@FXML
	private Label progressLabel;

	@FXML
	private ProgressIndicator indicator;

	@FXML
	private static ProgressBar bar;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		bar = new ProgressBar();
		bar.setProgress(0 / 100);

		indicator = new ProgressIndicator();
		progressLabel.setText("Starting");
	}

}
