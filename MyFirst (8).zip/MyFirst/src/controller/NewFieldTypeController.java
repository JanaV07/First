package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import item.StructureData;
import item.StructureItem;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import xml.ReadXML;
import xml.Bean.MapBean;

/**
 * Create a field inside the Type Block
 * 
 * @author VJanarthanan
 */
public class NewFieldTypeController implements Initializable {
	HashMap<String, Integer> indexMap = new HashMap<String, Integer>();
	List<Label> labelList = new ArrayList<Label>();
	List<Object> fieldList = new ArrayList<Object>();
	public static HashMap<String, String> newFieldMap = new HashMap<String, String>();
	public static HashMap<String, String> allAttributes = new HashMap<String, String>();
	public static boolean newEntry = true;
	public static Element newElement;
	@FXML
	private GridPane grid;
	@FXML
	private Button ok;
	@FXML
	private Button cancel;
	EventHandler<ActionEvent> okButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			try {
				newEntry = true;
				newFieldMap.clear();
				newElement = null;
				String key;
				String value = null;
				System.out.println("AM OK");
				System.out.println(labelList.size());
				// System.out.println(fieldList.size());
				List<StructureItem> list = getFieldProps();
				DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
				DocumentBuilder build = dFact.newDocumentBuilder();
				Document doc = build.newDocument();
				Element element = doc.createElement("item");
				// org.jdom.Element element=new org.jdom.Element("item");
				String fieldSize = null;
				String precision = null;
				String type = null;
				for (int i = 0; i < labelList.size(); i++) {
					// System.out.println(labelList.get(i));
					// System.out.println(fieldList.get(i));
					StructureItem item = list.get(i);
					key = ((Label) getNodeFromGridPane(grid, 0, i)).getText();
					// System.out.println("KEY : :: : : "+key);
					if (!key.equals("Information")) {
						Node node = getNodeFromGridPane(grid, 1, i);
						if (node instanceof TextField)
							value = ((TextField) node).getText();
						else if (node instanceof ComboBox) {
							System.out.println("AM::COMBO: :" + key);
							if (!((ComboBox) node).getItems().isEmpty()
									&& ((ComboBox) node).getSelectionModel().getSelectedItem() != null)
								value = ((ComboBox) node).getSelectionModel().getSelectedItem().toString();
							else
								value = "";
						} else if (node instanceof TextArea) {
							value = ((TextArea) node).getText();
						}
						if (key.equals("Description")) {
							value = value.replace("\n", "&#xA;");
						} else if (key.equals("Required") || key.equals("Nillable")) {
							value = value.toLowerCase();
						} else if (key.equals("Size")) {
							fieldSize = value;
						} else if (key.equals("Type")) {
							type = value;
						} else if (key.equals("Precision")) {
							precision = value;
						} else if (( key.equals("MQ Format") || key.equals("PL Header") )&& value.length() > 0) {
							HashMap<String, Element> elementMap = MapBean.dataTypeMap.get(type);
							List<Element> formats = ReadXML.getElements((Element) elementMap.get("format"));
							if(key.equals("PL Header"))
								formats=ReadXML.getElements((Element) elementMap.get("plheader"));
							System.out.println(formats);
							for (Element ele : formats) {
								// System.out.println(ele.getAttribute("label"));
								if (ele.getAttribute("label").equals(value)) {
									value = ele.getAttribute("id");
									break;
								}
							}
							if (value.contains("%fieldSize%")) {
								String s = "";
								for (int k = 0; k < Integer.parseInt(fieldSize) && k < Integer.parseInt(
										MapBean.dataTypeMap.get(type).get("fieldSize").getAttribute("max")); k++) {
									s = s + "0";
								}
								// System.out.println(s);
								value = value.replaceAll("%fieldSize%", s);
							}
							if (value.contains("%precision%")) {
								String s = "";
								for (int k = 0; k < Integer.parseInt(precision) && k < Integer.parseInt(
										MapBean.dataTypeMap.get(type).get("precision").getAttribute("max")); k++) {
									s = s + "0";
								}
								// System.out.println(s);
								value = value.replaceAll("%precision%", s);
							}
						}
						if (!value.isEmpty() && !value.contains("default")) {
							System.out.println("KEY ::" + key);
							System.out.println("TAG : :" + item.getTag().replace("@", ""));
							System.out.println("VALUE :: " + value);
							element.setAttribute(item.getTag().replace("@", ""), value);
							allAttributes.put(item.getTag().replace("@", ""), value);
						}
						newElement = (Element) element;
						if(value.length()>0)
							newFieldMap.put(key, value);
					}
				}
				// System.out.println(element.toString());
				// System.out.println(element.getAttributes());
				Stage stage = (Stage) ok.getScene().getWindow();
				stage.close();
			} catch (Exception e) {
				System.out.println("Am in Exception 95 in NEwfieldType");
				e.printStackTrace();
			}
		}
	};
	EventHandler<ActionEvent> cancelButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			newEntry = false;
			System.out.println("AM Cancel");
			Stage stage = (Stage) cancel.getScene().getWindow();
			stage.close();
		}
	};

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		gridInitialize();
		ok.setOnAction(okButtonHandler);
		ok.setDefaultButton(true);
		cancel.setOnAction(cancelButtonHandler);
	}

	public void gridInitialize() {
		List<StructureItem> list = getFieldProps();
		ObservableList<String> options = FXCollections.observableArrayList("Yes", "No");
		for (int i = 0; i < list.size(); i++) {
			System.out.println("AM : : " + list.get(i).id);
			Label label = new Label(list.get(i).getLabel());
			// RowConstraints row=new RowConstraints();
			GridPane.setConstraints(label, 0, i);
			System.out.println(label.getText());
			grid.getChildren().add(label);
			indexMap.put(list.get(i).getLabel(), i);
			if (label.getText().equals("Type")) {
				ComboBox<String> combo = new ComboBox<>(getDataTypes());
				combo.getSelectionModel().select("String");
				combo.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						String sel = combo.getValue();
						if (InTypeController.fieldTypeList.contains(sel)) {
							userDefinedFunction(sel);
						} else {
							types_Function(sel, null, null, null);
						}
						// /UpdateSize(sel);
					}
				});
				GridPane.setConstraints(combo, 1, i);
				grid.getChildren().add(combo);
				fieldList.add(i, combo);
			} else if (label.getText().equals("Required") || label.getText().equals("Nillable")) {
				ComboBox<String> combo = new ComboBox<>(options);
				combo.getSelectionModel().select("No");
				GridPane.setConstraints(combo, 1, i);
				grid.getChildren().add(combo);
				fieldList.add(i, combo);
			} else if (label.getText().equals("Description")) {
				TextArea itf = new TextArea();
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
				fieldList.add(i, itf);
			} else if (label.getText().equals("maxOccurs") || label.getText().equals("Size")
					|| label.getText().equals("Precision")) {
				TextField field = new TextField();
				field.textProperty().addListener(new ChangeListener<String>() {
					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {
						if (!newValue.matches("\\d*")) {
							field.setText(newValue.replaceAll("[^\\d]", ""));
						}
					}
				});
				GridPane.setConstraints(field, 1, i);
				grid.getChildren().add(field);
				fieldList.add(i, field);
			} else {
				TextField field = new TextField();
				GridPane.setConstraints(field, 1, i);
				grid.getChildren().add(field);
				fieldList.add(i, field);
			}
			labelList.add(i, label);
			// grid.add(label, 0, i);
		}
		types_Function("String",null,null,null);
		allign();
		System.out.println(grid.getHeight());
	}

	protected void types_Function(String sel, String fieldSize, String fieldMQ, String fieldPrecision) {
		int sizeIndex = indexMap.get("Size");
		int precisionIndex = indexMap.get("Precision");
		int infoIndex = indexMap.get("Information");
		int valueListIndex = indexMap.get("Value List");
		int fixedValueIndex = indexMap.get("Fixed Value");
		int mqIndex = indexMap.get("MQ Format");
		int plHeaderIndex = indexMap.get("PL Header");
		HashMap<String, Element> elementMap = MapBean.dataTypeMap.get(sel);
		Iterator i = null;
		HashMap<String, String> formatMap = new HashMap<String, String>(); // Contatins//
																			// <Label,Value(id)
		String typeFieldSize = "";
		ObservableList<String> list = FXCollections.observableArrayList();
		ObservableList<String> plList = FXCollections.observableArrayList();
		plList.clear();
		String precision = "";
		if (elementMap != null) {
			i = elementMap.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				// System.out.println("KEY " + entry.getKey());
				if (entry.getKey().toString().equals("information")) {
					Element innerElement = (Element) entry.getValue();
					// System.out.println(innerElement.getTextContent());
				} else if (entry.getKey().toString().equals("format")) {
					List<Element> formats = ReadXML.getElements((Element) entry.getValue());
					// System.out.println(formats);
					for (Element innerElement : formats) {
						formatMap.put(innerElement.getAttribute("label"), innerElement.getAttribute("id"));
						list.add(innerElement.getAttribute("label"));
					}
				} else if (entry.getKey().toString().equals("plheader")) {
					List<Element> formats = ReadXML.getElements((Element) entry.getValue());
					// System.out.println(formats);
					for (Element innerElement : formats) {
						formatMap.put(innerElement.getAttribute("label"), innerElement.getAttribute("id"));
						plList.add(innerElement.getAttribute("label"));
					}
				} else if (entry.getKey().toString().equals("fieldSize")) {
					Element innerElement = (Element) entry.getValue();
					typeFieldSize = innerElement.getAttribute("default");
					System.out.println(typeFieldSize);
				} else if (entry.getKey().toString().equals("precision")) {
					Element innerElement = (Element) entry.getValue();
					precision = innerElement.getAttribute("default");
					System.out.println(precision);
				}
			}
		}
		// ********size
		if (fieldSize == null) {
			if (sel.equals("Account"))
				fieldSize = "9";
			else if (sel.equals("Phone") || sel.equals("Address") || sel.equals("Date"))
				fieldSize = "10";
			else if (sel.equals("Indicator"))
				fieldSize = "1";
			else if (sel.equals("DateTime"))
				fieldSize = "19";
			else if (sel.equals("Integer18") || sel.equals("Time") || sel.equals("Timestamp"))
				fieldSize = "18";
			else if (sel.equals("Decimal12.6"))
				fieldSize = "12";
			else if (sel.equals("Decimal14.4"))
				fieldSize = "14";
			else if (sel.equals("Decimal16.2"))
				fieldSize = "16";
			else
				fieldSize = typeFieldSize;
		}
		TextField tf = new TextField(fieldSize);
		tf.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!newValue.matches("\\d*")) {
					tf.setText(newValue.replaceAll("[^\\d]", ""));
				}
			}
		});
		if (elementMap.get("fieldSize").getAttribute("state").toString().equals("suppress"))
			tf.setEditable(false);
		else
			tf.setEditable(true);
		GridPane.setConstraints(tf, 1, sizeIndex);
		grid.getChildren().remove(fieldList.get(sizeIndex));
		grid.getChildren().add(tf);
		fieldList.remove(sizeIndex);
		fieldList.add(sizeIndex, tf);
		// ********info
		String info1 = elementMap.get("information").getTextContent();
		TextArea itf = new TextArea(info1);
		itf.setEditable(false);
		GridPane.setConstraints(itf, 1, infoIndex);
		grid.getChildren().remove(fieldList.get(infoIndex));
		grid.getChildren().add(itf);
		fieldList.remove(infoIndex);
		fieldList.add(infoIndex, itf);
		// allign();
		// ***********precision
		if (fieldPrecision == null) {
			if (sel.equals("Decimal12.6"))
				fieldPrecision = "6";
			else if (sel.equals("Decimal14.4"))
				fieldPrecision = "4";
			else if (sel.equals("Decimal16.2"))
				fieldPrecision = "2";
			else
				fieldPrecision = precision;
		}
		TextField ptf = new TextField(fieldPrecision);
		if (elementMap.get("precision").getAttribute("state").toString().equals("suppress"))
			ptf.setEditable(false);
		else
			ptf.setEditable(true);
		GridPane.setConstraints(ptf, 1, precisionIndex);
		grid.getChildren().remove(fieldList.get(precisionIndex));
		grid.getChildren().add(ptf);
		fieldList.remove(precisionIndex);
		fieldList.add(precisionIndex, ptf);
		//////////// MQ
		ComboBox<String> combo = new ComboBox<>(list);
		combo.getSelectionModel().select(fieldMQ);
		combo.getSelectionModel().selectFirst();
		GridPane.setConstraints(combo, 1, mqIndex);
		grid.getChildren().remove(fieldList.get(mqIndex));
		grid.getChildren().add(combo);
		fieldList.remove(mqIndex);
		fieldList.add(mqIndex, combo);
		// **************plHeaderIndex
		ComboBox<String> combo1 = new ComboBox<>(plList);
		GridPane.setConstraints(combo1, 1, plHeaderIndex);
		grid.getChildren().remove(fieldList.get(plHeaderIndex));
		grid.getChildren().add(combo1);
		fieldList.remove(plHeaderIndex);
		fieldList.add(plHeaderIndex, combo1);
		// ***********valueListIndex
		TextField vtf = new TextField();
		if (!elementMap.get("enumValues").getAttribute("state").toString().equals("suppress"))
			vtf.setEditable(true);
		else
			vtf.setEditable(false);
		GridPane.setConstraints(vtf, 1, valueListIndex);
		grid.getChildren().remove(fieldList.get(valueListIndex));
		grid.getChildren().add(vtf);
		fieldList.remove(valueListIndex);
		fieldList.add(valueListIndex, vtf);
		// ***********fixedValueIndex
		TextField ftf = new TextField();
		ftf.setEditable(false);
		GridPane.setConstraints(ftf, 1, fixedValueIndex);
		grid.getChildren().remove(fieldList.get(fixedValueIndex));
		grid.getChildren().add(ftf);
		fieldList.remove(fixedValueIndex);
		fieldList.add(fixedValueIndex, ftf);
		allign();
	}

	protected void userDefinedFunction(String sel) {
		int sizeIndex = indexMap.get("Size");
		int precisionIndex = indexMap.get("Precision");
		int infoIndex = indexMap.get("Information");
		int valueListIndex = indexMap.get("Value List");
		int fixedValueIndex = indexMap.get("Fixed Value");
		int mqIndex = indexMap.get("MQ Format");
		System.out.println();
		// ********size
		TextField tf = new TextField(InTypeController.typeSizeMap.get(sel));
		tf.setEditable(false);
		GridPane.setConstraints(tf, 1, sizeIndex);
		grid.getChildren().remove(fieldList.get(sizeIndex));
		grid.getChildren().add(tf);
		fieldList.remove(sizeIndex);
		fieldList.add(sizeIndex, tf);
		// ********info
		String info1 = "User Defined Type";
		TextArea itf = new TextArea(info1);
		itf.setEditable(false);
		GridPane.setConstraints(itf, 1, infoIndex);
		grid.getChildren().remove(fieldList.get(infoIndex));
		grid.getChildren().add(itf);
		fieldList.remove(infoIndex);
		fieldList.add(infoIndex, itf);
		allign();
		// ***********precision
		TextField ptf = new TextField();
		ptf.setEditable(false);
		GridPane.setConstraints(ptf, 1, precisionIndex);
		grid.getChildren().remove(fieldList.get(precisionIndex));
		grid.getChildren().add(ptf);
		fieldList.remove(precisionIndex);
		fieldList.add(precisionIndex, ptf);
		// **************MQ
		TextField mtf = new TextField();
		mtf.setEditable(false);
		GridPane.setConstraints(mtf, 1, mqIndex);
		grid.getChildren().remove(fieldList.get(mqIndex));
		grid.getChildren().add(mtf);
		fieldList.remove(mqIndex);
		fieldList.add(mqIndex, mtf);
		// ***********valueListIndex
		TextField vtf = new TextField();
		vtf.setEditable(false);
		GridPane.setConstraints(vtf, 1, valueListIndex);
		grid.getChildren().remove(fieldList.get(valueListIndex));
		grid.getChildren().add(vtf);
		fieldList.remove(valueListIndex);
		fieldList.add(valueListIndex, vtf);
		allign();
	}

	
	
	protected void newUserDefinedFunction(String sel) {
		int sizeIndex = indexMap.get("Size");
		int precisionIndex = indexMap.get("Precision");
		int infoIndex = indexMap.get("Information");
		int valueListIndex = indexMap.get("Value List");
		int fixedValueIndex = indexMap.get("Fixed Value");
		int mqIndex = indexMap.get("MQ Format");
		System.out.println();
		HashMap<String, Element> elementMap = MapBean.dataTypeMap.get(sel);
		Iterator i = null;
		HashMap<String, String> formatMap = new HashMap<String, String>(); // Contatins
																			// <Label,Value(id)
		ObservableList<String> list = FXCollections.observableArrayList();
		String fieldSize = "";
		String precision = "";
		if (elementMap != null) {
			i = elementMap.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				// System.out.println("KEY " + entry.getKey());
				if (entry.getKey().toString().equals("information")) {
					Element innerElement = (Element) entry.getValue();
					// System.out.println(innerElement.getTextContent());
				} else if (entry.getKey().toString().equals("format")) {
					List<Element> formats = ReadXML.getElements((Element) entry.getValue());
					// System.out.println(formats);
					for (Element innerElement : formats) {
						formatMap.put(innerElement.getAttribute("label"), innerElement.getAttribute("id"));
						list.add(innerElement.getAttribute("label"));
					}
				} else if (entry.getKey().toString().equals("fieldSize")) {
					Element innerElement = (Element) entry.getValue();
					fieldSize = innerElement.getAttribute("default");
					System.out.println(fieldSize);
				} else if (entry.getKey().toString().equals("precision")) {
					Element innerElement = (Element) entry.getValue();
					precision = innerElement.getAttribute("default");
					System.out.println(precision);
				}
			}
		}
		// ********size
		TextField tf = new TextField(fieldSize);
		if (elementMap.get("fieldSize").getAttribute("state").toString().equals("suppress"))
			tf.setEditable(false);
		else
			tf.setEditable(true);
		tf.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!newValue.matches("\\d*")) {
					tf.setText(newValue.replaceAll("[^\\d]", ""));
				}
			}
		});
		GridPane.setConstraints(tf, 1, sizeIndex);
		grid.getChildren().remove(fieldList.get(sizeIndex));
		grid.getChildren().add(tf);
		fieldList.remove(sizeIndex);
		fieldList.add(sizeIndex, tf);
		// ********info
		String info = elementMap.get("information").getTextContent();
		System.out.println("info: : :" + info);
		TextArea itf = new TextArea(info);
		itf.setEditable(false);
		GridPane.setConstraints(itf, 1, infoIndex);
		grid.getChildren().remove(fieldList.get(infoIndex));
		grid.getChildren().add(itf);
		fieldList.remove(infoIndex);
		fieldList.add(infoIndex, itf);
		// ***********precision
		TextField ptf = new TextField();
		if (elementMap.get("precision").getAttribute("state").toString().equals("suppress"))
			ptf.setEditable(false);
		else
			ptf.setEditable(true);
		GridPane.setConstraints(ptf, 1, precisionIndex);
		grid.getChildren().remove(fieldList.get(precisionIndex));
		grid.getChildren().add(ptf);
		fieldList.remove(precisionIndex);
		fieldList.add(precisionIndex, ptf);
		// **************MQ
		ComboBox<String> combo = new ComboBox<>(list);
		combo.getSelectionModel().selectFirst();
		GridPane.setConstraints(combo, 1, mqIndex);
		grid.getChildren().remove(fieldList.get(mqIndex));
		grid.getChildren().add(combo);
		fieldList.remove(mqIndex);
		fieldList.add(mqIndex, combo);
		// ***********valueListIndex
		TextField vtf = new TextField();
		if (elementMap.get("enumValues").getAttribute("state").toString().equals("suppress"))
			vtf.setEditable(false);
		else
			vtf.setEditable(true);
		GridPane.setConstraints(vtf, 1, valueListIndex);
		grid.getChildren().remove(fieldList.get(valueListIndex));
		grid.getChildren().add(vtf);
		fieldList.remove(valueListIndex);
		fieldList.add(valueListIndex, vtf);
		allign();
	}


	public void allign() {
		// make all of the Controls and Panes inside the grid fill their grid
		// cell,
		// align them in the center and give them a filled background.
		// you could also place each of them in their own centered StackPane
		// with
		// a styled background to achieve the same effect.
		for (Node n : grid.getChildren()) {
			if (n instanceof Control) {
				Control control = (Control) n;
				control.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
				control.setStyle("-fx-background-color: white; -fx-alignment: Left;");
			}
			if (n instanceof Pane) {
				Pane pane = (Pane) n;
				pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
				pane.setStyle("-fx-background-color: grey; -fx-alignment: center;");
			}
		}
		// style the grid so that it has a background and gaps around the grid
		// and
		// between the
		// grid cells so that the background will show through as grid lines.
		grid.setStyle("-fx-background-color: grey; -fx-padding: 1; -fx-hgap: 1; -fx-vgap: 2;");
		// turn layout pixel snapping off on the grid so that grid lines will be
		// an even
		// width.
		grid.setSnapToPixel(false);
	}

	private Node getNodeFromGridPane(GridPane gridPane, int col, int row) {
		for (Node node : gridPane.getChildren()) {
			if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
				return node;
			}
		}
		return null;
	}

	public ObservableList<StructureItem> getFieldProps() {
		// System.out.println("Type Name : : :"+serviceName);
		StructureData structureData = MapBean.getStructureMap().get("type");
		ObservableList<StructureItem> itemList = FXCollections.observableArrayList(structureData.getDetailList());
		/*
		 * for (StructureItem item : itemList) System.out.println("Am : : : :" +
		 * item.getId());
		 */
		return itemList;
	}

	public ObservableList<String> getDataTypes() {
		HashMap<String, HashMap<String, Element>> dataTypeMap = MapBean.getDataTypeMap();
		ObservableList<String> itemList = FXCollections.observableArrayList();
		Iterator i = null;
		if (dataTypeMap != null) {
			i = dataTypeMap.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				String key = (String) entry.getKey();
				// System.out.println(key);
				itemList.add(key);
			}
		}
		FXCollections.sort(itemList);
		itemList.addAll(InTypeController.fieldTypeList);
		return itemList;
	}
}