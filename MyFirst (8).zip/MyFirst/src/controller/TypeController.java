package controller;

import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import item.Header;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

/**
 *	Type Main Page containing all the types included in the package
 * 	view - TypeController.fxml
 * 
 * @author VJanarthanan
 */
public class TypeController implements Initializable {
	public static HashMap<String, List<Header>> typeMap;
	public static String Package;

	public static String getPackage() {
		return Package;
	}

	public static void setPackage(String package1) {
		Package = package1;
	}

	public static HashMap<String, List<Header>> getTypeMap() {
		return typeMap;
	}

	public static void setTypeMap(HashMap<String, List<Header>> typeMap) {
		TypeController.typeMap = typeMap;
	}

	@FXML
	Label application;
	@FXML
	private TableView<HeaderList> table;
	@FXML
	private TableColumn<HeaderList, String> nameColumn;
	@FXML
	private TableColumn<Header, String> categoryColumn;
	@FXML
	private TableColumn<Header, String> datedColumn;
	@FXML
	private TableColumn<Header, String> authorCoulumn;

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		application.setText(Package);
		// System.out.println(typeMap);
		nameColumn.setCellValueFactory(new PropertyValueFactory<HeaderList, String>("name"));
		categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
		datedColumn.setCellValueFactory(new PropertyValueFactory<>("dated"));
		authorCoulumn.setCellValueFactory(new PropertyValueFactory<>("author"));
		// System.out.println("++++++++++++++++ssss+++: : :
		// :"+nameColumn.getCellData(2));
		nameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
		nameColumn.setOnEditCommit(new EventHandler<CellEditEvent<HeaderList, String>>() {
			@Override
			public void handle(CellEditEvent<HeaderList, String> t) {
				((HeaderList) t.getTableView().getItems().get(t.getTablePosition().getRow())).setName(t.getNewValue());
			}
		});
		table.setItems(getTypeList());
		table.setEditable(true);
		// System.out.println(getTypeList());
		// System.out.println("+++++++++++++++++++: : :
		// :"+nameColumn.getCellData(2));
	}

	public ObservableList<HeaderList> getTypeList() {
		List<Header> headerList = typeMap.get(Package);
		// System.out.println("LIST*******************************************");
		ObservableList<HeaderList> typeList = FXCollections.observableArrayList();
		for (Header header : headerList) {
			// System.out.println("::: : :"+header.getName().getTextContent());
			HeaderList type = new HeaderList();
			type.setName(header.getName().getTextContent());
			if (header.getAuthor() != null)
				type.setAuthor(header.getAuthor().getTextContent());
			type.setDated(header.getCreated().getTextContent());
			type.setCategory(header.getCategory().getTextContent());
			typeList.add(type);
		}
		return typeList;
	}
}