package controller;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import application.MainApp;
import application.MainController;
import gen.doc.DocGenerator;
import gen.doc.PDFGenerator;
import gen.mdo.MDOGenerator;

import java.util.ResourceBundle;
import item.FunctionData;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import xml.UpdateMap;
import xml.UpdateXML;

/**
 * Inside the Service
 * Views the data inside the service
 * view - InService.fxml
 * 
 * @author VJanarthanan
 */
public class InServiceController implements Initializable {
	public static String serviceName;
	public static String packageName;
	public static String type = null;
	public ObservableList<ItemBase> observableInputItemList;
	public ObservableList<ItemBase> observableOutputItemList;
	public ServiceData serviceData; //Coontains the corresponding serviceData of a service
	public static List<HashMap<String, ServiceData>> serviceMapList; //Contains all the service inside that package ServiceName,ServiceData
	public static List<HashMap<String, FunctionData>> functionMapList; // contains all the function inside that package functionName,FunctionData
	public static ObservableList<String> functionList = FXCollections.observableArrayList(); // conatains all the function name in the package
	@FXML
	Label serviceLabel;
	@FXML
	private TableView<HeaderList> topTable;
	@FXML
	private TableView<ItemBase> inputTable;
	@FXML
	private TableView<ItemBase> outputTable;
	@FXML
	private TableColumn<ItemBase, String> iname;
	@FXML
	private TableColumn<ItemBase, String> itype;
	@FXML
	private TableColumn<ItemBase, String> imaxOccurs;
	@FXML
	private TableColumn<ItemBase, String> oname;
	@FXML
	private TableColumn<ItemBase, String> otype;
	@FXML
	private TableColumn<ItemBase, String> omaxOccurs;
	@FXML
	private Button addNewB;
	@FXML
	private Button deleteB;
	@FXML
	private Button moveUpB;
	@FXML
	private Button moveDownB;
	@FXML
	private Button addNewRB;
	@FXML
	private Button deleteRB;
	@FXML
	private Button moveUpRB;
	@FXML
	private Button moveDownRB;
	@FXML
	private Button gmdo;
	@FXML
	private Button docButton;

	public static List<HashMap<String, ServiceData>> getServiceMapList() {
		return serviceMapList;
	}

	public static void setServiceMapList(List<HashMap<String, ServiceData>> serviceMapList) {
		InServiceController.serviceMapList = serviceMapList;
	}

	public static List<HashMap<String, FunctionData>> getFunctionMapList() {
		return functionMapList;
	}

	public static void setFunctionMapList(List<HashMap<String, FunctionData>> functionMapList) {
		InServiceController.functionMapList = functionMapList;
	}

	public static String getServiceName() {
		return serviceName;
	}

	public static void setServiceName(String serviceName) {
		InServiceController.serviceName = serviceName;
	}

	public static String getPackageName() {
		return packageName;
	}

	public static void setPackageName(String packageName) {
		InServiceController.packageName = packageName;
	}
	
	EventHandler<ActionEvent> inputDownButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// //System.out.println("Am here");
			ItemBase item = inputTable.getSelectionModel().getSelectedItem();
			int index = inputTable.getSelectionModel().getSelectedIndex();
			// //System.out.println("index " + index);
			if (index < inputTable.getItems().size() - 1) {
				inputTable.getItems().add(index + 1, inputTable.getItems().remove(index));
				// select item at new position
				// //System.out.println("size " + inputTable.getItems().size());
				inputTable.getSelectionModel().clearAndSelect(index + 1);
				inputDownButtonFunction(index, item);
			}
			// //System.out.println(item.getName());
			event.consume();
		}
	};
	EventHandler<ActionEvent> inputUpButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// //System.out.println("Am here");
			ItemBase item = inputTable.getSelectionModel().getSelectedItem();
			int index = inputTable.getSelectionModel().getSelectedIndex();
			// //System.out.println("index " + index);
			if (index > 0) {
				inputTable.getItems().add(index - 1, inputTable.getItems().remove(index));
				// select item at new position
				// //System.out.println("size " + inputTable.getItems().size());
				inputTable.getSelectionModel().clearAndSelect(index - 1);
				inputUpButtonFunction(index, item);
			}
			// //System.out.println(item.getName());
			event.consume();
		}
	};
	EventHandler<ActionEvent> outputDownButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// //System.out.println("Am here");
			ItemBase item = outputTable.getSelectionModel().getSelectedItem();
			int index = outputTable.getSelectionModel().getSelectedIndex();
			// //System.out.println("index " + index);
			if (index < outputTable.getItems().size() - 1) {
				outputTable.getItems().add(index + 1, outputTable.getItems().remove(index));
				// select item at new position
				// //System.out.println("size " +
				// outputTable.getItems().size());
				outputTable.getSelectionModel().clearAndSelect(index + 1);
				outputDownButtonFunction(index, item);
			}
			// //System.out.println(item.getName());
			event.consume();
		}
	};
	
	EventHandler<ActionEvent> outputUpButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// //System.out.println("Am here");
			ItemBase item = outputTable.getSelectionModel().getSelectedItem();
			int index = outputTable.getSelectionModel().getSelectedIndex();
			// //System.out.println("index " + index);
			if (index > 0) {
				outputTable.getItems().add(index - 1, outputTable.getItems().remove(index));
				// select item at new position
				// //System.out.println("size " +
				// outputTable.getItems().size());
				outputTable.getSelectionModel().clearAndSelect(index - 1);
				outputUpButtonFunction(index, item);
			}
			// //System.out.println(item.getName());
			event.consume();
		}
	};
	
	EventHandler<ActionEvent> inputDeleteButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			//// System.out.println("Am here");
			ItemBase item = inputTable.getSelectionModel().getSelectedItem();
			int index = inputTable.getSelectionModel().getSelectedIndex();
			inputTable.getItems().remove(item);
			deleteButtonFunction(index, item, "I");
			// upButtonFunction(index,item);
			//// System.out.println("index "+index);
			// if(index>0){
			// inputTable.getItems().add(index-1,
			// inputTable.getItems().remove(index));
			// select item at new position
			//// System.out.println("size "+inputTable.getItems().size());
			//// System.out.println(item.getName());
			event.consume();
		}
	};
	
	EventHandler<ActionEvent> outputDeleteButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			//// System.out.println("Am here");
			ItemBase item = outputTable.getSelectionModel().getSelectedItem();
			int index = outputTable.getSelectionModel().getSelectedIndex();
			outputTable.getItems().remove(item);
			deleteButtonFunction(index, item, "O");
			// upButtonFunction(index,item);
			//// System.out.println("index "+index);
			// if(index>0){
			// inputTable.getItems().add(index-1,
			// inputTable.getItems().remove(index));
			// select item at new position
			//// System.out.println("size "+inputTable.getItems().size());
			//// System.out.println(item.getName());
			event.consume();
		}
	};
	
    EventHandler<ActionEvent> addButtonHandler = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (((Button) event.getSource()).getId().equals("addNewB"))
					type = "Input";
				else
					type = "Output";
				System.out.println("Am in button");
				//////////////// SUB WINDOW////////////////////
				Parent parent = null;
				try {
					parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewFieldService.fxml"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Stage stage = new Stage();
				// stage.initStyle(StageStyle.TRANSPARENT);
				stage.setTitle("Include Function");
				stage.setScene(new Scene(parent));
				stage.initModality(Modality.WINDOW_MODAL);
				stage.initOwner(MainApp.getStage());
				stage.showAndWait();
				//////////////// SUB WINDOW////////////////////
				int index;
				if (type.equals("Input"))
					index = inputTable.getSelectionModel().getSelectedIndex();
				else
					index = outputTable.getSelectionModel().getSelectedIndex();
				System.out.println("INDEX: dddd: : :" + index);
				if (NewFieldServiceController.newEntry)
					addButtonFunction(index);
				NewServiceController.newEntry = false;
				event.consume();
			}
		};
	//Handling Document Generation
		EventHandler<ActionEvent> docButtonHandler = (e)->{
			try {
			DocGenerator docGenerator=new DocGenerator(packageName,serviceName,serviceMapList,functionMapList,functionList,MainController.bulkFunctionMap,MainController.bulkTypeMap);
			Hashtable htService=(Hashtable)docGenerator.createHashTable(false);
			
			PDFGenerator gen=new PDFGenerator(htService,"c://Data//MessageExplorer-Java//Documents//"+packageName);
	 		gen.generatePDF();
			}
			catch(Exception ex) {
				ex.printStackTrace();
				System.out.println("Exception occured : "+ex);
			}
			
		};
	EventHandler<ActionEvent> mdoEventHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
		
		MDOGenerator mdoGenerator=new MDOGenerator("input",packageName,serviceName,serviceMapList,functionMapList,functionList,MainController.bulkFunctionMap,MainController.bulkTypeMap);
			try
			{
				mdoGenerator.generateOP();
				Text text = new Text();
				text.setText("MDO GENERATED!!!!");
				text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
				text.setX(50);
				text.setY(50);
				Group root = new Group(text);
				Scene scene = new Scene(root, 350, 100);
				Stage stage = new Stage();
				stage.setTitle("Success");
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e) {
				Text text = new Text();
				text.setText("Error in Generation!!!!");
				text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
				text.setX(50);
				text.setY(50);
				Group root = new Group(text);
				Scene scene = new Scene(root, 350, 100);
				Stage stage = new Stage();
				stage.setTitle("Success");
				stage.setScene(scene);
				stage.show();
			}
			
		}
		};

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		serviceLabel.setText(serviceName);
		iname.setCellValueFactory(new PropertyValueFactory<>("name"));
		itype.setCellValueFactory(new PropertyValueFactory<>("type"));
		imaxOccurs.setCellValueFactory(new PropertyValueFactory<>("maxOccurs"));
		// iprecision.setCellValueFactory(new
		// PropertyValueFactory<>("precision"));
		iname.setPrefWidth(200.0);
		itype.setPrefWidth(100.0);
		oname.setCellValueFactory(new PropertyValueFactory<>("name"));
		otype.setCellValueFactory(new PropertyValueFactory<>("type"));
		omaxOccurs.setCellValueFactory(new PropertyValueFactory<>("maxOccurs"));
		oname.setPrefWidth(200.0);
		otype.setPrefWidth(100.0);
		iname.setSortable(false);
		itype.setSortable(false);
		imaxOccurs.setSortable(false);
		oname.setSortable(false);
		otype.setSortable(false);
		omaxOccurs.setSortable(false);
		//System.out.println("Calling Input");
		//System.out.println(serviceMapList);
		observableInputItemList = getInputFunctionList(serviceMapList);
		inputTable.setItems(observableInputItemList);
		// System.out.println("Calling Output");
		// System.out.println(outputServiceList);
		observableOutputItemList = getOutputFunctionList(serviceMapList);
		outputTable.setItems(observableOutputItemList);
		// System.out.println("functionMap: : :"+functionMap);
		
     	moveUpB.setOnAction(inputUpButtonHandler );
		moveUpRB.setOnAction(outputUpButtonHandler);
		moveDownB.setOnAction(inputDownButtonHandler);
		moveDownRB.setOnAction(outputDownButtonHandler);
		deleteB.setOnAction(inputDeleteButtonHandler);
		deleteRB.setOnAction(outputDeleteButtonHandler);
		
		gmdo.setOnAction(mdoEventHandler);
		docButton.setOnAction(docButtonHandler);
		addNewB.setOnAction(addButtonHandler);
		
		addNewRB.setOnAction(addButtonHandler);
		setFunctions();
	}

	protected void deleteButtonFunction(int index, ItemBase item, String type) {
		if (type.equals("I")) {
			UpdateXML.moveButtonServiceFunction(packageName, serviceName, index, "Delete", "I");
			UpdateMap.moveButtonServiceFunction(packageName, serviceName, index, item, "Delete", "I");
		} else {
			UpdateXML.moveButtonServiceFunction(packageName, serviceName, index, "Delete", "O");
			// UpdateMap.moveButtonTypeFunction(packageName,functionName,index,item,"Delete");
			UpdateMap.moveButtonServiceFunction(packageName, serviceName, index, item, "Delete", "O");
		}
	}

    protected void inputUpButtonFunction(int index, ItemBase item) {
		// //System.out.println("Package Name : : "+packageName);
		//// System.out.println("Type Name : : : "+ functionName);
		UpdateXML.moveButtonServiceFunction(packageName, serviceName, index, "U", "I");
		UpdateMap.moveButtonServiceFunction(packageName, serviceName, index, item, "U", "I");
	}

	protected void inputDownButtonFunction(int index, ItemBase item) {
		//// System.out.println("Package Name : : "+packageName);
		//// System.out.println("Type Name : : : "+ functionName);
		UpdateXML.moveButtonServiceFunction(packageName, serviceName, index, "D", "I");
		// UpdateMap.moveButtonFunFunction(packageName,functionName,index,item,"D");
		UpdateMap.moveButtonServiceFunction(packageName, serviceName, index, item, "D", "I");
	}

	protected void outputUpButtonFunction(int index, ItemBase item) {
		//// System.out.println("Package Name : : "+packageName);
		// //System.out.println("Type Name : : : "+ functionName);
		UpdateXML.moveButtonServiceFunction(packageName, serviceName, index, "U", "O");
		// UpdateMap.moveButtonFunFunction(packageName,functionName,index,item,"D");
		UpdateMap.moveButtonServiceFunction(packageName, serviceName, index, item, "U", "D");
	}

	protected void outputDownButtonFunction(int index, ItemBase item) {
		// //System.out.println("Package Name : : "+packageName);
		// //System.out.println("Type Name : : : "+ functionName);
		UpdateXML.moveButtonServiceFunction(packageName, serviceName, index, "D", "O");
		// UpdateMap.moveButtonFunFunction(packageName,functionName,index,item,"D");
		UpdateMap.moveButtonServiceFunction(packageName, serviceName, index, item, "D", "D");
	}
	protected void addButtonFunction(int index) {
		HashMap<String, Boolean> newFieldMap = NewFieldServiceController.selected;
		
		Iterator i = null;
		if (newFieldMap != null) {
			i = newFieldMap.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				if (entry != null) {
					if ((Boolean) entry.getValue()) {
						ItemBase itemBase = new ItemBase();
						itemBase.setName((String) entry.getKey());
						itemBase.setType("Function");
						System.out.println(entry.getKey());
						System.out.println(type);
						System.out.println(packageName);
						if (index < 0) {
							if (type.equals("Input")) {
								observableInputItemList.add(itemBase);
								UpdateMap.addButtonServiceFunction(packageName, serviceName, index, itemBase, type);

							} else {
								System.out.println("Inside output: : " + type);
								observableOutputItemList.add(itemBase);
								UpdateMap.addButtonServiceFunction(packageName, serviceName, index, itemBase, type);

							}
						} else {
							if (type.equals("Input")) {
								observableInputItemList.add(index + 1, itemBase);
								UpdateMap.addButtonServiceFunction(packageName, serviceName, index, itemBase, type);

							} else {
								observableOutputItemList.add(index + 1, itemBase);
								UpdateMap.addButtonServiceFunction(packageName, serviceName, index, itemBase, type);

							}
						}
					}
				}
			}
			if (type.equals("Input")) {
				UpdateXML.addButtonServiceFunction(packageName, serviceName, index, type);
			} else {
				UpdateXML.addButtonServiceFunction(packageName, serviceName, index, type);
			}
		}
	}

	/*
	 * public ObservableList<ItemBase> getInFunctionList(List<HashMap<String,
	 * List<ItemBase>>> functionList){
	 * //System.out.println("Service Name : : :"+serviceName);
	 * ObservableList<ItemBase> itemList=FXCollections.observableArrayList();
	 * if(functionList!=null) { for(HashMap<String, List<ItemBase>> hash :
	 * functionList) {
	 * 
	 * Iterator i = null; boolean con=true; if (hash != null) { i =
	 * hash.entrySet().iterator(); while (i.hasNext() && i != null) { Entry
	 * entry = (Entry) i.next();
	 * if(entry.getKey().toString().equals(serviceName)) { for(ItemBase item
	 * :(List<ItemBase>) entry.getValue()) { itemList.add(item); }
	 * 
	 * con=false; break; } } if(!con) break; } } //HashMap<String,Object>
	 * hashMap=list.get System.out.println(itemList.size()); return itemList; }
	 * else return null; }
	 */

	
	public  ObservableList<ItemBase> getInputFunctionList(List<HashMap<String, ServiceData>> serviceMapList) {
		System.out.println("Service Name : : :" + serviceName);
		ObservableList<ItemBase> itemList = FXCollections.observableArrayList();
		if (serviceMapList != null) {
			for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
				System.out.println(serviceMap);
				Iterator i = null;
				boolean con = true;
				if (serviceMap != null) {
					i = serviceMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry != null)
							if (entry.getKey().toString().equals(serviceName)) {
								if (((ServiceData) entry.getValue()).getInputItemList() != null)
									for (ItemBase item : ((ServiceData) entry.getValue()).getInputItemList()) {
										// System.out.println("item
										// type"+item.getType());
										// System.out.println("item name
										// "+item.getName());
										if (item.getType().equals("Function")) {
											// System.out.println(functionMapList);
											FunctionData function = getFunction(item.getName());
											// System.out.println(function.getHeader().getName().getTextContent());
											if(function!=null && function.getHeader()!=null && function.getHeader().getName()!=null)
												item.setName(function.getHeader().getName().getTextContent());
										}
										itemList.add(item);
									}
								con = false;
								break;
							}
					}
					if (!con)
						break;
				}
			}
			// HashMap<String,Object> hashMap=list.get
			System.out.println(itemList.size());
			return itemList;
		} else
			return null;
	}

	public  FunctionData getFunction(String function) {
		for (HashMap<String, FunctionData> functionMap : functionMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionMap != null) {
				i = functionMap.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					// System.out.println(entry.getKey().toString());
					if (entry.getKey().toString().compareToIgnoreCase(function) == 0) {
						// System.out.println("found");
						return (FunctionData) entry.getValue();
					}
				}
			}
		}
		return null;
	}

	public void setFunctions() {
		ObservableList<String> list = FXCollections.observableArrayList();
		if(functionMapList!=null)
		for (HashMap<String, FunctionData> functionMap : functionMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionMap != null) {
				i = functionMap.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					list.add(entry.getKey().toString());
				}
			}
		}
		functionList = list;
	}

	public  ObservableList<ItemBase> getOutputFunctionList(List<HashMap<String, ServiceData>> serviceMapList) {
		System.out.println("Service Name : : :" + serviceName);
		ObservableList<ItemBase> itemList = FXCollections.observableArrayList();
		if (serviceMapList != null) {
			for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
				Iterator i = null;
				boolean con = true;
				if (serviceMap != null) {
					i = serviceMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry.getKey().toString().equals(serviceName)) {
							if (((ServiceData) entry.getValue()).getOutputItemList() != null)
								for (ItemBase item : ((ServiceData) entry.getValue()).getOutputItemList()) {
									{
										if (item.getType().equals("Function")) {
											// System.out.println(functionMapList);
											FunctionData function = getFunction(item.getName());
											// System.out.println(function.getHeader().getName().getTextContent());
											if(function!=null && function.getHeader()!=null && function.getHeader().getName()!=null)
											    item.setName(function.getHeader().getName().getTextContent());
										}
										itemList.add(item);
									}
								}
							con = false;
							break;
						}
					}
					if (!con)
						break;
				}
			}
			// HashMap<String,Object> hashMap=list.get
			System.out.println(itemList.size());
			return itemList;
		} else
			return null;
	}
}