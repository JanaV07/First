package controller;

import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.Map.Entry;

import application.MainController;
import gen.doc.DocGenerator;
import gen.doc.PDFGenerator;
import gen.swagger.Swaggerspecgen;
import gen.valueObject.GenValueObject;
import item.FunctionData;
import item.Header;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * Service Main page consisting of all the services inside the package
 * 
 * Document Generator
 * Swagger Generator
 * 
 * @author VJanarthanan
 */
public class ServiceController implements Initializable {
	public static HashMap<String, List<Header>> serviceMap;
	public static String Package;

	@FXML
	private Button swagger;
	@FXML
	private Button document;
	@FXML
	private Button valueObject;
	public static HashMap<String, List<Header>> getServiceMap() {
		return serviceMap;
	}

	public static void setServiceMap(HashMap<String, List<Header>> serviceMap) {
		ServiceController.serviceMap = serviceMap;
	}

	public static String getPackage() {
		return Package;
	}

	public static void setPackage(String package1) {
		Package = package1;
	}

	@FXML
	Label application;
	@FXML
	private TableView<HeaderList> table;
	@FXML
	private TableColumn<Header, String> selectColumn;
	@FXML
	private TableColumn<Header, String> nameColumn;
	@FXML
	private TableColumn<Header, String> categoryColumn;
	@FXML
	private TableColumn<Header, String> datedColumn;
	@FXML
	private TableColumn<Header, String> authorCoulumn;
	

	
	EventHandler<ActionEvent> docButtonHandler = (e)->{
		
		ObservableList<HeaderList> itemList=table.getItems();
		try {
		for(HeaderList header:itemList) {
			if(header.getSelect().isSelected()) {
				
				System.out.println(header.getName());
				
				DocGenerator docGenerator=new DocGenerator(Package,header.getName(),MainController.bulkServiceMap.get(Package),MainController.bulkFunctionMap.get(Package),getFunctions(MainController.bulkFunctionMap.get(Package)),MainController.bulkFunctionMap,MainController.bulkTypeMap);
				Hashtable htService=(Hashtable)docGenerator.createHashTable(false);
				
				PDFGenerator gen=new PDFGenerator(htService,"c://Data//MessageExplorer-Java//Documents//"+Package);
		 		gen.generatePDF();
		 		
		 		
		 		
			}
		}
		Text text = new Text();
		text.setText("Doucment Generated Successfully : : "+Package);
		text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
		text.setX(50);
		text.setY(50);
		Group root = new Group(text);
		Scene scene = new Scene(root, 350, 100);
		Stage stage = new Stage();
		stage.setTitle("Success");
		stage.setScene(scene);
		stage.show();
		
		}
		catch(Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception occured : "+ex);
		}
		
		
		
		
	};
	
EventHandler<ActionEvent> swaggerButtonHandler = (e)->{
		
		ObservableList<HeaderList> itemList=table.getItems();
		Hashtable htService=new Hashtable();
		Vector vHashForService=new Vector();
		 /*vHashForService.add(htOpInput);
    	   vHashForService.add(htOpOutput);
    	   vHashForService.add(htOpValTypesIn);
    	   vHashForService.add(htOpValTypesOut);
    	   vHashForService.add(htOpDescription);*/
		try {
			Hashtable htOpInput=new Hashtable();
			Hashtable htOpOutput=new Hashtable();
			Hashtable htOpValTypesOut=new Hashtable();
			Hashtable htOpValTypesIn=new Hashtable();
		for(HeaderList header:itemList) {
			if(header.getSelect().isSelected()) {
				
				
				
				
				
				System.out.println(header.getName());
				
				DocGenerator docGenerator=new DocGenerator(Package,header.getName(),MainController.bulkServiceMap.get(Package),MainController.bulkFunctionMap.get(Package),getFunctions(MainController.bulkFunctionMap.get(Package)),MainController.bulkFunctionMap,MainController.bulkTypeMap);
				
				String alternate=docGenerator.getAlternateName();
				htOpInput.put(alternate, docGenerator.gethtOpInput());
				htOpOutput.put(alternate, docGenerator.gethtOpOutput());
				htOpValTypesOut.put(alternate, docGenerator.gethtOpValTypesOut());
				htOpValTypesIn.put(alternate, docGenerator.gethtOpValTypesIn());
				
				//Hashtable htService1=docGenerator.createHashTable(true);
				// vHashForService.add(htService1.get(header.getName()));
				
			}
		}
		vHashForService.add(htOpInput);
  	   vHashForService.add(htOpOutput);
  	   vHashForService.add(htOpValTypesIn);
  	   vHashForService.add(htOpValTypesOut);
  	   
  	   
  	   Hashtable htOpDescription=new Hashtable();
		htOpDescription.put("SwaggerVersion","1");
  	   vHashForService.add(htOpDescription);
  	  
  	  
		htService.put(Package, vHashForService);
		Swaggerspecgen gen=new Swaggerspecgen(htService,Package);
 		gen.main();
		Text text = new Text();
		text.setText("Swagger Generated Successfully : : "+Package);
		text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
		text.setX(50);
		text.setY(50);
		Group root = new Group(text);
		Scene scene = new Scene(root, 350, 100);
		Stage stage = new Stage();
		stage.setTitle("Success");
		stage.setScene(scene);
		stage.show();
		
		}
		catch(Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception occured : "+ex);
		}
		
		
		
		
	};
	
	
EventHandler<ActionEvent> valueObjectHandler = (e)->{
		
		ObservableList<HeaderList> itemList=table.getItems();
		Hashtable htService=new Hashtable();
		Vector vHashForService=new Vector();
		 /*vHashForService.add(htOpInput);
    	   vHashForService.add(htOpOutput);
    	   vHashForService.add(htOpValTypesIn);
    	   vHashForService.add(htOpValTypesOut);
    	   vHashForService.add(htOpDescription);*/
		try {
			Hashtable htOpInput=new Hashtable();
			Hashtable htOpOutput=new Hashtable();
			Hashtable htOpValTypesOut=new Hashtable();
			Hashtable htOpValTypesIn=new Hashtable();
		for(HeaderList header:itemList) {
			if(header.getSelect().isSelected()) {
				System.out.println(header.getName());
				DocGenerator docGenerator=new DocGenerator(Package,header.getName(),MainController.bulkServiceMap.get(Package),MainController.bulkFunctionMap.get(Package),getFunctions(MainController.bulkFunctionMap.get(Package)),MainController.bulkFunctionMap,MainController.bulkTypeMap);
				
				String alternate=docGenerator.getAlternateName();
				htOpInput.put(alternate, docGenerator.gethtOpInput());
				htOpOutput.put(alternate, docGenerator.gethtOpOutput());
				htOpValTypesOut.put(alternate, docGenerator.gethtOpValTypesOut());
				htOpValTypesIn.put(alternate, docGenerator.gethtOpValTypesIn());
				
				//Hashtable htService1=docGenerator.createHashTable(true);
				// vHashForService.add(htService1.get(header.getName()));
				
			}
		}
		vHashForService.add(htOpInput);
  	   vHashForService.add(htOpOutput);
  	   vHashForService.add(htOpValTypesIn);
  	   vHashForService.add(htOpValTypesOut);
  	   
  	   
  	   Hashtable htOpDescription=new Hashtable();
		htOpDescription.put("SwaggerVersion","1");
  	   vHashForService.add(htOpDescription);
  	  
  	  
		htService.put(Package, vHashForService);
		GenValueObject gen=new GenValueObject(htService,Package);
 		gen.main();
		Text text = new Text();
		text.setText("Value Object Generated Successfully : : "+Package);
		text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
		text.setX(50);
		text.setY(50);
		Group root = new Group(text);
		Scene scene = new Scene(root, 350, 100);
		Stage stage = new Stage();
		stage.setTitle("Success");
		stage.setScene(scene);
		stage.show();
		
		}
		catch(Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception occured : "+ex);
		}
		
		
		
		
	};
	
	
	
	public ObservableList<String> getFunctions(List<HashMap<String, FunctionData>> functionMapList) {
		ObservableList<String> list = FXCollections.observableArrayList();
		for (HashMap<String, FunctionData> functionMap : functionMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionMap != null) {
				i = functionMap.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					list.add(entry.getKey().toString());
				}
			}
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		application.setText(Package);
		// System.out.println(serviceMap);
		selectColumn.setCellValueFactory(new PropertyValueFactory<Header, String>("select"));
		nameColumn.setCellValueFactory(new PropertyValueFactory<Header, String>("name"));
		categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
		datedColumn.setCellValueFactory(new PropertyValueFactory<>("dated"));
		authorCoulumn.setCellValueFactory(new PropertyValueFactory<>("author"));
		// System.out.println("++++++++++++++++ssss+++: : :
		// :"+nameColumn.getCellData(2));
		table.setItems(getTypeList());
		// System.out.println(getTypeList());
		// System.out.println("+++++++++++++++++++: : :
		// :"+nameColumn.getCellData(2));
		document.setOnAction(docButtonHandler);
		swagger.setOnAction(swaggerButtonHandler);
		valueObject.setOnAction(valueObjectHandler);
		
		
	}

	public ObservableList<HeaderList> getTypeList() {
		List<Header> headerList = serviceMap.get(Package);
		// System.out.println("LIST*******************************************");
		System.out.println(Package);
		System.out.println(serviceMap);
		ObservableList<HeaderList> typeList = FXCollections.observableArrayList();
		for (Header header : headerList) {
			// System.out.println("::: : :"+header.getName().getTextContent());
			HeaderList type = new HeaderList();
			type.setName(header.getName().getTextContent());
			if(header.getAuthor()!=null)
			type.setAuthor(header.getAuthor().getTextContent());
			type.setDated(header.getCreated().getTextContent());
			type.setCategory(header.getCategory().getTextContent());
			type.setSelect(header.getSelect());
			typeList.add(type);
		}
		return typeList;
	}
}