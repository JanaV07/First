package xml;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import application.MainApp;
import item.FunctionData;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import xml.Bean.BaseBean;
import xml.Bean.MapBean;

/**
 *
 * 
 * @author VJanarthanan
 */
public class WriteBase {
	public static void main(String[] args) {
	}

	public static List constructStructure(BaseBean base) {
		String id = base.getId();
		File structFile;
		String dirName = "C:\\Data\\MessageExplorer-Java\\dev";
		String temp = dirName + "\\" + id;
		File dir = new File(dirName);
		structFile = new File(temp);
		if (!structFile.exists()) {
			System.out.println("creating directory: " + structFile.getName());
			try {
				structFile.mkdir();
				System.out.println("DIR created");
				// throw new Exception();
			} catch (Exception se) {
				Text text = new Text();
				text.setText("Error Occur while Creating New Package!!!!");
				text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
				text.setX(50);
				text.setY(50);
				Group root = new Group(text);
				Scene scene = new Scene(root, 600, 100);
				Stage stage = new Stage();
				stage.setTitle("Warning");
				stage.setScene(scene);
				stage.show();
			}
		}
		File[] listOfFiles = structFile.listFiles();
		// System.out.println(Arrays.asList(listOfFiles));
		System.out.println("READING : :" + temp);
		// MainApp.progress="Reading : :"+temp;
		List<HashMap<String, Object>> keyHeaderlist = new ArrayList<HashMap<String, Object>>();
		List<HashMap<String, List<ItemBase>>> functionInputlist = new ArrayList<HashMap<String, List<ItemBase>>>();
		List<HashMap<String, List<ItemBase>>> functionOutputlist = new ArrayList<HashMap<String, List<ItemBase>>>();
		List<HashMap<String, List<ItemBase>>> serviceInputlist = new ArrayList<HashMap<String, List<ItemBase>>>();
		List<HashMap<String, List<ItemBase>>> serviceOutputlist = new ArrayList<HashMap<String, List<ItemBase>>>();
		List<HashMap<String, TypeData>> typeMapList = new ArrayList<HashMap<String, TypeData>>();
		List<HashMap<String, FunctionData>> functionMapList = new ArrayList<HashMap<String, FunctionData>>();
		List<HashMap<String, ServiceData>> serviceMapList = new ArrayList<HashMap<String, ServiceData>>();
		// System.out.println(temp);
		
		if(listOfFiles==null) {
			System.out.println("DIRECTORY IS NOT AVAILABLE");
		}
		else {
			
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				try {
				keyHeaderlist.add(ReadXML.readExistingStructure(listOfFiles[i]));
			}
			catch(Exception e) {
				e.printStackTrace();
				System.out.println("Error occured in Reading XML ");
			}
				// Types//////////////////////////////////////////////
				if (MapBean.typeMap != null) {
					typeMapList.add(MapBean.typeMap);
				}
				////////////////////////// FUNCTION//////////////////////////////
				if (MapBean.functionMap != null) {
					/// System.out.println(MapBean.functionMap);
					functionMapList.add(MapBean.functionMap);
				}
				//////////////////////////// SERVICE//////////////////////////////////
				if (MapBean.serviceMap != null)
					serviceMapList.add(MapBean.serviceMap);
				//////////////////////////////////////////////////////////////////////
				/*
				 * if (MapBean.functionInputBean != null) { //
				 * System.out.println(MapBean.functionInputBean);
				 * functionInputlist.add(MapBean.functionInputBean); } if
				 * (MapBean.functionOutputBean != null) { //
				 * /System.out.println(MapBean.functionOutputBean);
				 * functionOutputlist.add(MapBean.functionOutputBean); } if
				 * (MapBean.serviceInputBean != null) {
				 * serviceInputlist.add(MapBean.serviceInputBean); } if
				 * (MapBean.serviceOutputBean != null) {
				 * serviceOutputlist.add(MapBean.serviceOutputBean); }
				 */
				// System.out.println("File " + listOfFiles[i].getName());
			} else if (listOfFiles[i].isDirectory()) {
				// System.out.println("Directory " + listOfFiles[i].getName());
			}
		}
			
		if (typeMapList.size() > 0) {
			MapBean.setTypeMapList(typeMapList);
		} else
			MapBean.setTypeMapList(null);
		if (functionMapList.size() > 0) {
			MapBean.setFunctionMapList(functionMapList);
			// System.out.println(functionMapList);
		} else
			MapBean.setFunctionMapList(null);
		if (serviceMapList.size() > 0)
			MapBean.setServiceMapList(serviceMapList);
		else
			MapBean.setServiceMapList(null);
		/*
		 * if (functionInputlist.size() > 0) { //
		 * System.out.println(functionInputlist);
		 * MapBean.setFunctionInputlist(functionInputlist); } else
		 * MapBean.setFunctionInputlist(null); if (functionOutputlist.size() >
		 * 0) { // System.out.println(functionInputlist);
		 * MapBean.setFunctionOutputlist(functionOutputlist); } else
		 * MapBean.setFunctionOutputlist(null); if(serviceInputlist.size()>0) {
		 * MapBean.setServiceInputlist(serviceInputlist); } else
		 * MapBean.setServiceInputlist(null); if(serviceOutputlist.size()>0) {
		 * MapBean.setServiceOutputlist(serviceOutputlist); } else
		 * MapBean.setServiceOutputlist(null);
		 * MapBean.setKeyHeaderlist(keyHeaderlist);
		 */
		if (!structFile.exists()) {
			// System.out.println(temp);
			structFile.mkdir();
		}
		}
		return keyHeaderlist;
	}
}