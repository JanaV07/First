package gen.swagger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.Set;
import java.util.Arrays;
import java.util.List;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

import arch.rep.ServiceRepository;
import arch.rep.value.types.StringType;
import arch.util.File;

import gen.utility.Definitions;
import gen.utility.MetaData;
import gen.utility.Parameter1;

/**
* 
* Swagger Generator
* 
* @author NMahalakshmi
*/

public class Swaggerspecgen {

	private String opName, serviceName, outputDirectory, opDesc, serviceVersion;
	private Hashtable htOpIn, htOpOut, htValTypeIn, htValTypeOut, htOpDesc;
	private static Hashtable htService;
	ArrayList typesSeqHolder = null;
	ArrayList typesSeqoutHolder = null;
	LinkedHashMap operationMap = null;
	ArrayList<String> operationList = null;
	LinkedHashMap keyMap = null;
	LinkedHashMap keyOutMap = null;
	LinkedHashMap operationoutputMap = null;
	LinkedHashMap typeMap = null;
	ArrayList typeList = null;
	LinkedHashMap propertyMap = null;
	LinkedHashMap definitionMap = null;
	LinkedHashMap requiredmap = null;
	LinkedHashMap typenameMap = null;
	LinkedHashMap typesamplenameMap = null;
	LinkedHashMap propertyList = null;
	ArrayList<Definitions> defnslst = null;
	// Aniruddha added the maperOperationList for issues
	List<String> maperOperationList = null;

	HashMap<String, String> opMap = new HashMap<String, String>();
	HashMap<String, String> methodMap = new HashMap<String, String>();
	HashMap<String, String> summaryMap = new HashMap<String, String>();
	HashMap<String, String> descriptionMap = new HashMap<String, String>();
	LinkedHashMap resourcemap = new LinkedHashMap<String, ArrayList<String>>();
	LinkedHashMap valueObjectmap = new LinkedHashMap<String, HashMap<String, String>>();
	LinkedHashMap parameterMap = new LinkedHashMap<String, LinkedHashMap<String, Parameter1>>();

	public String packageName;

	public Swaggerspecgen(Hashtable htService, String packageName) {
		this.htService = htService;
		this.packageName = packageName;
	}

	public HashMap readPropertyFile(String propfilname) {
		// System.out.println("In readPropertyFile method");
		Properties prop = new Properties();
		InputStream input;
		HashMap<String, String> propvals = new HashMap<String, String>();
		try {
			File file = new File(propfilname);
			input = new FileInputStream(file);

			prop.load(input);
			// System.out.println("Property File Loaded Succesfully"+propfilname);
			Set<String> propertyNames = prop.stringPropertyNames();
			for (String Property : propertyNames) {
				// System.out.println(Property + ":" + prop.getProperty(Property));
				propvals.put(Property, prop.getProperty(Property));
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return propvals;
	}

	public void readoperationPropertyFile(String propfilname) {
		// System.out.println("In readPropertyFile method");

		Properties prop = new Properties();
		InputStream input;
		// Aniruddha added maperOperationList for the issue faces in generating swagger
		// for piiamps
		maperOperationList = new ArrayList<String>();
		try {
			File file = new File(propfilname);
			input = new FileInputStream(file);

			prop.load(input);
			System.out.println("Property File Loaded Succesfully" + propfilname);
			Set<String> propertyNames = prop.stringPropertyNames();
			for (String Property : propertyNames) {

				System.out.println(Property + ":::::OPERATION MAP ::::" + prop.getProperty(Property));
				String[] descriptions = prop.getProperty(Property).split(";");
				// Aniruddha added the maperOperationList
				maperOperationList.add(Property);
				opMap.put(Property, descriptions[0]);
				methodMap.put(Property, descriptions[1]);
				if (descriptions[2] != null)
					summaryMap.put(Property, descriptions[2]);
				if (descriptions[3] != null)
					descriptionMap.put(Property, descriptions[3]);
			}
			System.out.println("HashMaps generated::" + propfilname);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readresourcePropertyFile(String propfilname) {
		// System.out.println("In readPropertyFile method");
		// System.out.println("In readPropertyFile method reading : "+propfilname);
		Properties prop = new Properties();
		InputStream input;

		try {
			File file = new File(propfilname);
			input = new FileInputStream(file);

			prop.load(input);
			System.out.println("Property File Loaded Succesfully" + propfilname);
			Set<String> propertyNames = prop.stringPropertyNames();
			for (String Property : propertyNames) {

				// System.out.println(Property + ":" + prop.getProperty(Property));
				String[] descriptions = prop.getProperty(Property).split(";");
				ArrayList<String> resourcelist = new ArrayList(Arrays.asList(descriptions));
				resourcemap.put(Property, resourcelist);
			}
			// System.out.println("Resource::::"+ ":" +resourcemap);
			// System.out.println("HashMaps generated::"+propfilname);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readvalueobjectPropertyFile(String propfilname) {
		// System.out.println("In readPropertyFile method");
		// System.out.println("In readPropertyFile method reading : "+propfilname);
		Properties prop = new Properties();
		InputStream input;

		try {
			File file = new File(propfilname);
			input = new FileInputStream(file);

			prop.load(input);
			System.out.println("Property File Loaded Succesfully" + propfilname);
			Set<String> propertyNames = prop.stringPropertyNames();
			for (String Property : propertyNames) {

				// System.out.println(Property + ":" + prop.getProperty(Property));
				String[] descriptions = prop.getProperty(Property).split(",");
				// ArrayList<String> samplelist =new ArrayList( Arrays.asList( descriptions) );
				HashMap<String, String> VOMap = new HashMap<String, String>();
				for (String description : descriptions) {
					String[] keyvalue = description.split(":");
					VOMap.put(keyvalue[0], keyvalue[1]);
				}
				// resourcemap.put(Property, resourcelist);

				valueObjectmap.put(Property, VOMap);
			}
			// System.out.println( "valueObjectmap: : " + valueObjectmap);
			// System.out.println("HashMaps generated::"+propfilname);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readParameterPropertyFile(String propfilname) {
		Properties prop = new Properties();
		InputStream input;

		try {
			File file = new File(propfilname);
			input = new FileInputStream(file);

			prop.load(input);
			System.out.println("Property File Loaded Succesfully" + propfilname);
			Set<String> propertyNames = prop.stringPropertyNames();

			for (String Property : propertyNames) {

				System.out.println(Property + ":" + prop.getProperty(Property));
				String[] descriptions = prop.getProperty(Property).split(";");
				Map<String, Parameter1> paramMap = new LinkedHashMap<String, Parameter1>();
				ArrayList<Parameter1> paramList = new ArrayList<Parameter1>();
				// System.out.println("SIZEEEEEE"+descriptions.length);
				for (int i = 0; i < descriptions.length; i = i + 7) {
					System.out.println(i + 6);
					// System.out.println(descriptions[i]);
					Parameter1 p = new Parameter1();
					p.setMain(descriptions[i]);
					if (descriptions[i + 1] != null)
						p.setIn(descriptions[i + 1]);
					if (descriptions[i + 2] != null)
						p.setDescription(descriptions[i + 2]);
					if (descriptions[i + 3] != null)
						p.setRequired(descriptions[i + 3]);
					if (descriptions[i + 4] != null)
						p.setType(descriptions[i + 4]);
					if (descriptions[i + 5] != null)
						p.setDefaultValue(descriptions[i + 5]);

					if ((i + 6) < descriptions.length && descriptions[i + 6] != null) {
						// System.out.println("enumsList: : : :"+descriptions[i+6]);
						String[] enums = descriptions[i + 6].split(" ");
						if (enums.length > 1) {
							ArrayList<String> enumsList = new ArrayList(Arrays.asList(enums));
							// System.out.println("enumsList: : : :"+enumsList);
							p.setEnumList(enumsList);
						}
					}
					// p.main=descriptions[i];
					// p.in=descriptions[i+1];
					// p.description=descriptions[i+2];
					// p.required=descriptions[i+3];
					// p.type=descriptions[i+4];
					// p.defaultValue=descriptions[i+5];
					System.out.println("description: : sdfdsfdf: :" + descriptions[i]);
					paramList.add(p);
					paramMap.put(descriptions[i], p);
				}

				System.out.println("description: : : :" + paramList);
				// resourcemap.put(Property, resourcelist);
				parameterMap.put(Property, paramMap);
			}
			// System.out.println("Resource::::"+ ":" +resourcemap);
			// System.out.println("HashMaps generated::"+propfilname);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	boolean checkforpropertyfile(String filename) {
		File file = new File(filename);
		boolean exists = file.exists();
		return exists;

	}

	public VelocityContext genSwaggerFile(Hashtable htService, String serviceName, VelocityContext schemaContext,
			String directorypath) {
		operationMap = new LinkedHashMap();
		operationList = new ArrayList<String>();

		keyMap = new LinkedHashMap();
		keyOutMap = new LinkedHashMap();
		operationoutputMap = new LinkedHashMap();
		typeMap = new LinkedHashMap();
		typeList = new ArrayList();
		propertyMap = new LinkedHashMap();
		definitionMap = new LinkedHashMap();
		propertyList = new LinkedHashMap();
		typenameMap = new LinkedHashMap();
		typesamplenameMap = new LinkedHashMap<String, HashMap<String, String>>();
		requiredmap = new LinkedHashMap<String, ArrayList<String>>();
		HashMap<String, String> fieldMap = new HashMap<String, String>();
		HashMap<String, String> respfieldMap = new HashMap<String, String>();
		HashMap<String, String> fieldtypeMap = new HashMap<String, String>();

		String fieldfile = directorypath + "\\FieldMapper.properties";
		String respfieldfile = directorypath + "\\RespFieldMapper.properties";
		String operationfile = directorypath + "\\operationMapper.properties";
		String fieldtypefile = directorypath + "\\fieldTypeMapper.properties";
		String resourcefile = directorypath + "\\resourcefileMapper.properties";
		String valueobjectfile = directorypath + "\\valueobjectMapper.properties";
		String parameterFile = directorypath + "\\parametersMapper.properties";

		boolean fieldmappresent = checkforpropertyfile(fieldfile);
		boolean respfieldmappresent = checkforpropertyfile(respfieldfile);
		boolean fieldtypemappresent = checkforpropertyfile(fieldtypefile);
		boolean resourcemappresent = checkforpropertyfile(resourcefile);
		boolean valueobjectmappresent = checkforpropertyfile(valueobjectfile);
		boolean parametersmappresent = checkforpropertyfile(parameterFile);

		if (fieldmappresent) {
			System.out.println("Property file present::" + fieldfile);
			fieldMap = readPropertyFile(fieldfile);
			System.out.println("HashMaps generated for property::" + fieldfile);
		} else
			System.out.println(fieldfile + " not present..");
		if (respfieldmappresent) {
			System.out.println("Property file present::" + respfieldfile);
			respfieldMap = readPropertyFile(respfieldfile);
			System.out.println("HashMaps generated for property::" + respfieldfile);
		} else
			System.out.println(respfieldfile + " not present..");
		if (fieldtypemappresent) {
			System.out.println("Property file present::" + fieldtypefile);
			fieldtypeMap = readPropertyFile(fieldtypefile);
			System.out.println("fieldtypeMap::" + fieldtypeMap);
			System.out.println("HashMaps generated for property::" + fieldtypefile);
		} else
			System.out.println(fieldtypefile + " not present..");

		if (resourcemappresent) {
			System.out.println("Property file present::" + resourcefile);
			readresourcePropertyFile(resourcefile);
			System.out.println("HashMaps generated for property::" + resourcefile);
		} else
			System.out.println(resourcefile + " not present..");

		if (valueobjectmappresent) {
			System.out.println("Property file present::" + valueobjectfile);
			readvalueobjectPropertyFile(valueobjectfile);
			System.out.println("HashMaps generated for property::" + valueobjectfile);
		} else
			System.out.println(valueobjectfile + " not present..");

		if (parametersmappresent) {

			readParameterPropertyFile(parameterFile);
		}

		readoperationPropertyFile(operationfile);

		System.out.println("!!!!!!!!!!365 " + operationfile);

		ArrayList<Definitions> defnslst = new ArrayList<Definitions>();
		schemaContext.put("serviceName", serviceName);
		serviceVersion = "";
		java.util.Vector vTemp = (java.util.Vector) htService.get(serviceName);

		if (vTemp.size() == 5) {
			htOpIn = (Hashtable) vTemp.get(0);
			// System.out.println("!!!!!!!!!! "+htOpIn);
			htOpOut = (Hashtable) vTemp.get(1);
			htValTypeIn = (Hashtable) vTemp.get(2);
			htValTypeOut = (Hashtable) vTemp.get(3);
			htOpDesc = (Hashtable) vTemp.get(4);
		}

		
	/*	 System.out.println("htOpInput : : "+htOpIn); System.out.println("__________________________________________________________________");
		 
		  System.out.println(" htOpOutput: : "+htOpOut); System.out.println( "__________________________________________________________________");
		  System.out.println(htValTypeIn); System.out.println( "__________________________________________________________________");
		  System.out.println(htValTypeOut); System.out.println("Generating");
		 
*/
		java.util.Enumeration enmIn = htOpIn.keys();
		while (enmIn.hasMoreElements()) {
			opName = (String) enmIn.nextElement();

			if (htOpDesc != null && htOpDesc.containsKey(opName)) {
				opDesc = (String) htOpDesc.get(opName);
			} else {
				opDesc = opName;
				// opDesc = opMap.get(opName);
				// System.out.println("opMap:: "+opMap);
			}

			operationList.add(opName);
			operationMap.put(opName, opDesc);
			schemaContext.put("operationList", operationList);
			schemaContext.put("operationMap", operationMap);
			schemaContext.put("opMap", opMap);
			schemaContext.put("methodMap", methodMap);
			schemaContext.put("summaryMap", summaryMap);
			schemaContext.put("descriptionMap", descriptionMap);
			schemaContext.put("resourcemap", resourcemap);
			schemaContext.put("parameterMap", parameterMap);
			// System.out.println("resourcemap::"+resourcemap);
		}
		// System.out.println("opName::408 "+opName);
		// operationList.add("openAccount");
		// operationMap.put("openAccount", opDesc);
		// schemaContext.put("operationList", operationList);
		// schemaContext.put("operationMap", operationMap);
		System.out.println("operationList412:::: " + operationList);
		System.out.println("mapperOperationList:::: " + maperOperationList);

		for (String operation : maperOperationList) {
			typesSeqHolder = new ArrayList();
			typesSeqoutHolder = new ArrayList();
			Hashtable htInputParms = (Hashtable) htOpIn.get(operation);
			if (htInputParms != null) {
				System.out.println("operation !!!" + operation + ":: " + htInputParms);
				java.util.Enumeration enmParmIn = htInputParms.keys();

				typesamplenameMap = valueObjectmap;

				while (enmParmIn.hasMoreElements()) {
					String keyName = (String) enmParmIn.nextElement();
					String[] typeInfo = (String[]) htInputParms.get(keyName);
					String tempTypeFull = typeInfo[0];
					// String tempchangeTypeFull=null;

					String typeOccurs = typeInfo[1];
					// R

					definitionMap.put(keyName, tempTypeFull);
					keyMap.put(operation, keyName);

					System.out.println("Printing key map:: " + keyMap);
					schemaContext.put("keyMap", keyMap);

				}

				Hashtable htOutputParms = (Hashtable) htOpOut.get(operation);
				java.util.Enumeration enmParmOut = htOutputParms.keys();
				while (enmParmOut.hasMoreElements()) {
					String outkeyName = (String) enmParmOut.nextElement();
					// R
					String tempchangeTypeFull = null;
					// System.out.println("output :: "+ outkeyName);
					operationoutputMap.put(operation, outkeyName);
					schemaContext.put("operationoutputMap", operationoutputMap);
					if (outkeyName.indexOf("|Primitive") == -1) {
						String[] typeInfo = (String[]) htOutputParms.get(outkeyName);

						String typeName = shortenTypeName(typeInfo[0]);
						// System.out.println("typeName :: "+ typeName);
						// typenameMap.put(outkeyName,typeName);
						definitionMap.put(outkeyName, typeName);

						String typeOccurs = typeInfo[1];

					}
					keyOutMap.put(operation, outkeyName);
					schemaContext.put("keyOutMap", keyOutMap);
					// System.out.println("Printing keyOutMap map:: "+keyOutMap);
				}
				schemaContext.put("definitionMap", definitionMap);
				// schemaContext.put("typenameMap", typenameMap);
				schemaContext.put("typesamplenameMap", typesamplenameMap);

				// System.out.println("Printing typenameMap map:: "+typenameMap);
				// System.out.println("definitionMap:::"+ definitionMap);
				Hashtable htValTypes = (Hashtable) htValTypeIn.get(operation);
				String value = null;
				if (keyMap.containsKey(operation)) {
					value = definitionMap.get(keyMap.get(operation).toString()).toString();
					// System.out.println("operation::
					// "+operation+"::"+keyMap.get(operation).toString());
				} else
					System.out.println("operation::in else:: " + operation);

				if (!typesSeqHolder.contains(value))
					typesSeqHolder.add(value);

				// System.out.println("TTTTTTTTTTT"+typesSeqHolder);
				for (int i = 0; i < typesSeqHolder.size(); i++) {
					String keyValType = (String) typesSeqHolder.get(i);
					// R
					// System.out.println("keyValType:: "+keyValType);

					String tempkeyValType = null;
					ArrayList<String> req = new ArrayList<String>();
					HashMap<String, String> tempvoMap = new HashMap<String, String>();

					if (valueObjectmap.containsKey(operation)) {
						tempvoMap = (HashMap) valueObjectmap.get(operation);
						if (tempvoMap.containsKey(keyValType)) {
							tempkeyValType = tempvoMap.get(keyValType);
							// System.out.println("######inside inner map if block");
						} else
							;
						// System.out.println("######inside in if block");
					} else
						;

					Definitions defns = new Definitions();

					if (tempkeyValType != null)
						defns.setDefnName(tempkeyValType);
					else
						defns.setDefnName(keyValType);

					ArrayList alValType = (ArrayList) htValTypes.get(keyValType);
					// System.out.println("@@@@@@@@@@"+htValTypes);
					ArrayList<MetaData> metadatalst = new ArrayList<MetaData>();

					if (alValType != null && !alValType.isEmpty()) {
						for (int j = 0; j < alValType.size(); j++) {
							Hashtable htTemp = (Hashtable) alValType.get(j);
							// System.out.println("!!!!!!!!!!");
							String temptypeNameStr = null;
							MetaData metadata = new MetaData();
							if (htTemp.containsKey("type")) {

								metadata.setDefnType("Object");
								String typeNameStr = (String) htTemp.get("type");
								String name = (String) htTemp.get("name");
								System.out.println("htTEmp : : : : :" + name);
								// R
								if (fieldMap.containsKey(name)) {
									name = (String) fieldMap.get(name);
								}
								// System.out.println("@@@@@@@@@@"+htValTypes);
								System.out.println("I am in DA DDDDDd ");
								metadata.setName(name);
								/*
								 * if (hm.get("nexenName") != null) {
								 * System.out.println("nexenNAme: : : : : : "+(String)hm.get("nexenName")); name
								 * = ((String)hm.get("nexenName")); metadata.setLength(name); }
								 */
								// metadata.setType(typeNameStr);
								if (tempvoMap.containsKey(typeNameStr)) {
									temptypeNameStr = tempvoMap.get(typeNameStr);
									// System.out.println("######inside inner map if block");
								} else
									temptypeNameStr = typeNameStr;

								metadata.setType(temptypeNameStr);

								if (!typesSeqHolder.contains(typeNameStr)) {
									typesSeqHolder.add(typeNameStr);

								}

								if (htTemp.containsKey("properties")) {
									HashMap hm = (HashMap) htTemp.get("properties");
									if (hm.containsKey("maxOccurs")) {
										// String typeOccurs = (String)hm.get("maxOccurs");
										if (hm.get("nexenName") != null) {
											// System.out.println("nexenNAme: : : : : : "+(String)hm.get("nexenName"));
											name = ((String) hm.get("nexenName"));
											metadata.setName(name);
										}
										String typeOccurs = (hm.get("maxOccurs")).toString();
										if (typeOccurs.equalsIgnoreCase("1") || typeOccurs.equalsIgnoreCase("0")
												|| typeOccurs.equals("")) {
											metadata.setOccurs("");
										} else {
											// System.out.println("typeOccurs=["+ typeOccurs +"]");
											metadata.setOccurs(typeOccurs);
										}

									}
									// if no properties then set 'group occurs'
								} else {
									metadata.setOccurs("1");
								}
							} else {

								metadata.setDefnType("Primitive");
								String name = (String) htTemp.get("name");

								if (fieldMap.containsKey(name)) {
									name = (String) fieldMap.get(name);
								}
								metadata.setName(name);
								HashMap hm = (HashMap) htTemp.get("properties");
								String tempType = "";
								String typeStr = "";
								String len = "";
								String precision = "";
								String desc = "";
								String defaultv;
								// System.out.println("(String)htTemp::"+(String)htTemp.get("name"));
								// System.out.println(name+ " :: "+hm.get("mqtype"));
								if (hm.get("length") != null) {
									len = (hm.get("length")).toString();
									metadata.setLength(len);
								}

								if (hm.get("nexenName") != null) {
									// System.out.println("nexenNAme: : : : : : "+(String)hm.get("nexenName"));
									name = ((String) hm.get("nexenName"));

									metadata.setName(name);
								}
								if (hm.get("default") != null) {

									// System.out.println("default: : : : : : "+((String)hm.get("default")).trim());
									defaultv = ((String) hm.get("default"));
									if (defaultv.length() >= 1)
										metadata.setDefaultvalue(defaultv);
								}
								if (hm.get("possibleValues") != null) {
									System.out
									.println("possibleValues: : : : : : " + (String) hm.get("possibleValues"));
									String[] values = ((String) hm.get("possibleValues")).split(",");
									ArrayList<String> possibleValuesList = new ArrayList(Arrays.asList(values));
									metadata.setPossibleValues(possibleValuesList);
								}

								if (hm.get("description") != null) {
									desc = (String) hm.get("description");
									// System.out.println("before replace:" +desc+"after replace:
									// "+desc.replaceAll("\n", "<br />").replaceAll("'", "").replaceAll("\"", ""));
									// metadata.setDescription(desc);
									metadata.setDescription(
											desc.replaceAll("\n", "<br />").replaceAll("'", "").replaceAll("\"", ""));
									// metadata.setDescription(desc.replaceAll("\\s+"," ").replaceAll("'",
									// "").replaceAll("\"", ""));
								}
								if (hm.get("required") != null) {
									String required = hm.get("required").toString();
									metadata.setRequired(required);
									if (required == "true")
										req.add("\"" + name + "\"");

								}
								if (hm.containsKey("maxOccurs")) {
									// String typeOccurs = (String)hm.get("maxOccurs");
									String typeOccurs = ((java.lang.Integer) hm.get("maxOccurs")).toString();
									if (typeOccurs.equalsIgnoreCase("1") || typeOccurs.equalsIgnoreCase("0")
											|| typeOccurs.equals("")) {
										metadata.setOccurs("1");
									} else {
										// System.out.println("typeOccurs=["+ typeOccurs +"]");
										metadata.setOccurs(typeOccurs);
									}

								} else {
									metadata.setOccurs("1");
								}
								if (hm.get("precision") != null) {
									precision = ((java.lang.Integer) hm.get("precision")).toString();
								}
								// if(fieldtypeMap.containsKey((String)htTemp.get("name")))
								if (fieldtypeMap.containsKey(metadata.getName())) {
									typeStr = (String) fieldtypeMap.get(metadata.getName());
									// System.out.println("inside map check ######"+(String)htTemp.get("name")+"type
									// assigned is :##"+typeStr);
								} else if (hm.get("mqtype") != null) {
									tempType = (String) hm.get("mqtype");
									tempType = tempType.toLowerCase();

									typeStr += tempType;
									// System.out.println("typeStr:"+typeStr);
									if (tempType.equals("decimal")) {
										// typeStr += "[" + len + "." + precision + "]";
									}

									else if (tempType.equals("date")) {
										typeStr = typeStr;
									} else {
										if (!len.equalsIgnoreCase("0")) {
											// typeStr += "[" + len + "]";
										} else {
											// typeStr += "[]";
										}
									}

								}

								metadata.setType(typeStr);

							}

							if (!metadata.getType().equalsIgnoreCase("reserved"))
								metadatalst.add(metadata);

						}

					}

					defns.setPropertylist(metadatalst);
					defnslst.add(defns);
					// System.out.println("In key name: block added to defnlist:: " +keyValType);
					// System.out.println("required in this block"+req);

					// requiredmap.put(keyValType,req);
					requiredmap.put(defns.getDefnName(), req);
					// System.out.println("In writing map: ");
					// System.out.println("\""+keyValType+"\""+":"+requiredmap.get(keyValType));
					// System.out.println("\""+defns.getDefnName()+"\""+":"+requiredmap.get(defns.getDefnName()));
					schemaContext.put("requiredmap", requiredmap);
					if (i == typesSeqHolder.size() - 1)
						System.out.println("typesSeqHolder::: " + typesSeqHolder);
				}
				// System.out.println("In firstLOOP PRIMITIVE REQUIRED " +req);

				Hashtable htoutValTypes = (Hashtable) htValTypeOut.get(operation);
				String value1 = definitionMap.get(operationoutputMap.get(operation).toString()).toString();
				if (!typesSeqoutHolder.contains(value1))
					typesSeqoutHolder.add(value1);

				for (int i = 0; i < typesSeqoutHolder.size(); i++) {
					String keyValType = (String) typesSeqoutHolder.get(i);
					ArrayList<String> req1 = new ArrayList<String>();
					// R
					String tempkeyValType = null;
					// System.out.println("#########out "+keyValType);
					HashMap<String, String> tempvoMap = new HashMap<String, String>();

					if (valueObjectmap.containsKey(operation)) {
						tempvoMap = (HashMap) valueObjectmap.get(operation);
						if (tempvoMap.containsKey(keyValType)) {
							tempkeyValType = tempvoMap.get(keyValType);
						} else
							;
					} else
						;

					Definitions defns = new Definitions();

					if (tempkeyValType != null)
						defns.setDefnName(tempkeyValType);
					else
						defns.setDefnName(keyValType);

					// defns.setDefnName(keyValType);
					ArrayList alValType = (ArrayList) htoutValTypes.get(keyValType);
					// System.out.println("@@@@@@@@@@"+alValType);
					ArrayList<MetaData> metadatalst = new ArrayList<MetaData>();
					if (alValType != null && !alValType.isEmpty()) {
						for (int j = 0; j < alValType.size(); j++) {
							Hashtable htTemp = (Hashtable) alValType.get(j);
							// System.out.println("!!!!!!!!!!");
							String temptypeNameStr = null;
							MetaData metadata = new MetaData();
							if (htTemp.containsKey("type")) {

								metadata.setDefnType("Object");
								String typeNameStr = (String) htTemp.get("type");
								String name = (String) htTemp.get("name");
								if (respfieldMap.containsKey(name)) {
									name = (String) respfieldMap.get(name);
								}
								System.out.println(" name to change in obj:: " + name);

								metadata.setName(name);
								if (tempvoMap.containsKey(typeNameStr)) {
									temptypeNameStr = tempvoMap.get(typeNameStr);
									// System.out.println("######inside inner map if block");
								} else
									temptypeNameStr = typeNameStr;

								metadata.setType(temptypeNameStr);
								// metadata.setType(typeNameStr);

								if (!typesSeqoutHolder.contains(typeNameStr)) {
									typesSeqoutHolder.add(typeNameStr);

								}
								if (htTemp.containsKey("properties")) {
									HashMap hm = (HashMap) htTemp.get("properties");
									if (hm.get("nexenName") != null) {
										// System.out.println("nexenNAme: : : : : : "+(String)hm.get("nexenName"));
										name = ((String) hm.get("nexenName"));
										metadata.setName(name);
									}
									if (hm.containsKey("maxOccurs")) {
										// String typeOccurs = (String)hm.get("maxOccurs");
										String typeOccurs = (hm.get("maxOccurs")).toString();
										if (typeOccurs.equalsIgnoreCase("1") || typeOccurs.equalsIgnoreCase("0")
												|| typeOccurs.equals("")) {
											metadata.setOccurs("");
										} else {
											// System.out.println("typeOccurs=["+ typeOccurs +"]");
											metadata.setOccurs(typeOccurs);
										}

									}
									// if no properties then set 'group occurs'
								} else {
									metadata.setOccurs("1");
								}
								// R
								// System.out.println("occurs !!!!!!!!!!!!! "+metadata.getOccurs());
							} else {

								metadata.setDefnType("Primitive");
								String name = (String) htTemp.get("name");

								if (respfieldMap.containsKey(name)) {
									name = (String) respfieldMap.get(name);
								}
								metadata.setName(name);
								HashMap hm = (HashMap) htTemp.get("properties");
								String tempType = "";
								String typeStr = "";
								String len = "";
								String precision = "";
								String desc = "";
								String defaultv = "";
								// System.out.println("hm******"+hm);
								if (hm.get("length") != null) {
									len = (hm.get("length")).toString();
									metadata.setLength(len);
								}
								if (hm.get("description") != null) {
									desc = (String) hm.get("description");
									// System.out.println("before replace:" +desc+"after replace:
									// "+desc.replaceAll("\n", "<br />").replaceAll("'", "").replaceAll("\"", ""));
									// metadata.setDescription(desc);
									metadata.setDescription(
											desc.replaceAll("(\n)", "<br />").replaceAll("'", "").replaceAll("\"", ""));
									// metadata.setDescription(desc.replaceAll("\\s+"," ").replaceAll("'",
									// "").replaceAll("\"", "") );
								}

								if (hm.get("nexenName") != null) {
									// System.out.println("nexenNAme: : : : : : "+(String)hm.get("nexenName"));
									name = ((String) hm.get("nexenName"));
									metadata.setName(name);
								}
								if (hm.get("default") != null) {

									// System.out.println("default: : : : : : "+((String)hm.get("default")).trim());
									defaultv = ((String) hm.get("default"));
									if (defaultv.length() >= 1)
										metadata.setDefaultvalue(defaultv);
								}
								if (hm.get("possibleValues") != null) {
									System.out
									.println("possibleValues: : : : : : " + (String) hm.get("possibleValues"));
									String[] values = ((String) hm.get("possibleValues")).split(",");
									ArrayList<String> possibleValuesList = new ArrayList(Arrays.asList(values));
									metadata.setPossibleValues(possibleValuesList);
								}

								if (hm.containsKey("maxOccurs")) {
									// String typeOccurs = (String)hm.get("maxOccurs");
									String typeOccurs = ((java.lang.Integer) hm.get("maxOccurs")).toString();
									if (typeOccurs.equalsIgnoreCase("1") || typeOccurs.equalsIgnoreCase("0")
											|| typeOccurs.equals("")) {
										metadata.setOccurs("1");
									} else {
										// System.out.println("typeOccurs=["+ typeOccurs +"]");
										metadata.setOccurs(typeOccurs);
									}

								} else {
									metadata.setOccurs("1");
								}
								if (hm.get("required") != null) {
									String required = hm.get("required").toString();
									metadata.setRequired(required);
									if (required == "true")
										req1.add("\"" + name + "\"");
									else
										;
								}
								if (hm.get("precision") != null) {
									precision = ((java.lang.Integer) hm.get("precision")).toString();
								}

								if (fieldtypeMap.containsKey(metadata.getName())) {
									typeStr = (String) fieldtypeMap.get(metadata.getName());
									// System.out.println("inside response map check
									// ######"+(String)htTemp.get("name")+"type assigned is :##"+typeStr);
								} else if (hm.get("mqtype") != null) {
									tempType = (String) hm.get("mqtype");
									tempType = tempType.toLowerCase();
									typeStr += tempType;
									if (tempType.equals("decimal")) {
										// typeStr += "[" + len + "." + precision + "]";
									}

									else if (tempType.equals("date")) {
										typeStr = typeStr;
									} else {
										if (!len.equalsIgnoreCase("0")) {
											// typeStr += "[" + len + "]";
										} else {
											// typeStr += "[]";
										}
									}

								}

								metadata.setType(typeStr);

								// System.out.println(name+ " :: "+metadata.getType());
							}
							if (!metadata.getType().equalsIgnoreCase("reserved"))
								metadatalst.add(metadata);
						}
					}

					defns.setPropertylist(metadatalst);
					defnslst.add(defns);
					// System.out.println("In key name: block added to defnlist:: " +keyValType);
					// System.out.println("In key name: block name " +keyValType);
					// System.out.println("required in this block"+req1);
					requiredmap.put(defns.getDefnName(), req1);
					// requiredmap.put(keyValType,req1);
					// System.out.println("In writing and checking map: ");
					// System.out.println("\""+keyValType+"\""+":"+requiredmap.get(keyValType));
					schemaContext.put("requiredmap", requiredmap);

					if (i == typesSeqoutHolder.size() - 1)
						System.out.println("typesSeqoutHolder::: " + typesSeqoutHolder);
				}
				// System.out.println("test seqout");
				// System.out.println("LIST : " +req1);
			}
		}
		// R
		// System.out.println(defnslst.size());
		schemaContext.put("defnslst", defnslst);

		// System.out.println("Total elements : : "+defnslst.size());
		// System.out.println("TTTTTTTTTTT"+typesSeqHolder);

		return schemaContext;

	}

	private void processHashValType(Hashtable httemp) {
		// System.out.println(httemp);
		if (httemp.containsKey("type")) {

			String typeNameStr = (String) httemp.get("type");
			// R
			// System.out.println("opName=" + opName+ "typeNameStr :: " + typeNameStr);
			if (!typesSeqHolder.contains(typeNameStr)) {
				typesSeqHolder.add(typeNameStr);
			} else {
				// System.out.println("opName=" + opName + " " + typeNameStr + " already in
				// typesSeqHolder array");
			}

			if (httemp.containsKey("properties")) {
				HashMap hm = (HashMap) httemp.get("properties");
				if (hm.containsKey("maxOccurs")) {
					// String typeOccurs = (String)hm.get("maxOccurs");
					String typeOccurs = ((java.lang.Integer) hm.get("maxOccurs")).toString();
					if (typeOccurs.equalsIgnoreCase("-1") || typeOccurs.equalsIgnoreCase("1")
							|| typeOccurs.equalsIgnoreCase("0") || typeOccurs.equals("")) {
						// R
						// System.out.println("group occurs 1");
					} else {
						// System.out.println("typeOccurs=["+ typeOccurs +"]");
						// R
						// System.out.println("group occurs " + typeOccurs);
					}

				}
				// if no properties then set 'group occurs'
			} else {
				// R
				// System.out.println("group occurs 1");
			}

		} else {

			if (httemp.containsKey("name")) {
				String obj = (String) httemp.get("name");

			}

			if (httemp.containsKey("properties")) {
				HashMap hm = (HashMap) httemp.get("properties");
				processHashMapContents(hm);

			} else {

			}

		}
	}

	private void processHashMapContents(HashMap hmap) {
		String tempType = "";
		String len = "";
		String precision = "";
		String typeStr = "xsd:";
		String desc = "";

		if (hmap.get("mqreserved") != null) {
			Boolean resB = (java.lang.Boolean) hmap.get("mqreserved");
			if (resB == Boolean.TRUE) {

				return;
			}
		}

		if (hmap.get("description") != null) {
			desc = (String) hmap.get("description");
			// System.out.println("IN FOR LOOP GET PROCESS HASH MAP CONTENTS: "+desc);
		}

		if (hmap.get("length") != null) {
			len = ((java.lang.Integer) hmap.get("length")).toString();
		}

		if (hmap.get("precision") != null) {
			precision = ((java.lang.Integer) hmap.get("precision")).toString();
		}
		if (hmap.get("mqtype") != null) {
			tempType = (String) hmap.get("mqtype");
			tempType = tempType.toLowerCase();
			typeStr += tempType;
			if (tempType.equals("decimal")) {
				typeStr += "[" + len + "." + precision + "]";
			}

			else if (tempType.equals("date")) {
				typeStr = typeStr;
			} else {
				if (!len.equalsIgnoreCase("0")) {
					typeStr += "[" + len + "]";
				} else {
					typeStr += "[]";
				}
			}

		}
		if (hmap.get("required") != null) {
			Boolean reqB = (java.lang.Boolean) hmap.get("required");
			if (reqB.equals(Boolean.TRUE)) {

			} else {

			}
		} else {
			System.out.println("O");
		}

	}

	public String shortenTypeName(String str) {
		String retStr = str;
		int ptPos = str.lastIndexOf(".");
		if (ptPos != -1 && ptPos < (str.length() - 1))
			retStr = str.substring(ptPos + 1);

		return retStr;
	}

	public void main() throws Exception {
		String directorypath = "c://Data//MessageExplorer-Java//properties//" + packageName;
		// schemaContext.put("ctx_xdef", xDef);

		VelocityEngine engine;
		engine = new VelocityEngine();

		Velocity.init();
		Template schemaFileTemplate;
		schemaFileTemplate = engine.getTemplate("./src/gen/template/swaggerjsonTemplate.vm");

		java.util.Enumeration enmService = htService.keys();
		String serviceName = "";
		while (enmService.hasMoreElements()) {
			serviceName = (String) enmService.nextElement();
			System.out.println("Service Name ::" + serviceName);
			VelocityContext schemaContext = new VelocityContext();
			schemaContext = genSwaggerFile(htService, serviceName, schemaContext, directorypath);
			File theDir = new File("c://Data//MessageExplorer-Java//Swagger//" + packageName);
			FileWriter output = new FileWriter(new File("c://Data//MessageExplorer-Java//Swagger//" + packageName + "/"
					+ serviceName + "_swaggerspec.json"));
			StringWriter writer = new StringWriter();
			schemaFileTemplate.merge(schemaContext, writer);

			output.write(writer.toString());
			output.flush();
			output.close();

		}
		System.out.println("file created");

	}
}