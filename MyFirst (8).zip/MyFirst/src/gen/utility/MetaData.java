package gen.utility;


import java.util.*;

public class MetaData {
String name;
String type;
String occurs;
String description;
String length;
String required;
String defaultvalue;
String defnType;
List<String> possibleValues;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public void setPossibleValues(List possibleValues)
{
	this.possibleValues=possibleValues;
}
public List<String> getPossibleValues()
{
	return possibleValues;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getOccurs() {
	return occurs;
}
public void setOccurs(String occurs) {
	this.occurs = occurs;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getLength() {
	return length;
}
public void setLength(String length) {
	this.length = length;
}
public String getRequired() {
	return required;
}
public void setRequired(String required) {
	this.required = required;
}
public String getDefaultvalue() {
	return defaultvalue;
}
public void setDefaultvalue(String defaultvalue) {
	this.defaultvalue = defaultvalue;
}
public String getDefnType() {
	return defnType;
}
public void setDefnType(String defnType) {
	this.defnType = defnType;
}
}
