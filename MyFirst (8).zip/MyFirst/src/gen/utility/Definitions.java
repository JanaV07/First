package gen.utility;

import java.util.ArrayList;

public class Definitions {
String defnName;
String defnType;
ArrayList<MetaData> propertylist;

public String getDefnName() {
	return defnName;
}
public void setDefnName(String defnName) {
	this.defnName = defnName;
}
public String getDefnType() {
	return defnType;
}
public void setDefnType(String defnType) {
	this.defnType = defnType;
}
public ArrayList<MetaData> getPropertylist() {
	return propertylist;
}
public void setPropertylist(ArrayList<MetaData> propertylist) {
	this.propertylist = propertylist;
}

}
