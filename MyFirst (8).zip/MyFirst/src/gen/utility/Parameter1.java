package gen.utility;

import java.util.*;

public class Parameter1{
	public String main;
	public String in;
	public String description;
	public String required;
	public String type;
	public String defaultValue;
	public List enumList;
	public String getMain() {
		return main;
	}
	public void setMain(String main) {
		this.main = main;
	}
	public List getEnumList() {
		return enumList;
	}
	public void setEnumList(List enumList) {
		this.enumList = enumList;
	}
	
	public String getIn() {
		return in;
	}
	public void setIn(String in) {
		this.in = in;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	 
 }	 