package gen.valueObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import gen.Utility;

public class GenValueObject {

	public Hashtable htService;
	public String packageName;
	
	public Hashtable htOpIn;
	public Hashtable htOpOut;
	public Hashtable htValTypeIn;
	public Hashtable htValTypeOut;
	public Hashtable htOpDesc;
	
	public GenValueObject(Hashtable htService, String packageName) {
		this.htService=htService;
		this.packageName=packageName;
	}

	public void main() {
		 
	        
	        Vector vHashForService=(Vector) htService.get(packageName);
	        
	        htOpIn = (Hashtable) vHashForService.get(0);
			// System.out.println("!!!!!!!!!! "+htOpIn);
			htOpOut = (Hashtable) vHashForService.get(1);
			htValTypeIn = (Hashtable) vHashForService.get(2);
			htValTypeOut = (Hashtable) vHashForService.get(3);
			htOpDesc = (Hashtable) vHashForService.get(4);
	        
	        generateValueObjects(htValTypeIn);
	        generateValueObjects(htValTypeOut);
	   	 System.out.println("htOpInput : : "+htOpIn); System.out.println("__________________________________________________________________");
		 
		  System.out.println(" htOpOutput: : "+htOpOut); System.out.println( "__________________________________________________________________");
		  System.out.println(htValTypeIn); System.out.println( "__________________________________________________________________");
	
		 

	        
	        
	      
		
	}

	private void generateValueObjects(Hashtable htValType) {
		
		java.util.Enumeration enm =  htValType.keys();
	   	while (enm.hasMoreElements()) {
	   		String keyName = (String)enm.nextElement();
	   		System.out.println(keyName);
	   		Hashtable hash=(Hashtable) htValType.get(keyName);
	   		for(Object className:hash.keySet()) {
	   			
	   			
	   			List<Hashtable> blockList=(List<Hashtable>) hash.get(className);
	   			HashMap<String,String> fieldMap=new HashMap<String,String>();
	   			List<String> requiredList=new ArrayList<String>();
	   			for(Hashtable block:blockList) {
	   				
	   				String fieldName=(String)block.get("name");
	   				HashMap propertyMap=(HashMap)block.get("properties");
	   				String type=(String)propertyMap.get("mqtype");
	   				String maxOccurs=(String)propertyMap.get("maxOccurs");
	   				System.out.println("REQUIRED : :: "+propertyMap.get("required"));
	   				if(((String)propertyMap.get("required")).equalsIgnoreCase("true")){
	   					System.out.println("Adding field:: "+fieldName);
	   					requiredList.add(fieldName);
	   				}
	   				String fieldType;
	   				if(type.equals("x")) {
	   					fieldType=getFieldType(type,(String)block.get("type"));
	   				}
	   				else
	   					fieldType=getFieldType(type,null);
	   				
	   				if(maxOccurs!=null && Integer.parseInt(maxOccurs)>0) {
	   					fieldType="java.util.List<"+fieldType+">";
	   				}
	   				
	   				
	   				fieldMap.put(fieldName, fieldType);
	   				generateClass(className.toString(),fieldMap,requiredList);
	   					//System.out.println("field Name : :"+fieldName);
	   				
	   			}
	   			System.out.println(className);
	   			System.out.println(fieldMap);
	   			
	   		}

	   	}
	}

	private void generateClass(String className, HashMap<String, String> fieldMap, List<String> requiredList) {
		System.out.println("required LIST : : :"+requiredList);
		VelocityEngine ve = new VelocityEngine();
		 Properties p = new Properties();
		 p.setProperty("resource.loader", "class");
		 p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
		 ve.init();
		 /*  next, get the Template  */
	        Template t = ve.getTemplate("./src/gen/template/ValueObject.vm");
	        /*  create a context and add data */
	        VelocityContext context = new VelocityContext();
	        context.put("FieldMap",fieldMap);
	        context.put("requiredList", requiredList);

	        Utility util=new Utility();
	        context.put("className", util.makeFirstLetterCapital(className));
	        String packageFolder="arch."+packageName+".value";
	        context.put("package", packageFolder);
	        context.put("util", util);
	        

	        try {
	        	File theDir = new File("C:/Data/MessageExplorer-Java/ValueObjects/"+packageFolder.replace(".", "/"));

	    		// if the directory does not exist, create it
	    		if (!theDir.exists()) {
	    			System.out.println("creating directory: " + theDir.getName());
	    			boolean result = false;

	    			try{
	    				theDir.mkdirs();
	    				result = true;
	    			} 
	    			catch(SecurityException se){
	    				//handle it
	    			}        
	    			if(result) {    
	    				//System.out.println("DIR created");  
	    			}
	    		}
	        	
	        	
				BufferedWriter writer =
					      new BufferedWriter(new FileWriter("C:/Data/MessageExplorer-Java/ValueObjects/"+packageFolder.replace(".", "/")+"/"+util.makeFirstLetterCapital(className)+".java"));
				
				t.merge( context, writer );
				writer.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	private String getFieldType(String type, String block) {
		
		if(block!=null) {
			return "arch."+packageName+".value."+Utility.makeFirstLetterCapital(block);
		}
		else if(type.equals("Date")) {
			return "arch.util.Date";
		}
		else if(type.equals("Integer")) {
			return "java.lang.Integer";
		}
		else if(type.equals("Timestamp")||type.equals("arch.util.DateTime")) {
			return "arch.util.DateTime";
		}
		else if(type.contains("Decimal")) {
			return "java.math.BigDecimal";
		}
		else {
			return "java.lang.String";
		}
		
		
	}
	
	

}
