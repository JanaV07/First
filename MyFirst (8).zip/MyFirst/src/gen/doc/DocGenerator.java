package gen.doc;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Vector;

import controller.InServiceController;
import gen.Utility;
import item.FunctionData;
import item.Header;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *Document Generator 
 * 
 * 
 * @author VJanarthanan
 */
public class DocGenerator {
	public String packageName;
	public String serviceName;
	public String functionName;
	public ServiceData serviceData;
	public List<HashMap<String, ServiceData>> serviceMapList;
	public List<HashMap<String, FunctionData>> functionMapList;
	public ObservableList<String> functionList;
	public Header header;
	public String alternateNameofService;
	public  List<HashMap<String, TypeData>> typeMapListInPackage = null; // contains the types inside package
	public List <String> typeNamesInPackage=null; // contains all the type names in the package
	public List<String> typesInvokedList =null;
	public List<String> typesInvokedList1 =null;
	public HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap = new HashMap<String, List<HashMap<String, FunctionData>>>();
	public HashMap<String, List<HashMap<String, TypeData>>> bulkTypeMap = new HashMap<String, List<HashMap<String, TypeData>>>();

	public DocGenerator( String packageName, String serviceName,
			List<HashMap<String, ServiceData>> serviceMapList, List<HashMap<String, FunctionData>> functionMapList,
			ObservableList<String> functionList, HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap, HashMap<String, List<HashMap<String, TypeData>>> bulkTypeMap) {
		this.packageName = packageName;
		this.serviceName = serviceName;
		this.serviceMapList = serviceMapList;
		this.functionMapList = functionMapList;
		this.functionList = functionList;
		this.serviceData = retrieveServiceData(serviceMapList);
		this.bulkFunctionMap=bulkFunctionMap;
		this.bulkTypeMap=bulkTypeMap;
		this.header = serviceData.getHeader();
		this.alternateNameofService=serviceData.header.getAllElements().get("alternate");
		if(!(alternateNameofService.length()>0)) {
			alternateNameofService=serviceData.header.getAllElements().get("name");
		}
		System.out.println("Service Name : :: " + serviceName);
		System.out.println("Package Name : : ::" + packageName);
		System.out.println("SErvice MAp  : :" + serviceMapList);
		System.out.println("Function Map : :" + functionMapList);
		System.out.println("Function List:::" + functionList);
		System.out.println("Service Data ifleNAe: : :" + serviceData.getFileName());
		System.out.println("Service Data :::" + serviceData.header.getAllElements());

		System.out.println("Service Data :IP LIST: " + serviceData.inputItemList);

	}

	public String getAlternateName() {
		return alternateNameofService;
	}
	private ServiceData retrieveServiceData(List<HashMap<String, ServiceData>> serviceMapList2) {
		if (serviceMapList != null) {
			for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
				Iterator i = null;
				if (serviceMap != null) {
					i = serviceMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry != null)
							if (entry.getKey().toString().equals(serviceName)) {
								return (ServiceData) entry.getValue();
							}
					}
				}
			}
		}
		return null;
	}




	public Object gethtOpInput() {
		Hashtable htOpInput=new Hashtable();
		Hashtable htInputParms=new Hashtable();
		String [] typeInfo= {"",""};
		typeInfo[0]=Utility.makeFirstLetterCapital(alternateNameofService)+"Input";
		htInputParms.put(alternateNameofService+"Input",typeInfo);
		htOpInput.put(alternateNameofService, htInputParms);
		return htInputParms;
	}


	public Object gethtOpOutput() {
		Hashtable htOpOutput=new Hashtable();
		Hashtable htOutputParms=new Hashtable();
		String [] typeInfo1= {"",""};
		typeInfo1[0]=Utility.makeFirstLetterCapital(alternateNameofService)+"Output";
		htOutputParms.put(alternateNameofService+"Output",typeInfo1);
		htOpOutput.put(alternateNameofService, htOutputParms);

		return htOutputParms;
	}

	public Object gethtOpValTypesOut()  {
		Hashtable htOpValTypesOut=new Hashtable();
		htOpValTypesOut.put(alternateNameofService,createHtOpValTypesIn(false));
		return createHtOpValTypesIn(false);
	}

	public Object gethtOpValTypesIn()  {
		Hashtable htOpValTypesIn=new Hashtable();
		htOpValTypesIn.put(alternateNameofService,createHtOpValTypesIn(true));
		return createHtOpValTypesIn(true);
	}

	public Object createHashTable(boolean Swagger) {
		Hashtable htService = new Hashtable();

		Hashtable htOpInput=new Hashtable();
		Hashtable htInputParms=new Hashtable();
		String [] typeInfo= {"",""};
		typeInfo[0]=Utility.makeFirstLetterCapital(alternateNameofService)+"Input";
		htInputParms.put(alternateNameofService+"Input",typeInfo);
		htOpInput.put(alternateNameofService, htInputParms);

		Hashtable htOpValTypesIn=new Hashtable();
		htOpValTypesIn.put(alternateNameofService,createHtOpValTypesIn(true));

		Hashtable htOpOutput=new Hashtable();
		Hashtable htOutputParms=new Hashtable();
		String [] typeInfo1= {"",""};
		typeInfo1[0]=Utility.makeFirstLetterCapital(alternateNameofService)+"Output";
		htOutputParms.put(alternateNameofService+"Output",typeInfo1);
		htOpOutput.put(alternateNameofService, htOutputParms);

		Hashtable htOpValTypesOut=new Hashtable();
		htOpValTypesOut.put(alternateNameofService,createHtOpValTypesIn(false));


		Hashtable htOpDescription=new Hashtable();
		htOpDescription.put("SwaggerVerison","1");

		Vector vHashForService=new Vector();
		vHashForService.add(htOpInput);
		vHashForService.add(htOpOutput);
		vHashForService.add(htOpValTypesIn);
		vHashForService.add(htOpValTypesOut);
		vHashForService.add(htOpDescription);
		htService.put(serviceName, vHashForService);

		System.out.println("htOpInput : : "+htOpInput);
		System.out.println("__________________________________________________________________");

		System.out.println(" htOpOutput: : "+htOpOutput);
		System.out.println("__________________________________________________________________");
		System.out.println(htOpValTypesIn);
		System.out.println("__________________________________________________________________");
		System.out.println(htOpValTypesOut);
		System.out.println("Generating");
		File theDir = new File("c://Data//MessageExplorer-Java//Documents//"+packageName);

		// if the directory does not exist, create it
		
		if (!theDir.exists()) {
			System.out.println("creating directory: " + theDir.getName());
			boolean result = false;

			try{
				theDir.mkdir();
				result = true;
			} 
			catch(SecurityException se){
				//handle it
			}        
			if(result) {    
				//System.out.println("DIR created");  
			}
		}
		if(Swagger)
			return vHashForService;
		return htService;

	}

	public Hashtable createHtOpValTypesIn(boolean input) {
		Hashtable HtOpValTypesIn=new Hashtable();
		List<ItemBase> functionList=null;
		if(input)
			functionList=getInputFunctionList(serviceMapList);
		else
			functionList=getOutputFunctionList(serviceMapList);
		if(functionList!=null)
			for(ItemBase function:functionList) {
				List<HashMap<String, FunctionData>> functionListOfPackage=bulkFunctionMap.get(packageName);
				typesInvokedList=new ArrayList<String>();
				typesInvokedList1=new ArrayList<String>();
				this.typeMapListInPackage=bulkTypeMap.get(packageName);
				typeNamesInPackage=retrieveAllTypeNames(typeMapListInPackage);
				////System.out.println("types in Package : :"+typeNamesInPackage);
				FunctionData functionData=getFunctionData(functionListOfPackage,function.getName());

				String key="";
				if(input)
					key=Utility.makeFirstLetterCapital(alternateNameofService)+"Input";
				else
					key=Utility.makeFirstLetterCapital(alternateNameofService)+"Output";	
				List<Hashtable> propertyMapList=new ArrayList<Hashtable>();
				if(functionData!=null) {

					List<ItemBase> datas=null;
					if(input)
						datas=functionData.inputItemList;
					else
						datas=functionData.outputItemList;
					for(ItemBase data :datas) {
						propertyMapList.add(getHtTemp(data));
					}
				}
				HtOpValTypesIn.put(key,propertyMapList);
				
				while(typesInvokedList1.size()>0)
					for(String typeName:typesInvokedList1) {
						typesInvokedList.add(typeName);
						typesInvokedList1.remove(typeName);
					}
				
				if(typesInvokedList!=null) {

					System.out.println("type InvokedList : : : "+typesInvokedList);
					for(String typeName:typesInvokedList) {
						propertyMapList=new ArrayList<Hashtable>();
						key=typeName;
						TypeData type=getTypeData(typeMapListInPackage,typeName);
						List<ItemBase> items=type.getItemList();
						System.out.println("KEY : : "+key);
						System.out.println(items.size());
						for(ItemBase data :items) {
							propertyMapList.add(getHtTemp(data));
						}
						HtOpValTypesIn.put(key,propertyMapList); 
					}

				}
				////System.out.println(HtOpValTypesIn);

			}
		return  HtOpValTypesIn;

	}

	private List<String> retrieveAllTypeNames(List<HashMap<String, TypeData>> typeMapListInPackage) {
		List<String> names=new ArrayList<String>();
		for(HashMap<String,TypeData> typeMap :typeMapListInPackage)
		{
			Iterator i=typeMap.entrySet().iterator();
			if(i!=null) {
				while(i.hasNext()) {
					names.add(((Entry)i.next()).getKey().toString());
				}
			}
		}

		return names;
	}
	public Hashtable getHtTemp(ItemBase field) {
		Hashtable ht=new Hashtable();
		HashMap fieldPropertyMap=null;

		fieldPropertyMap=new HashMap();

		HashMap propertyMap=new HashMap();
		Iterator i =field.getAllAttributes().entrySet().iterator();
		String name="";
		while (i.hasNext() && i != null) {
			Entry entry = (Entry) i.next();
			if (entry != null) {
				if(entry.getKey().equals("name"))
					name=entry.getValue().toString();
				else
				{
					String key=null;
					key=entry.getKey().toString();
					String value=entry.getValue().toString();
					if(key.equals("type"))
					{
						if(typeNamesInPackage.contains(value))
						{	
							propertyMap.put("mqtype", "x");
							ht.put("type", value);
							if(!typesInvokedList1.contains(value))
								typesInvokedList1.add(value);
						}
						else	
							key="mqtype";
					}
					else if(key.equals("size"))
						key="length";
					if(value.equalsIgnoreCase("yes"))
						value="true";
					else if(value.equalsIgnoreCase("no"))
						value="false";
					propertyMap.put(key, value);
				}

			}		
		}
		ht.put("name", name);
		ht.put("properties", propertyMap);
		////System.out.printn(propertyMap);
		fieldPropertyMap.put(name, propertyMap);
		return ht;
	}
	private TypeData getTypeData(List<HashMap<String, TypeData>> typeMapList,String typeNameToFind) {
		if (typeMapList != null) {
			for (HashMap<String, TypeData> functionMap : typeMapList) {
				Iterator i = null;
				boolean con = true;
				if (functionMap != null) {
					i = functionMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry.getKey().toString().equals(typeNameToFind)) {
							return (TypeData) entry.getValue();
						}
					}
					if (!con)
						break;
				}
			}
		}
		return null;
	}
	private FunctionData getFunctionData(List<HashMap<String, FunctionData>> functionMapList,String functionNameToFind) {
		if (functionMapList != null) {
			for (HashMap<String, FunctionData> functionMap : functionMapList) {
				Iterator i = null;
				boolean con = true;
				if (functionMap != null) {
					i = functionMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry.getKey().toString().equals(functionNameToFind)) {
							return (FunctionData) entry.getValue();
						}
					}
					if (!con)
						break;
				}
			}
		}
		return null;
	}

	public  ObservableList<ItemBase> getInputFunctionList(List<HashMap<String, ServiceData>> serviceMapList) {
		System.out.println("Service Name : : :" + serviceName);
		ObservableList<ItemBase> itemList = FXCollections.observableArrayList();
		if (serviceMapList != null) {
			for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
				System.out.println(serviceMap);
				Iterator i = null;
				boolean con = true;
				if (serviceMap != null) {
					i = serviceMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry != null)
							if (entry.getKey().toString().equals(serviceName)) {
								if (((ServiceData) entry.getValue()).getInputItemList() != null)
									for (ItemBase item : ((ServiceData) entry.getValue()).getInputItemList()) {
										// System.out.println("item
										// type"+item.getType());
										// System.out.println("item name
										// "+item.getName());
										if (item.getType().equals("Function")) {
											// System.out.println(functionMapList);
											FunctionData function = getFunction(item.getName());
											// System.out.println(function.getHeader().getName().getTextContent());
											if(function!=null && function.getHeader()!=null && function.getHeader().getName()!=null)
												item.setName(function.getHeader().getName().getTextContent());
										}
										itemList.add(item);
									}
								con = false;
								break;
							}
					}
					if (!con)
						break;
				}
			}
			// HashMap<String,Object> hashMap=list.get
			System.out.println(itemList.size());
			return itemList;
		} else
			return null;
	}

	public  FunctionData getFunction(String function) {
		for (HashMap<String, FunctionData> functionMap : functionMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionMap != null) {
				i = functionMap.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					// System.out.println(entry.getKey().toString());
					if (entry.getKey().toString().compareToIgnoreCase(function) == 0) {
						// System.out.println("found");
						return (FunctionData) entry.getValue();
					}
				}
			}
		}
		return null;
	}

	public  ObservableList<ItemBase> getOutputFunctionList(List<HashMap<String, ServiceData>> serviceMapList) {
		System.out.println("Service Name : : :" + serviceName);
		ObservableList<ItemBase> itemList = FXCollections.observableArrayList();
		if (serviceMapList != null) {
			for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
				Iterator i = null;
				boolean con = true;
				if (serviceMap != null) {
					i = serviceMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry.getKey().toString().equals(serviceName)) {
							if (((ServiceData) entry.getValue()).getOutputItemList() != null)
								for (ItemBase item : ((ServiceData) entry.getValue()).getOutputItemList()) {
									{
										if (item.getType().equals("Function")) {
											// System.out.println(functionMapList);
											FunctionData function = getFunction(item.getName());
											// System.out.println(function.getHeader().getName().getTextContent());
											if(function!=null && function.getHeader()!=null && function.getHeader().getName()!=null)
												item.setName(function.getHeader().getName().getTextContent());
										}
										itemList.add(item);
									}
								}
							con = false;
							break;
						}
					}
					if (!con)
						break;
				}
			}
			// HashMap<String,Object> hashMap=list.get
			System.out.println(itemList.size());
			return itemList;
		} else
			return null;
	}

}
