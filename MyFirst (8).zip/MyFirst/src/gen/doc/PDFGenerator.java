package gen.doc;



import arch.gx.*;
import arch.gx.layout.*;
import java.util.*;
import java.text.SimpleDateFormat;

//PN. 03-25-2008.
//Important: Bug fixes.
//Bug Fixes -- generate PDF documents anyway in case some of the fields are not valid rows...
//Potentially we may have missing fields due to invalid rows therefore, a closer examination of the
//document against schema definitino must be done!




public class PDFGenerator extends PDFBase {

  private class DataHolder {
  	String fieldName , typeXML, requirement, desc, groupName;
  	boolean bComplete;

  	private DataHolder(){
	  fieldName = ""; typeXML = ""; requirement = ""; desc = ""; groupName = "";
	  bComplete = false;
  	}

  	private void setDataComplete(boolean temp){
  		bComplete = temp;
  	}

  	private boolean getDataComplete(){
  		return bComplete;
  	}

  	private void setFieldName(String temp){
  		fieldName = temp;
  	}

  	private void setGroupName(String temp) {
  		groupName = temp;
  	}

  	private void setTypeXML(String temp){
  		typeXML = temp;
  	}

  	private void setRequirement(String temp){
  		requirement = temp;
  	}

  	private void setDesc(String temp){
  		desc = temp;
  	}


  	private String getFieldName(){
  		return fieldName;
  	}

  	private String getGroupName(){
  		return groupName;
  	}

  	private String getTypeXML(){
  		return typeXML;
  	}

  	private String getRequirement(){
  		return requirement;
  	}

  	private String getDesc(){
  		return desc;
  	}


  }
  private double htSoFar = 0.0;
  private double prevHt = 0.0;
  static int YCOORDINATE = 0,  HEIGHT = 1;
  double[] rectData = new double[2];
  private ArrayList colLineData = new ArrayList();
  private double curColumnHt = 0.0;

  private DataHolder dataSet = null;
  private String opName, serviceName, outputDirectory, opDesc, serviceVersion;
  //private Hashtable htOpValTypeIn, htOpValTypeOut, htValTypeDetailIn, htValTypeDetailOut;
  private Hashtable htOpIn, htOpOut, htValTypeIn, htValTypeOut, htOpDesc, htService;
  private ArrayList typesSeqHolder;
  private int serialNo = 0;
  private boolean bAddInput =false;
  private boolean bAddOutput = false;
  private boolean bValType = false;
  private boolean bPgBreakAdded = false;
  private double reduceHeight = 0.0;
  private String currentGroup = "";
  //private LinkedList groupList = new LinkedList();
  private Mark _footerFrame;
  private Mark _contentFrame;
  private Mark _firstPageContentFrame;
  private Font headerFont;
  private Font footerFont;
  private Font labelFont;
  private Font valueFont;
  private Font superLabelFont;
  private Font helvetica14;
  private Font helvetica14Bold;
  private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mma");
  Date dt1 = new Date();
  private String dt1Str = sdf.format(dt1);
  private double labelWidth;
  private double valueWidth;
  private int pageNumber = 1;
  private int pageCounter = 2;
  private int continuationRow = 0;
  private Size pageSize = null;
  private boolean bGreyBackGround = false;
  private Color greyColor = ColorSpace.RGB.newColor ("#EAEAEA");
  //private Color darkGreyColor = ColorSpace.RGB.newColor("#EAEAEA");
  private Color darkGreyColor = Color.LIGHT_GRAY;
  private Color whiteColor = Color.WHITE;
  private Color blackColor = Color.BLACK;
  private Margins margins = null;
  private ArrayList dataArr = new ArrayList();
  private Object[] dataObj;
  private static final double cellPadding = Unit.INCHES.toRaw (.125);
  private static final double grpCellPadding = Unit.INCHES.toRaw (.125);
  private static final double fldCellPadding = Unit.INCHES.toRaw (.2);
  private static final double column1Width = 133.75;
  private static final double column2Width = 26.75;
  private static final double column3Width = 133.75;
  private static final double column4Width = 26.75;
  private static final double column5Width = 214;
  private double dIndent;
  private String[] titleRow = {"Field", "No.", "XML:Type[Size]", "R/O", "Description"};
  private int multiple = 0;
  //private String imageName = "/arch/webservice/tools/PDF/NetexchangeServices_New.jpg";
  private String imageName = "/Resources/pdf/NetexchangeServices_New.jpg";
  private Image image1;
  private ImageFactory imageFactory = new ImageFactory ();
  private double totHt = 0;
  private double remainingHt = 0;


 public PDFGenerator(Hashtable  htService, String directory){
    
    	outputDirectory = directory;
    	this.htService = htService;

 }

  protected Margins getDefaultPageMargins (){
      Margins res = new Margins ();

      // we want our horizontal and vertical margins set to 1/2 an inch
      res.setVerticalMargins (Unit.INCHES.toRaw (.5));
      res.setHorizontalMargins (Unit.INCHES.toRaw (.5));
      return res;
 }

 private void createFooterFrame()  {
      Rect r;
      // create the frame for the footer and set its rectangle
      r = new Rect (margins.getLeftMargin (),
		    margins.getBottomMargin (),
		    pageSize.getWidth ()
		    - (margins.getLeftMargin () + margins.getRightMargin ()),
		    Unit.INCHES.toRaw (.5));
      _footerFrame = new Mark (r);
 }

  private void createFirstPageFrame() {
      Rect r;
      r = new Rect (margins.getLeftMargin (),
		    margins.getBottomMargin (),
		    pageSize.getWidth ()
		    - (margins.getLeftMargin () + margins.getRightMargin ()),
		    (pageSize.getHeight() - 130));


      _firstPageContentFrame = new Mark(r);
 }

 private void createContentFrame() {
      Rect r;
      r = new Rect (margins.getLeftMargin (),
		    margins.getBottomMargin (),
		    pageSize.getWidth ()
		    - (margins.getLeftMargin () + margins.getRightMargin ()),
		    (pageSize.getHeight() - _footerFrame.getBounds().getHeight()));


	_contentFrame = new Mark (r);

 }

 private void setup (Document document){

       pageSize = document.getDefaultPageSize ();
       margins = document.getDefaultPageMargins ();

       createFooterFrame();
       createFirstPageFrame();
       createContentFrame();

      totHt = _contentFrame.getBounds().getHeight();
      remainingHt = totHt;
      labelWidth = Unit.INCHES.toRaw (2);
      valueWidth = (_contentFrame.getBounds ().getWidth ()
		    - labelWidth - Unit.INCHES.toRaw (.125));
 }

  private void displayFooter (Mark footerFrame, Graphics gx){
      Rect cr = footerFrame.getBounds ();

      footerFrame.clear ();

      //just draw top border for footer frame
      footerFrame.add( new Marks.Border(cr, null, Color.BLACK, true, false, false, false, 1.0));

      TextLabel label = new TextLabel (cr,
				       "Page " + pageNumber,
				       footerFont,
				       Color.BLACK,
				       null,
				       HorizontalAlignment.CENTER,
				       VerticalAlignment.CENTER);
      label.sizeToFit ();
      footerFrame.add (label);


      // offset the date a bit from the left...
      Rect t = cr.copy ();

      t.getOrigin ().moveBy (Unit.INCHES.toRaw (.125), Unit.INCHES.toRaw(-0.16));

      label = new TextLabel (cr,
			     dt1Str,
			     footerFont,
			     Color.BLACK,
			     null,
			     HorizontalAlignment.CENTER,
			     VerticalAlignment.CENTER);


      label.setFrame (t);
      label.setHorizontalAlignment (HorizontalAlignment.LEFT);
      //System.out.println("Label height=" + label.getBounds().getHeight());
      label.sizeToFit ();

      footerFrame.add (label);


      label = new TextLabel (cr,
			     serviceName + "-" + opName + " XML Specification",
			     footerFont,
			     Color.BLACK,
			     null,
			     HorizontalAlignment.CENTER,
			     VerticalAlignment.CENTER);




      label.setFrame (t);
      label.setHorizontalAlignment (HorizontalAlignment.CENTER);
      label.sizeToFit ();

      footerFrame.add (label);

 }

 private Flowable addDocTitleFixed() {
    GridRow r = new GridRow ();
    Text txt1 = new Text("Contents:  ");
    txt1.setFont(helvetica14Bold);
    //r.add(txt1, 250, 150, 0, VerticalAlignment.CENTER);
    r.add(txt1, 150, 75, 0, VerticalAlignment.CENTER);
    Text txt2 = new Text("Service Field Description");
    txt2.setFont(helvetica14Bold);
    //r.add(txt2, 170, 0, 0, VerticalAlignment.CENTER);
    r.add(txt2, 275, 0, 0, VerticalAlignment.CENTER);
    return r;
    //r.add(titleTxt, 420, 160, 0, VerticalAlignment.CENTER);
 }

 private Flowable addDocTitleServiceName(String serviceStr){
    GridRow r = new GridRow ();
    Text txt1 = new Text(" Service:  ");
    txt1.setFont(helvetica14Bold);
    //r.add(txt1, 250, 150, 0, VerticalAlignment.CENTER);
    r.add(txt1, 150, 75, 0, VerticalAlignment.CENTER);
    Text txt2 = new Text(serviceStr);
    txt2.setFont(helvetica14Bold);
    //r.add(txt2, 170, 0, 0, VerticalAlignment.CENTER);
    r.add(txt2, 275, 0, 0, VerticalAlignment.CENTER);
    return r;
 }

 private Flowable addDocTitleInterfaceName(String interfaceStr){
    GridRow r = new GridRow ();
    Text txt1 = new Text("Interface: ");
    txt1.setFont(helvetica14Bold);
    //r.add(txt1, 250, 150, 0, VerticalAlignment.CENTER);
    r.add(txt1, 150, 75, 0, VerticalAlignment.CENTER);
    Text txt2 = new Text(interfaceStr);
    txt2.setFont(helvetica14Bold);
    //r.add(txt2, 170, 0, 0, VerticalAlignment.CENTER);
    r.add(txt2, 275, 0, 0, VerticalAlignment.CENTER);
    return r;
 }

 private Flowable addDocTitleVersion(String versionStr){
    GridRow r = new GridRow ();
    Text txt1 = new Text("Version: ");
    txt1.setFont(helvetica14Bold);
    //r.add(txt1, 250, 150, 0, VerticalAlignment.CENTER);
    r.add(txt1, 150, 75, 0, VerticalAlignment.CENTER);
    Text txt2 = new Text(versionStr);
    txt2.setFont(helvetica14Bold);
    //r.add(txt2, 170, 0, 0, VerticalAlignment.CENTER);
    r.add(txt2, 275, 0, 0, VerticalAlignment.CENTER);
    return r;
 }


 private Flowable addDocTitle(String titleStr){
    GridRow r = new GridRow ();
    Text titleTxt = null;
    titleTxt = new Text(titleStr);
    titleTxt.setFont(headerFont);
    //r.add(titleTxt, 400, 160, 0, VerticalAlignment.CENTER);
    r.add(titleTxt, 420, 160, 0, VerticalAlignment.CENTER);
    return r;
 }

  private GridRow getTitleRow(String[] title){
      GridRow r = new GridRow ();


      Text[] col = new Text[title.length];

      for (int i = 0; i < title.length; i++) {
      	col[i] = new Text (title[i]);
      	col[i].setFont (labelFont);
      	col[i].setColor(whiteColor);
      }


      	r.add (col[0], 133.75, cellPadding, 0, null); // Unit.INCHES.toRaw (.));
      	r.add (col[1], 26.75, 0, 0, null); // Unit.INCHES.toRaw (.));
      	r.add (col[2], 133.75, 0, 0, null); // Unit.INCHES.toRaw (.));
      	r.add (col[3], 26.75, 0, 0, null); // Unit.INCHES.toRaw (.));
      	r.add (col[4], 214, 0, 0, null); // Unit.INCHES.toRaw (.));

      	return r;

 }

  private GridRow getRow(String[] data){

	      double curHt = 0;
	      GridRow r = new GridRow ();
	      boolean doNotReturn = true;

	try {

	      //double curHt = 0;
	      //GridRow r = new GridRow ();


	      if (data[0].equalsIgnoreCase("+Input")){
	      	bAddInput = true;
	      	//return null;
	      	r = null;
	      	doNotReturn = false;
	      } else if (data[0].equalsIgnoreCase("+Output")){
	      	bAddOutput = true;
	      	//return null;
	      	r = null;
	      	doNotReturn = false;
	      } else if (data[0].equalsIgnoreCase("+valType")){
	      	bValType = true;
	      	//return null;
	      	r = null;
	      	doNotReturn = false;
	      }


	     if (doNotReturn) {

		      Text[] col = new Text[data.length];

		      for (int i = 0; i < data.length; i++) {
		      	col[i] = new Text (data[i]);
		      	//if (i == data.length - 1) System.out.println("data=>" + (String)data[i]);
		      	if(data[4] != null && data[4].length() > 2600 ){
				  System.out.println("The field ---->"+data[0]+"--- Contains description greater than 2600");
				  col[4] = new Text ("PLEASE REFER SEPERATE DOCUMENT FOR THIS FIELD DESCRIPTION");
				}
		      	col[i].setFont (valueFont);

		      }



			/*
			if (data[2].equalsIgnoreCase("group occurs")) {
				r.add (col[0], column1Width, grpCellPadding, 0, null); // Unit.INCHES.toRaw (.));
			} else {
		      		r.add (col[0], column1Width, fldCellPadding, 0, null); // Unit.INCHES.toRaw (.));
		      	}
      	*/

			r.add (col[0], column1Width, fldCellPadding, 0, null); // Unit.INCHES.toRaw (.));
		      	r.add (col[1], column2Width, cellPadding, 0, null); // Unit.INCHES.toRaw (.));
		      	r.add (col[2], column3Width, 0, 0, null); // Unit.INCHES.toRaw (.));
		      	r.add (col[3], column4Width, cellPadding, 0, null); // Unit.INCHES.toRaw (.));
		      	r.add (col[4], column5Width, 0, 0, null); // Unit.INCHES.toRaw (.));

			//if (data[2].equalsIgnoreCase("group occurs")) r.setBackgroundColor(darkGreyColor);

		} //end of doNotReturn

	  } catch (Exception e) {
	  	e.printStackTrace();

	  } finally {
	  	return r;             //NOSONAR
	  }



 }


private ArrayList GetDetailFlowables(){

	ArrayList rowsFD = new ArrayList();
	ArrayList rows = new ArrayList();

	int i;
	htSoFar = 0.0;
	prevHt = 0.0;
	double tempSoFarHt = 0.0;
	reduceHeight = 0.0;
	curColumnHt = 0.0;
	double curTableHt = 0.0;
	double curContentsHt = 0.0;
	colLineData = new ArrayList();
	rectData[YCOORDINATE] = 0; rectData[HEIGHT] = 0;
	double yCoord = 0.0;

	if (continuationRow == dataObj.length) return null;

	FlowingData fd1 = new FlowingData(_contentFrame.getBounds());

	double totalHt = _contentFrame.getBounds().getHeight() - 72;
	double curFlowableHt = 0.0;

	//dbj 10/14/2005
	double htAdjustment = Unit.INCHES.toRaw (.5);
	//double htAdjustment = 0.0;

	GridRow r1 = null;
	GridRow r2 = null;

	rowsFD.add(Flowables.makeSeparator (Unit.INCHES.toRaw (.5)));
	fd1.tryFit(rowsFD);
	curFlowableHt = fd1.getHeightOfCurrentFlowable();


	//System.out.println("original curFlowableHt=" + curFlowableHt + " and htAdjustment=" + htAdjustment);
	htSoFar += (curFlowableHt - htAdjustment);


	i = continuationRow;

	//System.out.println(serviceName + "->i=" + i);

	if (getRow((String[])dataObj[i]) == null) {

        /* debug PN
		String[] temp1 = (String[])dataObj[i];
		System.out.println("Field-->" + temp1[0]);
		System.out.println("Desc-->" + temp1[4]);

	    System.out.println("data row is null");
	    */

		if (bAddInput) {
			i++;
		 	bAddInput = false;
		 	//bAddOutput = true;
      		 	Text gridTitle1 = new Text ("Request XML Mapping Document");
      		 	Text gridTitle2 = new Text ("Request XML Mapping Document");
      		 	//gridTitle1.setFont (labelFont);
      		 	gridTitle1.setFont (superLabelFont);
      			gridTitle1.setColor (Color.BLACK);
      			rowsFD.add(gridTitle1);
      		 	//gridTitle2.setFont (labelFont);
      		 	gridTitle2.setFont (superLabelFont);
      			gridTitle2.setColor (Color.BLACK);
      			rows.add(gridTitle2);
			fd1.tryFit(rowsFD);
			curFlowableHt = fd1.getHeightOfCurrentFlowable();
			htSoFar += (curFlowableHt - htAdjustment);


			reduceHeight = (curFlowableHt - htAdjustment);

	  	} else if (bAddOutput) {
			if (!bPgBreakAdded){
			  continuationRow = i;
			  bPgBreakAdded = true;

			  //&&&&&&&&&&&&&&&&&&&&&&&
			  //add code for rectData[] here
			  yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (.5)) ;


			  //dbj 10/17/2005
			  //tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
			  tempSoFarHt = (curTableHt - reduceHeight);
			  curTableHt = 0.0;

			  if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
			  else rectData[YCOORDINATE] = 0.0;
			  if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
			  else rectData[HEIGHT] = 0.0;
			  colLineData.add(rectData);

			  return rows;
			}

			i++;
		  	bAddOutput = false;
		  	bPgBreakAdded = false;
      		 	Text gridTitle1 = new Text ("Response XML Mapping Document");
      		 	Text gridTitle2 = new Text ("Response XML Mapping Document");
      		 	gridTitle1.setFont (superLabelFont);
      			gridTitle1.setColor (Color.BLACK);
      			rowsFD.add(gridTitle1);
      		 	gridTitle2.setFont (superLabelFont);
      			gridTitle2.setColor (Color.BLACK);
      			rows.add(gridTitle2);
			fd1.tryFit(rowsFD);
			curFlowableHt = fd1.getHeightOfCurrentFlowable();
			htSoFar += (curFlowableHt - htAdjustment);

			reduceHeight = (curFlowableHt - htAdjustment);

		} else if (bValType){

			//&&&&&&&&&&&&&&&&&&&&&&&
			//add code for rectData[] here
			//yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (.5)) ;
			yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (1) ) ;

			//dbj 10/17/2005
			//tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
			tempSoFarHt = (curTableHt - reduceHeight);
			curTableHt = 0.0;

   		  	if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
			else rectData[YCOORDINATE] = 0.0;
			if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
			else rectData[HEIGHT] = 0.0;
			colLineData.add(rectData);
			rectData = new double[2];
			prevHt = tempSoFarHt;

			i++;

			bValType = false;
			bPgBreakAdded = false;
			String[] tempData = (String[])dataObj[i];

      		 	Text gridTitle1 = new Text (tempData[0]);
      		 	Text gridTitle2 = new Text (tempData[0]);
      		 	gridTitle1.setFont (labelFont);
      			gridTitle1.setColor (Color.BLACK);
      			rowsFD.add(gridTitle1);
      		 	gridTitle2.setFont (labelFont);
      			gridTitle2.setColor (Color.BLACK);
      			rows.add(gridTitle2);
			fd1.tryFit(rowsFD);
			curFlowableHt = fd1.getHeightOfCurrentFlowable();
			htSoFar += (curFlowableHt - htAdjustment);
			reduceHeight = (curFlowableHt - htAdjustment);
			i++;
		}

	}

	r1 = getTitleRow(titleRow);
	r2 = getTitleRow(titleRow);

	r1.setBackgroundColor(blackColor);
	r2.setBackgroundColor(blackColor);
	rowsFD.add(r1);
	rows.add(r2);

	fd1.tryFit(rowsFD);
	curFlowableHt = fd1.getHeightOfCurrentFlowable();
	htSoFar += (curFlowableHt - htAdjustment);


	curTableHt += (curFlowableHt  - htAdjustment);

	while (htSoFar < totalHt && i < dataObj.length) {

		if (getRow((String[])dataObj[i]) == null) {
		  	if (bAddOutput) {
				if (!bPgBreakAdded){
				  continuationRow = i;

				  htSoFar += htAdjustment;

				  bPgBreakAdded = true;

				  //&&&&&&&&&&&&&&&&&&&&&&&
				  //add code for rectData[] here
			  	  yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (.5)) ;

			  	  //dbj 10/17/2005
			  	  //tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
			  	  tempSoFarHt = (curTableHt - reduceHeight);
			  	  curTableHt = 0.0;

  	  			  if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
				  else rectData[YCOORDINATE] = 0.0;
				  if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
				  else rectData[HEIGHT] = 0.0;
			  	  colLineData.add(rectData);

				  return rows;
				}
			} else if (bValType){

			 	 //&&&&&&&&&&&&&&&&&&&&&&&
			 	//add code for rectData[] here

				//yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar - Unit.INCHES.toRaw (.5)) ;
				yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar - Unit.INCHES.toRaw (1) ) ;

				//dbj 10/17/2005
				//tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
				tempSoFarHt = (curTableHt - reduceHeight);
			  	curTableHt = 0.0;

			  	if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
		  		else rectData[YCOORDINATE] = 0.0;
		  		if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
		  		else rectData[HEIGHT] = 0.0;
				colLineData.add(rectData);
				rectData = new double[2];
				//prevHt = tempSoFarHt;
				prevHt += tempSoFarHt;


				i++;


				bValType = false;
				bPgBreakAdded = false;
				String[] tempData = (String[])dataObj[i];

	      		 	Text gridTitle1 = new Text (tempData[0]);
      			 	Text gridTitle2 = new Text (tempData[0]);
      			 	gridTitle1.setFont (labelFont);
      				gridTitle1.setColor (Color.BLACK);
      				rowsFD.add(gridTitle1);
      		 		gridTitle2.setFont (labelFont);
      				gridTitle2.setColor (Color.BLACK);
      				rows.add(gridTitle2);
//===============================================================


      				if (!fd1.tryFit(rowsFD)) {
					fd1 = new FlowingData(_contentFrame.getBounds());
					rowsFD = new ArrayList();
					rowsFD.add(Flowables.makeSeparator (Unit.INCHES.toRaw (.5)));
					gridTitle1 = new Text (tempData[0]);
      			 		gridTitle1.setFont (labelFont);
      					gridTitle1.setColor (Color.BLACK);
					rowsFD.add(gridTitle1);
					fd1.tryFit(rowsFD);
				}
				curFlowableHt = fd1.getHeightOfCurrentFlowable();
				htSoFar += (curFlowableHt - htAdjustment);

				//extra statement - the following one
				reduceHeight = (curFlowableHt - htAdjustment);


				if (htSoFar >= totalHt) {
					continuationRow = i-1;
					//System.out.println("subtracting curFlowableHt - htAdjustment =" + (curFlowableHt - htAdjustment));
					htSoFar  -= (curFlowableHt - htAdjustment) ;
					htSoFar +=  htAdjustment;


					rows.remove(gridTitle2);


					break;
				}

//================================================================

				//add column titles for the grid
				r1 = getTitleRow(titleRow);
				r2 = getTitleRow(titleRow);
				r1.setBackgroundColor(blackColor);
				r2.setBackgroundColor(blackColor);
				rowsFD.add(r1);
				rows.add(r2);
//==================================================================

				if (!fd1.tryFit(rowsFD)) {
					fd1 = new FlowingData(_contentFrame.getBounds());
					rowsFD = new ArrayList();
					rowsFD.add(Flowables.makeSeparator (Unit.INCHES.toRaw (.5)));
					r1 = getTitleRow(titleRow);
					r1.setBackgroundColor(blackColor);
					rowsFD.add(r1);
					fd1.tryFit(rowsFD);
				}
				curFlowableHt = fd1.getHeightOfCurrentFlowable();
				htSoFar += (curFlowableHt - htAdjustment);


				if (htSoFar >= totalHt) {
					continuationRow = i-1;
					htSoFar  -= (curFlowableHt - htAdjustment) ;
					htSoFar +=  htAdjustment;

					rows.remove(r2);
					rows.remove(gridTitle2);

//dbj 10/17/2005
/*
				 	 //&&&&&&&&&&&&&&&&&&&&&&&
				 	//add code for rectData[] here

					yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (.5)) ;
					tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
				  	if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
			  		else rectData[YCOORDINATE] = 0.0;
			  		if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
			  		else rectData[HEIGHT] = 0.0;
					colLineData.add(rectData);
					rectData = new double[2];
					//prevHt = tempSoFarHt;
					prevHt += tempSoFarHt;
*/
					break;

				} else {
					i++;
					curTableHt += (curFlowableHt - htAdjustment);
				}



//====================================================================

			}

		}


		//System.out.println(Arrays.asList(dataObj));
		r1 = getRow((String[])dataObj[i]);
		r2 = getRow((String[])dataObj[i]);

		//PN debug - uncomment these lines to find out where it breaks.
		String[] temp1 = (String[])dataObj[i];
		System.out.println("Field-->" + temp1[0]);
		System.out.println("Desc-->" + temp1[4]);

		//if (r1 == null || r2 == null) {
		//   System.out.println("data row r1 or r2 is null");
		//}

		//PN - check for null before using.
		if (r1!= null && r1.getBackgroundColor() == null ) {
	      		if (bGreyBackGround) {
				r1.setBackgroundColor(whiteColor);
				r2.setBackgroundColor(whiteColor);
				bGreyBackGround = false;
	      		} else {
				r1.setBackgroundColor(greyColor);
				r2.setBackgroundColor(greyColor);
				bGreyBackGround = true;
	      		}
	      	}
	    if (r1!=null) { //PN
		    rowsFD.add(r1);
		    rows.add(r2);
	    }




		if (!fd1.tryFit(rowsFD)) {
			fd1 = new FlowingData(_contentFrame.getBounds());
			rowsFD = new ArrayList();
			rowsFD.add(Flowables.makeSeparator (Unit.INCHES.toRaw (.5)));
			r1 = getRow((String[])dataObj[i]);
			if (r1!=null) { //PN
    			if (bGreyBackGround) {
    				r1.setBackgroundColor(greyColor);
    			} else {
    				r1.setBackgroundColor(whiteColor);
    			}
    			rowsFD.add(r1);
    	    }
			//String[] temp1 = (String[])dataObj[i];
			//System.out.println("FD-->" + temp1[0]);
			fd1.tryFit(rowsFD);

		}
		curFlowableHt = fd1.getHeightOfCurrentFlowable();

		//AM Oct 8 2008 -Fix for loop issue in pdf generation
		if(curFlowableHt >706)
		{
			curFlowableHt = 705.00;
			if(curFlowableHt > 717.52){
			  System.out.println("curFlowableHt Far ="+curFlowableHt);
			  System.out.println("Operation Name ="+opName);
			}
		}


		htSoFar += (curFlowableHt - htAdjustment);


		//System.out.println("Ht So Far =" + htSoFar + " (curFlowableHt - htAdjustment) = " + (curFlowableHt - htAdjustment));

		if (htSoFar >= totalHt) {
			continuationRow = i;
			//System.out.println("subtracting curFlowableHt - htAdjustment =" + (curFlowableHt - htAdjustment));

			htSoFar  -= (curFlowableHt - htAdjustment) ;
			htSoFar +=  htAdjustment;



			rows.remove(r2);


			//&&&&&&&&&&&&&&&&&&&&&&&
			//add code for rectData[] here
			yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (.5)) ;


			//dbj 10/17/2005
			//tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
			tempSoFarHt = (curTableHt - reduceHeight);
			curTableHt = 0.0;
			if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
			else rectData[YCOORDINATE] = 0.0;
			if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
			else rectData[HEIGHT] = 0.0;
			colLineData.add(rectData);
			rectData = new double[2];
			prevHt = tempSoFarHt;

			break;
		} else {
			curTableHt += (curFlowableHt - htAdjustment);
			i++;
		}



		if (i == dataObj.length) {
			continuationRow = dataObj.length;
			htSoFar += htAdjustment;


			  //&&&&&&&&&&&&&&&&&&&&&&&
			  //add code for rectData[] here
			yCoord = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar  - Unit.INCHES.toRaw (.5)) ;


			//dbj 10/17/2005
			//tempSoFarHt = htSoFar - Unit.INCHES.toRaw(.5) - reduceHeight - prevHt;
		  	tempSoFarHt = curTableHt - reduceHeight;
			curTableHt = 0.0;

			if (yCoord >= 0.0)  rectData[YCOORDINATE] = yCoord;
			else rectData[YCOORDINATE] = 0.0;
			if (tempSoFarHt >= 0.0) rectData[HEIGHT] = tempSoFarHt;
			else rectData[HEIGHT] = 0.0;
			colLineData.add(rectData);
		}

	}

	return rows;

}



protected int run (Document document) throws Exception {


      	FlowableManager mgrPage1 = new FlowableManager();
      	FlowableManager mgrPage2 = null;


      	setup (document);

      	Graphics gx;
      	Page page = document.beginPage ();
	gx = page.getGraphics ();

	headerFont = gx.findFont ("Helvetica-BoldOblique", 22);
	//footerFont = gx.findFont ("Helvetica-Bold", 15);
	footerFont = gx.findFont ("Helvetica", 9);
	//footerFont = gx.findFont ("ZapfDingbats", 9);
	//footerFont = gx.findFont("Arial", 10);
	//labelFont = gx.findFont ("Helvetica-Bold", 10);
	//valueFont = gx.findFont ("Helvetica", 10);
	helvetica14 = gx.findFont("Helvetica", 14);
	helvetica14Bold = gx.findFont("Helvetica-Bold", 14);
	superLabelFont = gx.findFont("Helvetica-Bold", 11);
	labelFont = gx.findFont ("Times-Bold", 10);
	valueFont = gx.findFont("Times-Roman", 10);

	//-----------------Page 1---------------------------------------
		java.io.InputStream propIn = null;
	   if ((propIn = getClass().getResourceAsStream(imageName)) != null )
	      image1 = imageFactory.readImage (propIn);
	   else
	   {
      	System.out.println("Unable to load resource:" + imageName);
	      return -1;
	   }
              double angle = 0.0;


              Rect contentRect = page.getContentRect ();
              Point middle = new Point (contentRect.getMidX(),
                                        contentRect.getMaxY ()-10);
              gx.gsave ();
              gx.translate (middle);
              gx.rotate (angle);

              double cw = contentRect.getWidth () - 100.0;
              double ch = contentRect.getHeight () - 100.0;


              Size imageSize = image1.getSize ().copy ();

              while (imageSize.getWidth () > cw
                     || imageSize.getHeight () > ch)
                {
                  imageSize.set (imageSize.getWidth () * 0.9,
                                 imageSize.getHeight () * 0.9);
                }
              Point where = new Point (- (imageSize.getWidth () / 2.0),
                                       - (imageSize.getHeight () / 2.0));


              gx.drawImage (where, imageSize, image1);
              gx.grestore ();


      	       mgrPage1.addFlowable (Flowables
			   .makeSeparator (Unit.INCHES.toRaw (.125)));


      		double border_height = (valueFont.getLineHeight ()
			      - valueFont.getDescender ());

      		Flowable justALine =  Flowables.wrapMark (new Marks.Border (new Rect (0, 0, 0, border_height),
								null,
								Color.BLACK,
								false,
								true,
								false,
								false,
								1),
					      false,
					      true);

		mgrPage1.addFlowable(justALine);

//dbj 02/15/2006
//		mgrPage1.addFlowable (Flowables
//			   .makeSeparator (Unit.INCHES.toRaw (3)));
		mgrPage1.addFlowable (Flowables
			   .makeSeparator (Unit.INCHES.toRaw (2.7)));

		Flowable titleFixed = addDocTitleFixed();
		mgrPage1.addFlowable(titleFixed);

		mgrPage1.addFlowable (Flowables.makeSeparator (Unit.INCHES.toRaw (.3)));

		//dbj 02/14/2006
		//------
		Flowable titleService = addDocTitleServiceName(serviceName);
		mgrPage1.addFlowable(titleService);
		mgrPage1.addFlowable (Flowables.makeSeparator (Unit.INCHES.toRaw (.3)));

		Flowable titleFl = addDocTitleInterfaceName(opDesc);
		//------

		//Flowable titleFl = addDocTitle(opDesc);

		mgrPage1.addFlowable(titleFl);

		if (!serviceVersion.equals("")) {
		   mgrPage1.addFlowable (Flowables.makeSeparator (Unit.INCHES.toRaw (.3)));
		   Flowable titleVersion = addDocTitleVersion(serviceVersion);
		   mgrPage1.addFlowable(titleVersion);
		}

		page.add (_firstPageContentFrame);
		//dbj 02/14/2006
		page.add (_footerFrame);

        	mgrPage1.buildMarks (_firstPageContentFrame);

              //dbj 02/14/2006
              displayFooter (_footerFrame, gx);
              	page.draw ();
              	endPage (document);
         	mgrPage1.clearFlowables();
              	pageNumber++;

	//--------------End Page 1 ----------------------------------------

	//java.util.List rowFlow ;
	ArrayList rowsFlowable;

	//dbj 03/17/2005
	//FillDataArray();

	//System.setProperty("arch.gx.layout.FlowableManager.debug", "true");
	boolean bNotDone = true;
	while (bNotDone)  {

		mgrPage1 = new FlowableManager();

		//rowFlow = new ArrayList();

		//PN debug
		//try {
    		rowsFlowable = GetDetailFlowables();
    	//}catch (Exception e) {
	    //    System.out.println("getDetailFlowables() failed!");
		//    rowsFlowable = null;
		//}

		if (rowsFlowable != null) {
			mgrPage1.addFlowable (Flowables.makeSeparator (Unit.INCHES.toRaw (.5)));
		  	mgrPage1.addFlowables(rowsFlowable);

		  	page = document.beginPage ();
		  	gx = page.getGraphics ();

			double yVal = margins.getBottomMargin () + _footerFrame.getBounds().getHeight() + (_contentFrame.getBounds().getHeight() - htSoFar - Unit.INCHES.toRaw (.5)) ;
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			page.add (_contentFrame);
			Mark box = null, boxCol1 = null, boxCol2 = null, boxCol3 = null, boxCol4 = null;
			Rect cr = null, Col1 = null, Col2 = null, Col3 = null, Col4 = null;

			for (int i =0; i < colLineData.size(); i++) {

				rectData  = (double[])colLineData.get(i);
				cr = new Rect(margins.getLeftMargin(), rectData[YCOORDINATE],
						535.00, rectData[HEIGHT]);
			  	//box = new Marks.Box (cr, null, Color.RED);
			  	box = new Marks.Box (cr, null, Color.GRAY);

		  		Col1 = new Rect(margins.getLeftMargin()+ column1Width-1, rectData[YCOORDINATE],
		  					0.5, rectData[HEIGHT]);
			  	boxCol1 = new Marks.Box(Col1, null, Color.GRAY);

		  	  	Col2 = new Rect(margins.getLeftMargin()+ column1Width + column2Width -1, rectData[YCOORDINATE],
			  				0.5, rectData[HEIGHT]);
			  	boxCol2 = new Marks.Box(Col2, null, Color.GRAY);

			  	Col3 = new Rect(margins.getLeftMargin()+ column1Width + column2Width + column3Width -1, rectData[YCOORDINATE],
			  				0.5, rectData[HEIGHT]);
			  	boxCol3 = new Marks.Box(Col3, null, Color.GRAY);

			  	Col4 = new Rect(margins.getLeftMargin()+ column1Width + column2Width + column3Width + column4Width -1, rectData[YCOORDINATE],
			  				0.5, rectData[HEIGHT]);
		  		boxCol4 = new Marks.Box(Col4, null, Color.GRAY);

		  		page.add (box);
		  		page.add(boxCol1);
	  			page.add(boxCol2);
	  			page.add(boxCol3);
	  			page.add(boxCol4);

			}


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





	  		page.add (_footerFrame);


			mgrPage1.buildMarks (_contentFrame);


		   	displayFooter (_footerFrame, gx);
	  		page.draw ();

	  		_contentFrame.clear ();

		  	pageNumber++;

		 	endPage (document);

		 	createContentFrame();

			rowsFlowable = null;

		} else {

			break;

		}

	}

	return 0;


 }


private void FillDataArray(DataHolder data) {
	String fld = "", srNo ="", type = "", req = "", des = "", grp = "";
	boolean bAddFlag = false;

	if (data.getDataComplete()) {
	   type = data.getTypeXML();
	   if (!type.startsWith("xsd:reserved")) {
	      bAddFlag = true;
   		fld = data.getFieldName();
   		if (!type.equals("")) {
   		   serialNo++;
   		   srNo = String.valueOf(serialNo);
   		}

   		req = data.getRequirement();
   		des = data.getDesc();
   		grp = data.getGroupName();
   	}
	}
	//System.out.println(fld + "->" + srNo + "->" + type + "->" + req + "->" + des + "->" + grp);
	if (bAddFlag){
	   String[] row = 	{fld, srNo, type, req, des, grp};
	   /* The below if block is added by AM on 14 Oct 2008.
		 * To handle infinite loop if the des length is greater than 2500 characters and
		 * lines greater than 54
		 */
		if(des != null && des.length() > 2300 && des.length() < 2600){
		   String noOfLines[] = des.split("\n");   // find out number of line feed.
		   int rowsToBeAdded = 0;
		   String splitString=null;
		   for (String lines:noOfLines)
		   {
			   int rows = (int) Math.ceil(lines.length() /52);   // calculate no of line if the string length is greater than 52 characters
			   rowsToBeAdded += rows==0?1:rows;
			   splitString = lines;
			   if (rowsToBeAdded >= 48)
			   {
				   break;
			   }
			}
		   int val = des.lastIndexOf(splitString);
		   String str1 = des.substring(0,val);
		   String str2 = des.substring(val,des.length());
		   String[] row1 = 	{fld, srNo, type, req, str1, grp};
		   dataArr.add(row1);
		   String[] row2 = 	{"", "", "", "", str2, grp};
		   dataArr.add(row2);
	     }else
	       dataArr.add(row);
	}

}

public String shortenTypeName(String str){
	String retStr = str;
	int ptPos = str.lastIndexOf(".");
	if (ptPos != -1 && ptPos < (str.length()-1)) retStr = str.substring(ptPos+1);

	return retStr;
}


public void generatePDF(){

   java.util.Enumeration enmService = htService.keys();
   while (enmService.hasMoreElements()){
      serviceName = (String)enmService.nextElement();
      serviceVersion = "";
      java.util.Vector vTemp = (java.util.Vector)htService.get(serviceName);
      if (vTemp.size() == 5) {
         htOpIn = (Hashtable)vTemp.get(0);
         htOpOut = (Hashtable)vTemp.get(1);
         htValTypeIn = (Hashtable)vTemp.get(2);
         htValTypeOut = (Hashtable)vTemp.get(3);
         htOpDesc = (Hashtable)vTemp.get(4);
      }

      if (htOpDesc.containsKey("repVersion")) serviceVersion = (String)htOpDesc.get("repVersion");

      continuationRow = 0;
      //need to reintialize dataArr
      dataArr = new ArrayList();

   	java.util.Enumeration enmIn =  htOpIn.keys();
   	while (enmIn.hasMoreElements()) {
   		opName = (String)enmIn.nextElement();
   		 if (htOpDesc.containsKey(opName)){
   		 	 opDesc = (String)htOpDesc.get(opName);
   		 } else {
   		 	opDesc = opName;
   		 }
   		setFileName (outputDirectory + "/" + serviceName + "-" + opName + ".pdf");
         typesSeqHolder = new ArrayList();
   		dataSet = new DataHolder();
   		dataSet.setFieldName("+Input");
   		dataSet.setDataComplete(true);
   		FillDataArray(dataSet);
   		serialNo = 0;
   		Hashtable htInputParms = (Hashtable)htOpIn.get(opName);
   		java.util.Enumeration enmParmIn = htInputParms.keys();
   		while (enmParmIn.hasMoreElements()){
   			String keyName = (String)enmParmIn.nextElement();
   			//System.out.println("----keyName=" + keyName);
   			if (keyName.indexOf("|Primitive") == -1) {
   				dataSet = new DataHolder();
   				String[] typeInfo = (String[])htInputParms.get(keyName);
   				String tempTypeFull = typeInfo[0];
   				if (!typesSeqHolder.contains(tempTypeFull)) {
   				    typesSeqHolder.add(tempTypeFull);
   				} else {
   				    //System.out.println("opName=" + opName + " " + tempTypeFull + " already in typesSeqHolder array");
   				}
   				String typeName = shortenTypeName(typeInfo[0]);
   				dataSet.setFieldName(keyName);
   				String typeOccurs = typeInfo[1];
   				if (typeOccurs.equalsIgnoreCase("-1") || typeOccurs.equalsIgnoreCase("1") ||
   				    typeOccurs.equalsIgnoreCase("0") || typeOccurs.equals("")) {
   				    dataSet.setTypeXML("group occurs 1");
   				} else {
   				    //System.out.println("typeOccurs=["+ typeOccurs +"]");
   				    dataSet.setTypeXML("group occurs " + typeOccurs);
   				}
   				dataSet.setRequirement("O");
   				dataSet.setDesc(typeName);
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   			} else {
   				Hashtable htIn = (Hashtable)htInputParms.get(keyName);
   				if (!htIn.isEmpty()){
   					dataSet = new DataHolder();
   					if (htIn.get("name")!= null) {
   						String obj = (String)htIn.get("name");
   						dataSet.setFieldName((String)obj);
   						//dbj 10/21/2005
   						/*
   						if (htIn.get("documentation")!= null) {
   							String obj1 = (String)htIn.get("documentation");
   							dataSet.setDesc(obj1);
   						}
   						*/
   						if (htIn.get("properties")!= null) {
   							HashMap hm = (HashMap)htIn.get("properties");
   							processHashMapContents(hm);
   							if (dataSet.getDataComplete()) FillDataArray(dataSet);
   						}
   					}
   				}
   			}
   		}


   		//now get valTypes for input
   		if (htValTypeIn.containsKey(opName)) {
   			Hashtable htValTypes = (Hashtable)htValTypeIn.get(opName);
  				for (int i = 0; i < typesSeqHolder.size(); i++){
               String keyValType = (String)typesSeqHolder.get(i);

   				dataSet = new DataHolder();
   				dataSet.setFieldName("+valType");
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   				dataSet = new DataHolder();
   				//dbj 10/25/2005
   				//dataSet.setFieldName(keyValType);
   				dataSet.setFieldName(shortenTypeName(keyValType));
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   				serialNo = 0;
   				ArrayList alValType = (ArrayList)htValTypes.get(keyValType);
   				if (alValType != null && !alValType.isEmpty()) {
   				   //System.out.println("alValType.size()=" + alValType.size());
   					for (int j = 0; j < alValType.size(); j++){
   						Hashtable htTemp = (Hashtable)alValType.get(j);
   						processHashValType(htTemp);
   					}				//end -for
   				}			//end-if
  				}     //end-for
  			}        //end-if


   		/*
   		//now get valTypes for input
   		if (htValTypeIn.containsKey(opName)) {
   			Hashtable htValTypes = (Hashtable)htValTypeIn.get(opName);
   			java.util.Enumeration enmValTypes = htValTypes.keys();
   			while (enmValTypes.hasMoreElements()){
   				String keyValType = (String)enmValTypes.nextElement();
   				System.out.println("----keyValTypeIn=" + keyValType);
   				dataSet = new DataHolder();
   				dataSet.setFieldName("+valType");
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   				dataSet = new DataHolder();
   				//dbj 10/25/2005
   				//dataSet.setFieldName(keyValType);
   				dataSet.setFieldName(shortenTypeName(keyValType));
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);
   				serialNo = 0;
   				ArrayList alValType = (ArrayList)htValTypes.get(keyValType);
   				if (alValType != null && !alValType.isEmpty()) {
   				   System.out.println("alValType.size()=" + alValType.size());
   					for (int i = 0; i < alValType.size(); i++){
   						Hashtable htTemp = (Hashtable)alValType.get(i);
   						processHashValType(htTemp);
   					}

   				}
   			}
   		}
         */

         typesSeqHolder = new ArrayList();
   		dataSet = new DataHolder();
   		dataSet.setFieldName("+Output");
   		dataSet.setDataComplete(true);
   		FillDataArray(dataSet);
   		serialNo = 0;
   		Hashtable htOutputParms = (Hashtable)htOpOut.get(opName);
   		java.util.Enumeration enmParmOut = htOutputParms.keys();
   		while (enmParmOut.hasMoreElements()){
   			String keyName = (String)enmParmOut.nextElement();
   			if (keyName.indexOf("|Primitive") == -1) {
   				dataSet = new DataHolder();
   				String[] typeInfo = (String[])htOutputParms.get(keyName);

   				String tempTypeFull = typeInfo[0];
   				if (!typesSeqHolder.contains(tempTypeFull)) {
   				    typesSeqHolder.add(tempTypeFull);
   				} else {
                   //System.out.println("opName=" + opName + " " + tempTypeFull + " already in typesSeqHolder array");
   				}

   				String typeName = shortenTypeName(typeInfo[0]);

   				dataSet.setFieldName(keyName);
   				String typeOccurs = typeInfo[1];
   				if (typeOccurs.equalsIgnoreCase("-1") || typeOccurs.equalsIgnoreCase("1") ||
   				    typeOccurs.equalsIgnoreCase("0") || typeOccurs.equals("")) {
   				    dataSet.setTypeXML("group occurs 1");
   				} else {
   				   //System.out.println("typeOccurs=["+ typeOccurs +"]");
   				    dataSet.setTypeXML("group occurs " + typeOccurs);
   				}
   				dataSet.setDesc(typeName);
   				dataSet.setRequirement("O");
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   			} else {
   				Hashtable htOut = (Hashtable)htOutputParms.get(keyName);
   				if (!htOut.isEmpty()){
   					dataSet = new DataHolder();
   					if (htOut.get("name")!= null) {
   						String obj = (String)htOut.get("name");
   						dataSet.setFieldName((String)obj);
   						//dbj 10/21/2005
   						/*
   						if (htOut.get("documentation")!= null) {
   							String obj1 = (String)htOut.get("documentation");
   							dataSet.setDesc(obj1);
   						}
   						*/
   						if (htOut.get("properties")!= null) {
   							HashMap hm = (HashMap)htOut.get("properties");
   							processHashMapContents(hm);
   							if (dataSet.getDataComplete()) FillDataArray(dataSet);
   						}
   					}
   				}
   			}
   		}

   		if (htValTypeOut.containsKey(opName)) {
   			Hashtable htValTypes = (Hashtable)htValTypeOut.get(opName);

  				for (int i = 0; i < typesSeqHolder.size(); i++){
               String keyValType = (String)typesSeqHolder.get(i);
               dataSet = new DataHolder();
   				dataSet.setFieldName("+valType");
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   				dataSet = new DataHolder();

   				dataSet.setFieldName(shortenTypeName(keyValType));
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   				serialNo = 0;
   				ArrayList alValType = (ArrayList)htValTypes.get(keyValType);
   				if (alValType != null && !alValType.isEmpty()) {
   					for (int j = 0; j < alValType.size(); j++){
   						Hashtable htTemp = (Hashtable)alValType.get(j);
   						processHashValType(htTemp);
   					}	//end for

   				}	   //end-if
   			}			//end-for
   		}        //end-if



   		/*
   		//now get valTypes for input
   		if (htValTypeOut.containsKey(opName)) {
   			Hashtable htValTypes = (Hashtable)htValTypeOut.get(opName);
   			java.util.Enumeration enmValTypes = htValTypes.keys();
   			while (enmValTypes.hasMoreElements()){
   				String keyValType = (String)enmValTypes.nextElement();
   				dataSet.setFieldName("+valType");
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);

   				dataSet = new DataHolder();
   				//dbj 10/25/2005
   				//dataSet.setFieldName(keyValType);
   				dataSet.setFieldName(shortenTypeName(keyValType));
   				dataSet.setDataComplete(true);
   				FillDataArray(dataSet);
   				serialNo = 0;
   				ArrayList alValType = (ArrayList)htValTypes.get(keyValType);
   				if (alValType != null && !alValType.isEmpty()) {
   					for (int i = 0; i < alValType.size(); i++){
   						Hashtable htTemp = (Hashtable)alValType.get(i);
   						processHashValType(htTemp);
   					}

   				}
   			}
   		}
   		*/


   		dataObj = dataArr.toArray();
   		try {
   			internal_run();
   		} catch (Exception e) {
   			e.printStackTrace();
   			//System.out.println(e.getMessage());
   		}
   		pageNumber = 1;
   		bPgBreakAdded = false;

   	}

    }	 //end of service enumeration

}

private void processHashValType(Hashtable httemp){
	if (httemp.containsKey("type")) {
		dataSet = new DataHolder();
	  	String typeNameStr = (String)httemp.get("type");
	  	//dataSet.setFieldName(typeNameStr);
	  	dataSet.setFieldName((String)httemp.get("name"));
	  	//dbj 10/25/2005
	  	//dataSet.setDesc(typeNameStr)
	  	if (!typesSeqHolder.contains(typeNameStr)) {
	  	   typesSeqHolder.add(typeNameStr);
	  	} else {
	  	   //System.out.println("opName=" + opName + " " + typeNameStr + " already in typesSeqHolder array");
	  	}
	  	dataSet.setDesc(shortenTypeName(typeNameStr));
	  	if (httemp.containsKey("properties")){
	  		HashMap hm = (HashMap)httemp.get("properties");
	  		if (hm.containsKey("maxOccurs")){
	  			//String typeOccurs = (String)hm.get("maxOccurs");
	  			String typeOccurs = (Integer.parseInt(hm.get("maxOccurs")+""))+"";
				if (typeOccurs.equalsIgnoreCase("-1") || typeOccurs.equalsIgnoreCase("1") ||
				    typeOccurs.equalsIgnoreCase("0") || typeOccurs.equals("")) {
				    dataSet.setTypeXML("group occurs 1");
				} else {
				    //System.out.println("typeOccurs=["+ typeOccurs +"]");
				    dataSet.setTypeXML("group occurs " + typeOccurs);
				}

	  		}
	  	//if no properties then set 'group occurs'
	  	} else {
	  		dataSet.setTypeXML("group occurs 1");
	  	}
	  	dataSet.setRequirement("O");
		dataSet.setDataComplete(true);
		FillDataArray(dataSet);
	} else {
		dataSet = new DataHolder();
		//if (httemp.get("name")!= null) {
		if (httemp.containsKey("name")){
			String obj = (String)httemp.get("name");
			dataSet.setFieldName((String)obj);
		}
		//dbj 10/21/2005
		/*
		if (httemp.containsKey("documentation")) {
			String obj = (String)httemp.get("documentation");
			dataSet.setDesc((String)obj);
		}
		*/
		//if (httemp.get("properties")!= null) {
		if (httemp.containsKey("properties")) {
			HashMap hm = (HashMap)httemp.get("properties");
			processHashMapContents(hm);
			if (dataSet.getDataComplete()) FillDataArray(dataSet);
		} else {
			dataSet.setDataComplete(true);
			FillDataArray(dataSet);
		}

	}
}

/*
private void processHashContents(Hashtable httemp){

	//create new dataSet object
	dataSet = new DataHolder();

	//String curGroupName = "";

	//first check for typeName
	//if it is there process it and take it out
	if (httemp.containsKey("typeName")) {
	  	String typeNameStr = (String)httemp.get("typeName");
	  	currentGroup = typeNameStr;
		dataSet.setFieldName(typeNameStr);
		dataSet.setTypeXML("group occurs");
		dataSet.setRequirement("O");
		dataSet.setDataComplete(true);
		FillDataArray(dataSet);
		httemp.remove("typeName");
		dataSet = new DataHolder();
	}

	java.util.Enumeration enmOut =  httemp.keys();
        while (enmOut.hasMoreElements()) {
		String key1 = (String)enmOut.nextElement();
		Object obj = httemp.get(key1);

		if (obj.getClass().getName().equalsIgnoreCase("java.util.ArrayList")) {
			java.util.ArrayList al = (ArrayList)httemp.get(key1);
			if (al != null && !al.isEmpty()){
				for (int i = 0; i < al.size(); i++){
					Object obj1 = al.get(i);
					//System.out.println("object type=" + obj1.getClass().getName());
					if (obj1.getClass().getName().equalsIgnoreCase("java.util.Hashtable")) {
						//System.out.println("Calling displayHashContents....");
						processHashContents((Hashtable)obj1);
					} else {
					  System.out.println("processHashContents: data type not hashtable");
					}
				}
			} else System.out.println("Arraylist (al) is empty....");
//		} else if (obj.getClass().getName().equalsIgnoreCase("java.util.Hashtable")) {
			//System.out.println(key1 + "===>java.util.Hashtable");
			//System.out.println("---------------------------------------");
//			processHashContents((Hashtable)obj);
		} else if (obj.getClass().getName().equalsIgnoreCase("java.util.HashMap")) {
			processHashMapContents((HashMap)obj);
			if (dataSet.getDataComplete()) FillDataArray(dataSet);
		} else if (obj.getClass().getName().equalsIgnoreCase("java.lang.String")) {

			if (key1.equalsIgnoreCase("name")) {
				if (obj != null) {
					dataSet.setFieldName((String)obj);
					dataSet.setGroupName(currentGroup);
				} else {
					dataSet.setFieldName("NULL");
				}
//			} else if (key1.equalsIgnoreCase("typeName")) {
//				if (obj != null) {
//					dataSet.setFieldName((String)obj);
//					dataSet.setTypeXML("group occurs");
//					dataSet.setRequirement("O");
//					dataSet.setDataComplete(true);
//					FillDataArray(dataSet);
//				}
			} else if (key1.equalsIgnoreCase("documentation")) {
				if (obj != null) {
					dataSet.setDesc((String)obj);
				}
			}

		}



	}

}

*/
private void processHashMapContents(HashMap hmap) {
	String tempType = "";
	String len = "";
	String precision = "";
	String typeStr = "xsd:";
	String desc = "";

	if (hmap.get("mqreserved")!= null) {
		Boolean resB = (java.lang.Boolean)hmap.get("mqreserved");
		if (resB == Boolean.TRUE) {
			dataSet.setDataComplete(false);
			return;
		}
	}

	//dbj 10/21/2005
	if (hmap.get("description") != null) {
		desc = (String) hmap.get("description");
	}
	dataSet.setDesc(desc);


	if (hmap.get("length") != null) {
		System.out.println(hmap.get("length"));
		len=Integer.parseInt(hmap.get("length").toString())+"";
		//len = ((java.lang.Integer)hmap.get("length")).toString();
	}

	if (hmap.get("precision")!= null) {
		
		precision = Integer.parseInt(hmap.get("precision").toString())+"";
	}
	if (hmap.get("mqtype")!= null) {
		tempType = (String)hmap.get("mqtype");
		tempType = tempType.toLowerCase();
		typeStr += tempType;
		if (tempType.equals("decimal")) {
			typeStr +=  "[" + len + "." + precision + "]";
		}
		//Added by Anitha on 19th Aug '09 to supress the date length in doc.
		else if(tempType.equals("date")){
			typeStr = typeStr ;
		}else {
			if (!len.equalsIgnoreCase("0")) {
				typeStr +=  "[" + len +  "]";
			} else {
				typeStr +=  "[]";
			}
		}
		dataSet.setTypeXML(typeStr);
	}
	if (hmap.get("required")!= null) {
		System.out.println();
		
		Boolean reqB =Boolean.parseBoolean(hmap.get("required").toString()); 
		if (reqB.equals(Boolean.TRUE)) {
			dataSet.setRequirement("R");
		} else {
			dataSet.setRequirement("O");
		}
	} else dataSet.setRequirement("O");

	dataSet.setDataComplete(true);


}



 }