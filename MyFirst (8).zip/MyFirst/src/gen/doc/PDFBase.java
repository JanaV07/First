package gen.doc;

import arch.gx.*;

public abstract class PDFBase {

  /**
   * flag controlling whether the generated document has debugging 
   * information.
   */
  private boolean debug = false;

  /**
   * flag controlling whether the generated document should be compressed
   */
  private boolean compress = false;

  /**
   * String which controls which document format is to be 
   * generated, default is "pdf", can be "pdf" or "ps", for
   * PDF or Postscript output resepectively.
   */
  private String documentClassKey = "pdf";

  /**
   * The file name use to create the document
   */
  private String fileName = null;

  /**
   * Keeps track of the number of pages generated, used for
   * statistics.
   */
  private int numberOfPages;
  
  protected final void endPage (Document document){
      document.endPage ();
      numberOfPages++;
  }
  
 /**
  * This is the method you should override, return zero if your
  * processing is ok, non-zero otherwise. This is declared as
  * throwing Exception to make it easier to write examples.
  */
  protected abstract int run (Document context) throws Exception;
  
  protected Margins getDefaultPageMargins (){
      return null;		// use the default (no margins)
  }
  
  protected Size getDefaultPageSize (){
      return null;		// use the default (8.5 x 11)
  }

  protected Page.Orientation getDefaultPageOrientation () {
      return null;		// use the default (no portrait)
  }
  
  protected void setFileName(String temp) {
	  fileName = temp;
  }
  
  protected int internal_run ()
    throws Exception
    {
      Document doc;
      numberOfPages = 0;
      // first, create a document factory which can be used to create documents
      DocumentFactory fact = new DocumentFactory ();

      // In order to actually create the document, 
      // one must first create a parameter map, specifying different
      // options (e.g., filename, title, etc...) -- see the Java-Docs for
      // arch.gx.Document for the keys (DEBUG, TITLE, DOCUMENT_PATH,
      // etc...)
      java.util.Map map = new java.util.HashMap ();

      map.put (Document.DEBUG, debug ? Boolean.TRUE : Boolean.FALSE);
      map.put (Document.TITLE, "A Test Document");
      map.put (Document.SUBJECT, "Some Subject");
      map.put (Document.AUTHOR, System.getProperty ("user.name"));
      map.put (Document.KEYWORDS, "Tests,Visual");
      map.put (Document.CREATOR, getClass ().getName ());
      map.put (Document.DOCUMENT_PATH, fileName);
      map.put (Document.COMPRESS_CONTENT,Boolean.FALSE);


      // keep track of when we started processing
      long startTime = System.currentTimeMillis ();

      // now create a new document, we pass a string denoting the type of
      // document to create (eg., pdf, ps) and use the page size,
      // margins and orientation specified by either us or our subclass
      // (by overriding getDefaultPageSize, getDefaultPageMargins,
      // getDefaultPageOrientation).
      doc = fact.createDocument (documentClassKey,
				 getDefaultPageSize (),
				 getDefaultPageMargins (),
				 getDefaultPageOrientation (),
				 map);

      // now call our subclass's run method with the document context
      int status = run (doc);

      // close the document, depending on the type of document generated,
      // the file not be written out (or any output generated until this
      // is called).
      doc.close ();
      if (status == 0)
	{
	  // print some statistics to see how we did
	  double elapsed = (System.currentTimeMillis () - startTime) / 1000.0;
	  //System.err.println ("total elapsed time: " + elapsed);
	  if (numberOfPages != 0)
	    {
	      if (elapsed == 0)
		elapsed = 0.00000001;
	      double pagesPerSecond = numberOfPages / elapsed;
	      //System.err.println ("  ~" + pagesPerSecond + " pages per second (or "
			//	  + (elapsed / numberOfPages)  + " seconds per page)");
	    }
	}
      else
	{
	  // print a message if something went wrong
	  System.err.println ("non-zero status generating document: "
			      + fileName
			      + ": "
			      + status);
	}
      return status;
    }  
  




}