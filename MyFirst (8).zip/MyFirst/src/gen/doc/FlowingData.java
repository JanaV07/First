package gen.doc;

import arch.gx.*;
import arch.gx.layout.Flowable;
import arch.gx.layout.Flowables;
  
  public class FlowingData
  {
    //private final Rect contentRect;
    //private final Rect flowingRect;
    //private final java.util.List newMarks;
    //private final java.util.List newFlowables;
    private  Rect contentRect;
    private  Rect flowingRect;
    private  java.util.List newMarks;
    private  java.util.List newFlowables;
    private double heightSoFar = 0.0;
    private double curFlowableHt = 0.0;

    public FlowingData (Rect contentRect)
      {
	this.contentRect = contentRect;
	flowingRect = contentRect.copy ();
	newMarks = new java.util.ArrayList ();
	newFlowables = new java.util.ArrayList ();
	heightSoFar = 0.0;
	flush ();
      }

    public void flush ()
      {
	flowingRect.setSize (contentRect.getSize ());
	flowingRect.setOrigin (contentRect.getX (),
			       contentRect.getMaxY ());
	newMarks.clear ();
      }

    public boolean getInProgress ()
      {
	return flowingRect.getSize ().equals (contentRect.getSize ()) == false;
      }
      
     public double getHeightSoFar(){
     	return heightSoFar;	
     }
     
     public double getHeightOfCurrentFlowable(){
     	return curFlowableHt;	
     }
     
     private void setHeightOfCurrentFlowable(double dHt){
     	curFlowableHt = dHt;
     }

   public boolean tryFit (java.util.List flowables)
         {
   	Flowable together = Flowables.keepTogether (flowables);
   	java.util.List fakeNewMarks = new java.util.ArrayList ();
   	java.util.List fakeNewFlowables = new java.util.ArrayList ();
   	Size sz = flowingRect.getSize ().copy ();
   
   	if (together.getSize (getInProgress (), sz) == false)
   	  return false;
   
   	together.flow (getInProgress (),
   		       flowingRect.getOrigin ().copy (),
   		       sz,
   		       fakeNewMarks,
   		       fakeNewFlowables);
   
   	
   	setHeightOfCurrentFlowable(sz.getHeight());
   //	System.out.println("sz-height before=" + sz.getHeight());
   
   	if (fakeNewFlowables.isEmpty () == false)
   	  return false;
   	newMarks.addAll (fakeNewMarks);
   	heightSoFar += sz.getHeight();
   	//System.out.println("sz-height=" + sz.getHeight());
   	//System.out.println("sz-width=" + sz.getWidth());
   	flowingRect.moveBy (0, - sz.getHeight ());
   	flowingRect.sizeBy (0, - sz.getHeight ());
   	return true;
    }
  }