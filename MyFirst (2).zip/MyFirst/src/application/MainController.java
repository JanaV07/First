package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class MainController implements Initializable {
	@FXML
	TreeView<String> treeview;
	 @FXML
	    private AnchorPane dataPane;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		TreeItem<String> root =new TreeItem<>("ROOT");
		TreeItem<String> nod1 =new TreeItem<>("nod1");
		TreeItem<String> nod2 =new TreeItem<>("type");
		TreeItem<String> nod3 =new TreeItem<>("fun");
		TreeItem<String> nod4 =new TreeItem<>("service");
		TreeItem<String> nod5 =new TreeItem<>("5");
		TreeItem<String> nod6 =new TreeItem<>("6");
		TreeItem<String> nod7 =new TreeItem<>("7");
		TreeItem<String> nod8 =new TreeItem<>("8");
		TreeItem<String> nod9 =new TreeItem<>("9");
		TreeItem<String> nod0 =new TreeItem<>("ROOT");
		TreeItem<String> nod11 =new TreeItem<>("ROOT");
		TreeItem<String> nod12 =new TreeItem<>("ROOT");
		
		
		root.getChildren().addAll(nod1,nod6,nod7,nod8,nod9,nod0,nod11,nod12);
		
		nod1.getChildren().addAll(nod2,nod3,nod4);	
		
		
		treeview.setRoot(root);
	}

	 public VBox fadeAnimate(String url) throws IOException {
	    	
	        VBox v = (VBox) FXMLLoader.load(getClass().getResource(url));
	        FadeTransition ft = new FadeTransition(Duration.millis(1500));
	        ft.setNode(v);
	        ft.setFromValue(0.1);
	        ft.setToValue(1);
	        ft.setCycleCount(1);
	        ft.setAutoReverse(false);
	        ft.play();
	        return v;
	    }
	 	
	 public void setDataPane(Node node) {
	        // update VBox with new form(FXML) depends on which button is clicked
	        dataPane.getChildren().setAll(node);
	    }
	    public void loadPane() throws IOException {
	        setDataPane(fadeAnimate("FXML1.fxml"));
	    }

	    public void loadPane2() throws IOException {
	        setDataPane(fadeAnimate("FXML2.fxml"));
	    }

	    public void loadPane3() throws IOException {
	        setDataPane(fadeAnimate("FXML3.fxml"));
	    }
	
	public void mouseClick(MouseEvent evnt){
		TreeItem<String> sel=treeview.getSelectionModel().getSelectedItem();
		System.out.println(sel.getValue());
		if(sel.getValue().equals("fun")){
			try {
				loadPane();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(sel.getValue().equals("type")){
			try {
				loadPane3();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(sel.getValue().equals("service")){
			try {
				loadPane2();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
