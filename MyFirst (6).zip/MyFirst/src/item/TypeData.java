package item;

import java.util.HashMap;
import java.util.List;

/**
 *
 * 
 * @author VJanarthanan
 */
public class TypeData {
	public Header header;
	public List<ItemBase> itemList;
	public int size;
	public HashMap<String, String> headerMap;
	public String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public HashMap<String, String> getHeaderMap() {
		return headerMap;
	}

	public void setHeaderMap(HashMap<String, String> headerMap) {
		this.headerMap = headerMap;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public List<ItemBase> getItemList() {
		return itemList;
	}

	public void setItemList(List<ItemBase> itemList) {
		this.itemList = itemList;
	}

}
