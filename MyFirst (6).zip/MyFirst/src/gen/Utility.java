package gen;

public class Utility {
	public static String makeFirstLetterCapital(String input) {
		return input.substring(0, 1).toUpperCase() + input.substring(1);
	}
public static String makeOnlyFirstLetterCapital(String input) {
		input = input.toLowerCase();
		if (!input.contains("|"))
			return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
		else {
			String str = "";
			String[] in = input.split("\\|");
			for (int i = 0; i < in.length; i++) {
				System.out.println(in[i]);
				str = str + makeOnlyFirstLetterCapital(in[i]);
			}
			return str;

		}
	}
}
