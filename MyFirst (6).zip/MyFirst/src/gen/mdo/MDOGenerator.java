package gen.mdo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

import gen.Utility;
import item.FunctionData;
import item.Header;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;
import javafx.collections.ObservableList;

public class MDOGenerator {
	public static String packageName;
	public String serviceName;
	public String functionName;
	public String type;
	public String alternateNameofService;
	public ServiceData serviceData;
	public int length;
	public List<HashMap<String, ServiceData>> serviceMapList;
	public List<HashMap<String, FunctionData>> functionMapList;
	public ObservableList<String> functionList;
	public Header header;
	public HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap = new HashMap<String, List<HashMap<String, FunctionData>>>();
	public HashMap<String, List<HashMap<String, TypeData>>> bulkTypeMap = new HashMap<String, List<HashMap<String, TypeData>>>();
	public static  LinkedHashMap<String, ItemBase> completeItems = new LinkedHashMap<String, ItemBase>();
	public  List<HashMap<String, TypeData>> fieldTypeMapList = null; // contains the types inside package
	public  List<String> fieldTypeList = new ArrayList<String>(); // contains the types inside package
	
	public List<String >inValueList =new ArrayList<String>();
	public List<String> outValueList=new ArrayList<String>();
	
	public List<String> defaultValueMap=new ArrayList<String>();
	
	public MDOGenerator(String type, String packageName, String serviceName,
	List<HashMap<String, ServiceData>> serviceMapList, List<HashMap<String, FunctionData>> functionMapList,
	ObservableList<String> functionList, HashMap<String, List<HashMap<String, FunctionData>>> bulkFunctionMap, HashMap<String, List<HashMap<String, TypeData>>> bulkTypeMap) {
		this.type = type;
		this.packageName = packageName;
		this.serviceName = serviceName;
		this.serviceMapList = serviceMapList;
		this.functionMapList = functionMapList;
		this.functionList = functionList;
		this.serviceData = retrieveServiceData(serviceMapList);
		this.bulkFunctionMap=bulkFunctionMap;
		this.bulkTypeMap=bulkTypeMap;
		this.header = serviceData.getHeader();
		this.alternateNameofService=serviceData.header.getAllElements().get("alternate");
		//////System.out.println("Service Name : :: " + serviceName);
		//////System.out.println("Package Name : : ::" + packageName);
		//////System.out.println("SErvice MAp  : :" + serviceMapList);
		//////System.out.println("Function Map : :" + functionMapList);
		//////System.out.println("Function List:::" + functionList);
		//////System.out.println("Service Data ifleNAe: : :" + serviceData.getFileName());
		//////System.out.println("Service Data :::" + serviceData.header.getAllElements());
		
		//////System.out.println("Service Data :IP LIST: " + serviceData.inputItemList);

	}

	private ServiceData retrieveServiceData(List<HashMap<String, ServiceData>> serviceMapList2) {
		if (serviceMapList != null) {
			for (HashMap<String, ServiceData> serviceMap : serviceMapList) {
				Iterator i = null;
				if (serviceMap != null) {
					i = serviceMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry != null)
							if (entry.getKey().toString().equals(serviceName)) {
								return (ServiceData) entry.getValue();
							}
					}
				}
			}
		}
		return null;
	}

	public ServiceData getServiceData() {
		return serviceData;
	}

	public void setServiceData(ServiceData serviceData) {
		this.serviceData = serviceData;
	}

	public List<HashMap<String, FunctionData>> getFunctionMapList() {
		return functionMapList;
	}

	public void setFunctionMapList(List<HashMap<String, FunctionData>> functionMapList) {
		this.functionMapList = functionMapList;
	}

	public ObservableList<String> getFunctionList() {
		return functionList;
	}

	public void setFunctionList(ObservableList<String> functionList) {
		this.functionList = functionList;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getAlternateNameofService() {
		return alternateNameofService;
	}

	public void setAlternateNameofService(String alternateNameofService) {
		this.alternateNameofService = alternateNameofService;
	}

	public void generateOP() {
		VelocityContext context = new VelocityContext();
		String package1="arch." + packageName ;
		context.put("package", package1+ ".service.mdo");
		String srName = Utility.makeFirstLetterCapital(serviceName);
		String className="OP"+Utility.makeFirstLetterCapital(header.getAllElements().get("alternate"));
		context.put("operController",className);
		String operProperties = "";
		//////System.out.println(header.getAllElements());
		/*
		 * context.setProperty("serviceName", "CHECKAPPROVALSERVICE");
		 * context.setProperty("systemId", "AMPS"); context.setProperty("requestType",
		 * "X9"); context.setProperty("sourceOfInput", "PXML");
		 */

		String serviceName = header.getAllElements().get("serviceName");
		String systemId = header.getAllElements().get("systemId");
		String requestType = header.getAllElements().get("requestType");
		String sourceOfInput = header.getAllElements().get("sourceOfInput");
		if(serviceName== null)
		{
			serviceName="";
		}
		if(systemId==null)
		{
			systemId="";
		}
		if(requestType==null)
		{
			requestType="";
		}
		if (sourceOfInput == null) {
			sourceOfInput = "PXML";
		}
		operProperties = operProperties + "context.setProperty(\"serviceName\",\"" + serviceName + "\");\n";
		operProperties = operProperties + "context.setProperty(\"systemId\",\"" + systemId + "\");\n";
		operProperties = operProperties + "context.setProperty(\"requestType\",\"" + requestType + "\");\n";
		operProperties = operProperties + "context.setProperty(\"sourceOfInput\",\"" + sourceOfInput + "\");\n";
		operProperties = operProperties + "context.setProperty(\"dataHeader\", new Boolean (false));";
		////////System.out.println("operProperties : : : : "+operProperties);
		context.put("operProperties", operProperties);
		
		// MDOCreatePIInValueProcess - inProcessor
		
			context.put("inProcessor", "MDO" + srName + "InValueProcess");
		
			context.put("outProcessor", "MDO" + srName + "OutValueProcess");
		try {
			generateFromTemplate("./src/gen/mdo/template/MPOperationController.vm",package1,className,context,serviceName,".java");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		generateFunctionMDO(serviceData.getInputItemList(),"input");
		generateFunctionMDO(serviceData.getOutputItemList(),"ouptut");
		generateInTypeMDO(inValueList,"input");
		generateInTypeMDO(outValueList,"output");
	}
	
	private void generateInTypeMDO(List<String> valueList, String type) {
		System.out.println(valueList);
		for(String value: valueList) {
			completeItems.clear();
			defaultValueMap.clear();
			//System.out.println("value : : : :"+value);
			TypeData typeData=getTypeData(fieldTypeMapList, value);
			//System.out.println(typeData.fileName);
			if(typeData!=null) {
				VelocityContext context = new VelocityContext();
				String package1="arch." + packageName ;
				context.put("package", package1+ ".service.mdo");
				context.put("ServiceValuePackage",package1);
				context.put("INPUTMDOTYPE","MDO.TYPE");
				String className="";
				String typeName=typeData.header.getAllElements().get("name");
				context.put("INPUTFUNCTIONNAME", "");
				context.put("OUTPUTFUNCTIONNAME", "");
				if(type.equals("input"))
					{
					className="MDO"+Utility.makeFirstLetterCapital(value)+"InValueProcess";
					context.put("MMFInputString", constructMMFInputString(typeData.itemList,"input"));
					context.put("inValueType", Utility.makeFirstLetterCapital(typeName));
					context.put("inConstants", constructInConstants());
					context.put("inMappingData",constructInMappingData());
					}
					else
					{
					className="MDO"+Utility.makeFirstLetterCapital(value)+"OutValueProcess";
					context.put("outProcessor",className);
					context.put("MMFOutputString", constructMMFInputString(typeData.itemList,"output"));
					context.put("outValueType",Utility.makeFirstLetterCapital(typeName));
					context.put("outConstants", constructInConstants());
					context.put("outMappingData", constructOutMappingData());
					}
				if(defaultValueMap.size()>0) {
					System.out.println("Inside Func call");
					context.put("initialization", constructInitialization());
				}
				try {
					if(type.equals("input"))
					generateFromTemplate("./src/gen/mdo/template/MDOOperationRequestProcess.vm",package1,className,context,serviceName,".java");
					else
						generateFromTemplate("./src/gen/mdo/template/MDOOperationResponseProcess.vm",package1,className,context,serviceName,".java");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}

	public void generateFunctionMDO(List<ItemBase> functionList,String type) {
		for(ItemBase function: functionList) {
			//////System.out.println("function : :: "+function.getName());
			//////System.out.println("function type : : "+function.getType());
			completeItems.clear();
			defaultValueMap.clear();
			List<HashMap<String, FunctionData>> functionListOfPackage=bulkFunctionMap.get(packageName);
			this.fieldTypeMapList=bulkTypeMap.get(packageName);
			contstructFieldTypeList(fieldTypeMapList);
			FunctionData functionData=getFunctionData(functionListOfPackage,function.getName());
			if(functionData!=null) {
				//////System.out.println("function Data filename: : :"+functionData.getFileName());
				//////System.out.println("function DAta headerMap: : : :"+functionData.getHeaderMap());
				
				VelocityContext context = new VelocityContext();
				String package1="arch." + packageName ;
				context.put("package", package1+ ".service.mdo");
				context.put("ServiceValuePackage",package1);
				String className="";
				if(type.equals("input"))
				className="MDO"+Utility.makeFirstLetterCapital(alternateNameofService)+"InValueProcess";
				else
					className="MDO"+Utility.makeFirstLetterCapital(alternateNameofService)+"OutValueProcess";
				//MDOCreatePIInValueProcess
				
				
				context.put("INPUTMDOTYPE","MDO.FUNCTION");
				String functionName=functionData.header.getAllElements().get("functionKey");
				//////System.out.println("function NAme : : :"+functionName);
				//////System.out.println(functionData.header.getAllElements());
				
					context.put("INPUTFUNCTIONNAME", "super.setName(\""+functionName+"\");");
				
				String valueObject=functionData.header.getAllElements().get("name");
				if(type.equals("input"))
					{
					context.put("inProcessor",className);
					context.put("MMFInputString", constructMMFInputString(functionData.inputItemList,"input"));
					context.put("inValueType", package1+".value."+Utility.makeFirstLetterCapital(valueObject)+"Input");
					//context.put("inConstants", constructInConstants());
					String occurs=functionData.inputOccurs;
					String min = occurs.charAt(0) + "";
					String max = occurs.charAt((occurs.length() - 1)) + "";
					if (max.equals("N"))
						max = "*";
					String inConstants=constructInConstants();
					inConstants=inConstants+"private static final String \r\n" + 
							"	 SystemId=\""+functionData.header.getAllElements().get("systemid")+"\", \r\n" + 
							"	 ResType=\""+functionData.header.getAllElements().get("requesttype")+"\"; \r\n" + 
							"private static final char \r\n" + 
							"	 MinOccurs='"+min+"', \r\n" + 
							"	 MaxOccurs='"+max+"'; ";
					context.put("inConstants", inConstants);
					context.put("inMappingData",constructInMappingData());				
					}
				else
					{
					context.put("outProcessor",className);
					context.put("OUTPUTFUNCTIONNAME", "super.setName(\""+functionName+"\");");
					context.put("MMFOutputString", constructMMFInputString(functionData.outputItemList,"output"));
					context.put("outValueType", package1+".value."+Utility.makeFirstLetterCapital(valueObject)+"Output");
					
					String occurs=functionData.inputOccurs;
					String min = occurs.charAt(0) + "";
					String max = occurs.charAt((occurs.length() - 1)) + "";
					if (max.equals("N"))
						max = "*";
					String inConstants=constructInConstants();
					inConstants=inConstants+"private static final String \r\n" + 
							"	 SystemId=\""+functionData.header.getAllElements().get("systemid")+"\", \r\n" + 
							"	 ResType=\""+functionData.header.getAllElements().get("requesttype")+"\"; \r\n" + 
							"private static final char \r\n" + 
							"	 MinOccurs='"+min+"', \r\n" + 
							"	 MaxOccurs='"+max+"'; ";
					context.put("outConstants", inConstants);
					context.put("outMappingData", constructOutMappingData());
					}
				System.out.println("size : :"+defaultValueMap.size());
				if(defaultValueMap.size()>0) {
					System.out.println("Inside Func call");
					context.put("initialization", constructInitialization());
				}
				try {
					if(type.equals("input"))
					generateFromTemplate("./src/gen/mdo/template/MDOOperationRequestProcess.vm",package1,className,context,serviceName,".java");
					else
						generateFromTemplate("./src/gen/mdo/template/MDOOperationResponseProcess.vm",package1,className,context,serviceName,".java");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}

private String constructInitialization() {
	System.out.println("Inside Func");
	StringBuffer buf = new StringBuffer();
	Iterator i;
	if (defaultValueMap != null) {
	for(String def:defaultValueMap) {
		System.out.println(" DEfault ::"+def);
		buf.append(def);
		}
		}
		return buf.toString();
	}

private String constructOutMappingData() {
	StringBuffer buf = new StringBuffer();
	Iterator i;
	if (completeItems != null) {
		i = completeItems.entrySet().iterator();
		for (int k = 0; i.hasNext() && i != null; k++) {
			Entry entry = (Entry) i.next();
			String key = (String) entry.getKey();
			ItemBase item=(ItemBase)entry.getValue();
			// value.setSystemError((String)header.getError_Text());
			String type=retrieveType(item);
			if(type.equals("header"))
				buf.append("value.set"+Utility.makeFirstLetterCapital(key)+"((String)header.getError_Text()); \n");
			else if(type.equals("x")) {
				if(item.getMaxOccurs()!=null && item.getMaxOccurs().length()>0 && Integer.parseInt(item.getMaxOccurs())>1) {
					//value.setRuleEngineErrors((java.util.List<arch.amps_sipi.value.RuleEngineErrorType>)getValue($RULEENGINEERRORS));
					buf.append("value.set"+Utility.makeFirstLetterCapital(key)+"((java.util.List<arch."+packageName+".value."+Utility.makeFirstLetterCapital(item.getType())+">)getValue($"+key.toUpperCase()+")); \n");
				}
				else
				buf.append("value.set"+Utility.makeFirstLetterCapital(key)+"(java.lang.String)getValue($"+key.toUpperCase()+"));\n");
			}
			else
				buf.append("value.set"+Utility.makeFirstLetterCapital(key)+"(java.lang.String)getValue($"+key.toUpperCase()+"));\n");
			
		}
	}
		return buf.toString();
	}

private String constructInMappingData() {
	StringBuffer buf = new StringBuffer();
	Iterator i;
	if (completeItems != null) {
		i = completeItems.entrySet().iterator();
		for (int k = 0; i.hasNext() && i != null; k++) {
			Entry entry = (Entry) i.next();
			String key = (String) entry.getKey();
		
	buf.append("if( value.get"+Utility.makeFirstLetterCapital(key)+"() != null ) \n ");
	buf.append(" setValue($"+key.toUpperCase()+", value.get"+Utility.makeFirstLetterCapital(key)+"()); \n ");
		}
	}
	return buf.toString();
	}

private String constructInConstants() {
	StringBuffer buf = new StringBuffer();
	buf.append("private static final int\n");
	Iterator i;

	if (completeItems != null) {
		i = completeItems.entrySet().iterator();
		for (int k = 0; i.hasNext() && i != null; k++) {
			Entry entry = (Entry) i.next();
			String key = (String) entry.getKey();
			
			buf.append("      $" + key.toUpperCase() + "=" + k + ",\n");
		}
		}
	buf.append("     $LENGTH="+length+"; \n");
	return buf.toString();
		
	}

private void contstructFieldTypeList(List<HashMap<String, TypeData>> fieldTypeMapList) {
	if(fieldTypeMapList!=null)
		for(HashMap<String, TypeData> map :fieldTypeMapList) {
			Iterator i = null;
			if (map != null) {
				i = map.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					String key = (String) entry.getKey();
					if(key!=null) {
						fieldTypeList.add(key);
					}
				}
			}	
		}
		
	}

private String constructMMFInputString( List<ItemBase> itemList,String io) {
	StringBuffer buf = new StringBuffer();
	buf.append("private final static FieldMetaData[] parameterInfo = new FieldMetaData[] { \n ");
	//////System.out.println("functionData input ItemList : : : ::"+functionData.inputItemList);
	
	if(itemList!=null) {
		int j = 0;
		int length=0;
		boolean variable=false;
		for (int i = 0; i < itemList.size(); i++) {
			ItemBase item = itemList.get(i);
			String type=retrieveType(item);
			buf.append(getFieldAttribute(item, j, type,io));
			
			if(item.getAllAttributes().get("fixedValue")!=null || item.getAllAttributes().get("default")!=null) {
				String def="";
				if(item.getAllAttributes().get("fixedValue")!=null && item.getAllAttributes().get("fixedValue").length()>0)
				{
				//defaultValueMap.put(item.getName(), item.getAllAttributes().get("fixedValue"));	
				// fieldname: messageType
				 //System.arraycopy("51".getBytes(), 0, buffer,0, 2); 
				
				def="//fieldname: "+item.getName()+"\n";
				def=def+"System.arraycopy(\""+item.getAllAttributes().get("fixedValue")+"\".getBytes(),0,buffer,"+j+","+item.getAllAttributes().get("fixedValue").length()+");\n";
				
				
				}
				if(item.getAllAttributes().get("default")!=null && item.getAllAttributes().get("default").length()>0)
				{
					
					// fieldname: messageType
					 //System.arraycopy("51".getBytes(), 0, buffer,0, 2); 
					
					def="//fieldname: "+item.getName()+"\n";
					def=def+"System.arraycopy(\""+item.getAllAttributes().get("default")+"\".getBytes(),0,buffer,"+j+","+item.getAllAttributes().get("default").length()+");\n";
				//defaultValueMap.put(item.getName(), item.getAllAttributes().get("default"));	
				}
				if(def.length()>0) {
					defaultValueMap.add(def);
					System.out.println(" DEfault : before:"+def);
					System.out.println("size :in :"+defaultValueMap.size());
				}
			}
			
			
			if(type.equals("x")) {
				if(!variable)
				if(item.getAllAttributes().get("variableBlock")!=null && item.getAllAttributes().get("variableBlock").equals("yes")) {
					variable=true;
					/*bIsItVariable = true; 
				 	firstVarBlock = 2; 
					staticDataOffset = 1003; */
					
					String str="bIsItVariable = true; \r\n" + 
							"				 	firstVarBlock ="+i+"; \r\n" + 
									"					staticDataOffset = "+j+";";
					defaultValueMap.add(str);
				}
				
				if(io.equals("input")) {
					if(!inValueList.contains(item.getType()))
					inValueList.add(item.getType());
				}
				else {
					if(!outValueList.contains(item.getType()))
					outValueList.add(item.getType());
				}
			}
			if(!type.equals("header")) {
			if(item.getMaxOccurs()!=null && item.getMaxOccurs().length()>0 && Integer.parseInt(item.getMaxOccurs())>1) {
				/*////System.out.println("Name  :: "+item.getName());
				////System.out.println("size : : "+item.getSize());
				////System.out.println("occurz : :"+item.getMaxOccurs());*/
			int occurs=Integer.parseInt(item.getMaxOccurs());
			int size=Integer.parseInt(item.getSize());
			int total=size*occurs;
			if(type.equals("x")) {
				j=j+total;
				length=length+total;
			}
			else {
				j=j+size;
				length=length+total;
			}
			//////System.out.println(" total: : "+total);
			}
			else
			{
				j = j + Integer.parseInt((item.getSize()));
			
			length=length+Integer.parseInt((item.getSize()));;
			}
			//////System.out.println("length: : "+length);
			}
		}
		this.length=length;
	}
	
		buf.append("};");
		return buf.toString();
	}

public static String getFieldAttribute(ItemBase item, int initial, String type,String io) {
	String name = item.getName(), size = item.getSize(), format = item.getFormat();
	completeItems.put(item.getName(), item);
	if(type.equals("x")) {
		String pack="";
		if(io.equals("input"))
		pack=pack+"arch."+packageName+".service.mdo.MDO"+Utility.makeFirstLetterCapital(item.getType())+"InValueProcess";
		else
			pack=pack+"arch."+packageName+".service.mdo.MDO"+Utility.makeFirstLetterCapital(item.getType())+"OutValueProcess";
		String occurs=item.getMaxOccurs();
		
		if(occurs.length()==0)
			occurs="1";
		////System.out.println(name);
		////System.out.println("Max occurs : "+occurs);
		String s="s="+occurs;
		boolean variable=false;
				if(item.getAllAttributes().get("variableBlock")!=null && item.getAllAttributes().get("variableBlock").equals("yes")) {
					variable=true;
				}
				if(variable)
				{
					return "      new FieldMetaData(\"" + item.getName() + "\"," + initial + "," + (Integer.parseInt(size))
							+ ",\'" + type + "\',\"" + s + ";v;\",\"" +pack + "\"),\n";
				}
				else
					return "      new FieldMetaData(\"" + item.getName() + "\"," + initial + "," + (Integer.parseInt(size))
				+ ",\'" + type + "\',\"" + s + ";\",\"" +pack + "\"),\n";
	}
	if(type.equals("header"))
		return "      new FieldMetaData(\"" + item.getName() + "\"," + initial + "," + 0
				+ ",\'s\',\"" + item.getAllAttributes().get("plheader") + "\"),\n";
	if (format.length() > 0)
		return "      new FieldMetaData(\"" + item.getName() + "\"," + initial + "," + (Integer.parseInt(size))
				+ ",\'" + type + "\',\"" + item.getFormat() + "\"),\n";
	else
		return "      new FieldMetaData(\"" + item.getName() + "\"," + initial + "," + (Integer.parseInt(size))
				+ ",\'" + type + "\'),\n";
}


public  String retrieveType(ItemBase item) {
	String type;
	//////System.out.println(fieldTypeList);
	if (fieldTypeList.contains(item.getType()))
		type = "x";
	else if (item.getType().equals("String"))
		{
		if(item.getAllAttributes().get("plheader")!=null && item.getAllAttributes().get("plheader").length()>0)
			type="header";
		else
			type = "s";
		}
	else if (item.getType().contains("Reserved"))
		type = "r";
	else if (item.getType().contains("Integer"))
		type = "i";
	else if (item.getType().contains("Decimal"))
		type = "d";
	else if (item.getType().equals("Date"))
		type = "e";
	else if (item.getType().contains("Date"))
		type = "g";
	else if (item.getType().equals("Time"))
		type = "t";
	else if (item.getType().contains("Time"))
		type = "h";
	else if (item.getType().contains("Long"))
		type = "l";
	else
		type = "undefined";
	return type;
}

private FunctionData getFunctionData(List<HashMap<String, FunctionData>> functionMapList,String functionNameToFind) {
	if (functionMapList != null) {
		for (HashMap<String, FunctionData> functionMap : functionMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionMap != null) {
				i = functionMap.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					if (entry.getKey().toString().equals(functionNameToFind)) {
						return (FunctionData) entry.getValue();
					}
				}
				if (!con)
					break;
			}
		}
	}
	return null;
}

private TypeData getTypeData(List<HashMap<String, TypeData>> typeMapList,String typeNameToFind) {
	if (typeMapList != null) {
		for (HashMap<String, TypeData> functionMap : typeMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionMap != null) {
				i = functionMap.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					if (entry.getKey().toString().equals(typeNameToFind)) {
						return (TypeData) entry.getValue();
					}
				}
				if (!con)
					break;
			}
		}
	}
	return null;
}


static public void generateFromTemplate(String templateFile, String packageName, String className, VelocityContext context, String serviceName, 
		String fileType) throws Exception {

	String directory = packageName.replace('.', '/');
	//String dirName = "C:\\Data\\MessageExplorer-Jana\\dev\\" + packageName + "\\" + typeName + ".xml";
	
	String dirName="C:\\Data\\MessageExplorer-Jana\\dev\\MDO";
	
	StringWriter stringBuffer = new StringWriter();
	//String outputDir = File.join(coredirectory, directory);
	String outputDir=join(dirName,directory);
	File file = new File(outputDir);
	file.mkdirs();

	String fileName = join(outputDir, className + fileType);
//////System.out.println("File name : : "+fileName);
	//////System.out.println("Generating: " + fileName);

	BufferedWriter writer =
  	      new BufferedWriter(new FileWriter(fileName));
	
	FileWriter output = new FileWriter(new File(fileName));
	Velocity.mergeTemplate(templateFile, context, stringBuffer);
	
	VelocityEngine ve = new VelocityEngine();
	 Properties p = new Properties();
	 p.setProperty("resource.loader", "class");
	 p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
	 ve.init();
       /*  next, get the Template  */
       Template t = ve.getTemplate(templateFile);
       t.merge( context, writer );
	output.write(stringBuffer.toString());
	output.flush();
	output.close();
	//////System.out.println("Create the file"+className+fileType);


}


public static String join(String file, String file2)
{
  return _join(file, file2);
}
private static String _join(String path, String path2)
{
  boolean as, bs;

  if ( path2 == null || path2.length() == 0 )
    {
	return path;
    }

  if ( java.io.File.separatorChar == '\\'  && path2.length() > 1 && path2.charAt(1) == ':' )
    {
	path2 = path2.substring(2);
    }

  as = path.endsWith("/") || path.endsWith("\\");
  bs = path2.startsWith("/") || path2.startsWith("\\");

  StringBuffer res = new StringBuffer(path);

  if ( as && bs )
    {
	res.append(path2.substring(1));
    }
  else if ( as || bs )
    {
	res.append(path2);
    }
  else
    {
	res.append(java.io.File.separatorChar);
	res.append(path2);
    }
  return res.toString();
}




}
