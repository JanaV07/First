package controller;
/**
* HeaderList - used in maintain the Type,Function,Service Controllers
* to maintain all the headers of the class to visible in Type,Function,Service Main Page
* 
* @author VJanarthanan
*/
public class HeaderList {
	public String name;
	public String category;
	public String dated;
	public String author;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDated() {
		return dated;
	}
	public void setDated(String dated) {
		this.dated = dated;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
}
