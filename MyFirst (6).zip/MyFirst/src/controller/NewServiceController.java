package controller;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import application.MainController;
import item.FunctionData;
import item.Header;
import item.ServiceData;
import item.StructureData;
import item.StructureItem;
import item.TypeData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import xml.Bean.MapBean;

/**
 * Create a new Service inside Package
 * 
 * @author VJanarthanan
 */
public class NewServiceController implements Initializable {
	public static HashMap<String, String> newFieldMap = new HashMap<String, String>();
	public static List<String> arrayList = new ArrayList<String>();
	public static String xmlName = ""; // new xml File name
	public static Element element; // new element to get create
	public static HashMap<String, Element> newElementMap = new HashMap<String, Element>(); // Filename,new
																							// element
	public static String application = null;
	public static HashMap<String, String> newServiceMap = new HashMap<String, String>();
	@FXML
	private GridPane grid;
	public static Header header = new Header();
	public static boolean newEntry;
	@FXML
	private Button ok;
	@FXML
	private Button cancel;
	EventHandler<ActionEvent> okButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			try {
				newEntry = true;
				Element newElement;
				newFieldMap.clear();
				newElement = null;
				String key;
				String value = null;
				System.out.println("************AM OK***************");
				// System.out.println(fieldList.size());
				List<StructureItem> list = getFieldProps();
				DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
				DocumentBuilder build = dFact.newDocumentBuilder();
				Document doc = build.newDocument();
				Element message = doc.createElement("message");
				Element header = doc.createElement("header");
				Element inputs = doc.createElement("inputs");
				Element outputs = doc.createElement("outputs");
				String fileName = "";
				String name = "";
				Element paf = doc.createElement("category");
				paf.setTextContent("PAF");
				Element type = doc.createElement("type");
				type.setTextContent("service");
				// header.setCategory(element1);
				header.appendChild(paf);
				header.appendChild(type);
				for (int i = 0; i < arrayList.size(); i++) {
					StructureItem item = list.get(i);
					key = ((Label) getNodeFromGridPane(grid, 0, i)).getText();
					System.out.println(key);
					Node node = getNodeFromGridPane(grid, 1, i);
					if (node instanceof TextField)
						value = ((TextField) node).getText();
					else if (node instanceof ComboBox) {
						if (!((ComboBox) node).getItems().isEmpty())
							value = ((ComboBox) node).getSelectionModel().getSelectedItem().toString();
					} else if (node instanceof TextArea) {
						value = ((TextArea) node).getText();
					}
					if (key.equals("Name")) {
						fileName = value.toLowerCase();
						fileName = fileName.substring(0, 1).toUpperCase() + fileName.substring(1);
						newServiceMap.put(value, fileName);
						name = value;
					} else if (key.equals("Application")) {
						System.out.println("AM setting application");
						MainController.packageName = value;
						application = value;
					} else if (key.equals("Description")) {
						value = value.replace("\n", "&#xA;");
					}
					Element element2 = doc.createElement(item.getTag().replace("/", ""));
					element2.setTextContent(value);
					System.out.println("TAG:::" + item.getTag().replace("/", ""));
					System.out.println("VALue:  :: " + value);
					if (!value.isEmpty() && !item.getLabel().equals("Size")) {
						System.out.println("APpending in header: :" + element2.getTagName());
						header.appendChild(element2);
						newFieldMap.put(item.getTag().replace("/", ""), value);
					}
					// element.setAttribute(item.getTag().replace("/", ""),
					// value);
					
					// System.out.println(newFieldMap.get(key));
				}
				// element.setAttribute("category", "PAF");
				newFieldMap.put("category", "PAF");
				message.appendChild(header);
				message.appendChild(inputs);
				message.appendChild(outputs);
				newElement = (Element) message;
				MainController.element = message;
				element = message;
				xmlName = fileName;
				MainController.xmlName = fileName;
				newElementMap.put(fileName, newElement);
				List<HashMap<String, TypeData>> typeList = MainController.bulkTypeMap.get(application);
				Boolean available = false;
				if (typeList != null)
					for (HashMap<String, TypeData> map : typeList) {
						if (map.containsKey(name)) {
							available = true;
							break;
						}
					}
				List<HashMap<String, FunctionData>> functionList = MainController.bulkFunctionMap.get(application);
				if (functionList != null && !available)
					for (HashMap<String, FunctionData> map : functionList) {
						if (map.containsKey(name)) {
							available = true;
							break;
						}
					}
				List<HashMap<String, ServiceData>> serviceList = MainController.bulkServiceMap.get(application);
				if (serviceList != null && !available)
					for (HashMap<String, ServiceData> map : serviceList) {
						if (map.containsKey(name)) {
							available = true;
							break;
						}
					}
				if (available) {
					newEntry = false;
					Text text = new Text();
					text.setText("Block Already Exist!!!!");
					text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
					text.setX(50);
					text.setY(50);
					Group root = new Group(text);
					Scene scene = new Scene(root, 350, 100);
					Stage stage = new Stage();
					stage.setTitle("Warning");
					stage.setScene(scene);
					stage.show();
				} else {
					newEntry = true;
					Stage stage = (Stage) ok.getScene().getWindow();
					stage.close();
				}
			} catch (Exception e) {
				System.out.println("Am in Exception 95 in NEwType");
				e.printStackTrace();
			}
		}
	};
	EventHandler<ActionEvent> cancelButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			newEntry = false;
			System.out.println("AM Cancel");
			Stage stage = (Stage) cancel.getScene().getWindow();
			stage.close();
		}
	};

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		List<StructureItem> list = getFieldProps();
		arrayList.clear();
		for (int i = 0; i < list.size(); i++) {
			System.out.println("AM : : " + list.get(i).id);
			arrayList.add(list.get(i).id);
			Label label = new Label(list.get(i).getLabel());
			// RowConstraints row=new RowConstraints();
			GridPane.setConstraints(label, 0, i);
			System.out.println(label.getText());
			grid.getChildren().add(label);
			if (label.getText().equals("Application")) {
				ComboBox<String> combo = new ComboBox<>(FXCollections.observableArrayList(MainController.packageList));
				System.out.println("COMBO : :: " + FXCollections.observableArrayList(MainController.packageList));
				if (MainController.application != null) {
					combo.getSelectionModel().select(MainController.application);
				} else
					combo.getSelectionModel().select(0);
				GridPane.setConstraints(combo, 1, i);
				grid.getChildren().add(combo);
			} else if (label.getText().equals("Description")) {
				TextArea itf = new TextArea();
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
			} else if (label.getText().equals("Dated")) {
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				Date date = new Date();
				TextField itf = new TextField(dateFormat.format(date));
				itf.setEditable(false);
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
			} else if (label.getText().equals("Size")) {
				TextField itf = new TextField();
				itf.setEditable(false);
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
			} else {
				TextField field = new TextField();
				GridPane.setConstraints(field, 1, i);
				grid.getChildren().add(field);
			}
		}
		allign();
		ok.setOnAction(okButtonHandler);
		cancel.setOnAction(cancelButtonHandler);
		/*
		 * label.setCellValueFactory(new PropertyValueFactory<>("label"));
		 * value.setCellValueFactory(new PropertyValueFactory<StructureItem,
		 * TextField>("value")); table.setItems(getFieldProps());
		 * table.setEditable(true);
		 */
		/*
		 * table.setFixedCellSize(25);
		 * table.prefHeightProperty().bind(table.fixedCellSizeProperty().
		 * multiply(Bindings.size(table.getItems()).add(1.01)));
		 * table.minHeightProperty().bind(table.prefHeightProperty());
		 * table.maxHeightProperty().bind(table.prefHeightProperty());
		 */
		// getFieldProps();
	}

	// Alligning the Grid
	public void allign() {
		// make all of the Controls and Panes inside the grid fill their grid
		// cell,
		// align them in the center and give them a filled background.
		// you could also place each of them in their own centered StackPane
		// with
		// a styled background to achieve the same effect.
		for (Node n : grid.getChildren()) {
			if (n instanceof Control) {
				Control control = (Control) n;
				control.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
				control.setStyle("-fx-background-color: white; -fx-alignment: Left;");
			}
			if (n instanceof Pane) {
				Pane pane = (Pane) n;
				pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
				pane.setStyle("-fx-background-color: grey; -fx-alignment: center;");
			}
		}
		// style the grid so that it has a background and gaps around the grid
		// and
		// between the
		// grid cells so that the background will show through as grid lines.
		grid.setStyle("-fx-background-color: grey; -fx-padding: 2; -fx-hgap: 2; -fx-vgap: 2;");
		// turn layout pixel snapping off on the grid so that grid lines will be
		// an even
		// width.
		grid.setSnapToPixel(false);
	}

	private Node getNodeFromGridPane(GridPane gridPane, int col, int row) {
		for (Node node : gridPane.getChildren()) {
			if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
				return node;
			}
		}
		return null;
	}

	public ObservableList<StructureItem> getFieldProps() {
		// System.out.println("Type Name : : :"+serviceName);
		System.out.println("*******************************AM hERE");
		StructureData structureData = MapBean.getStructureMap().get("service");
		// System.out.println(structureData.getHeaderList());
		ObservableList<StructureItem> itemList = FXCollections.observableArrayList(structureData.getHeaderList());
		// System.out.println("AM : : : : : "+itemList);
		// for(StructureItem item:itemList)
		// System.out.println("Am : : : :"+item.getId());
		return itemList;
	}
}