package controller;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Map.Entry;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import application.MainController;
import item.FunctionData;
import item.Header;
import item.ServiceData;
import item.StructureData;
import item.StructureItem;
import item.TypeData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import xml.Bean.MapBean;

/**
 * Editing a Function block
 * view - EditFunction.fxml
 
 * @author VJanarthanan
 */
public class EditFunctionController implements Initializable {
	public static HashMap<String, String> newFieldMap = new HashMap<String, String>();
	public static List<String> arrayList = new ArrayList<String>();
	public static String xmlName = ""; // new xml File name
	public static Element element; // new element to get create
	public static HashMap<String, Element> newElementMap = new HashMap<String, Element>(); // Filename,new
																							// element
	public static String application = null;
	public static HashMap<String, String> newTypeMap = new HashMap<String, String>();
	public static boolean newEntry = false;
	public static HashMap<String, String> newFunctionMap = new HashMap<String, String>();
	@FXML
	private GridPane grid;
	public static Header header = new Header();
	public static String oldFunctionName; 
	public static String oldName;
	@FXML
	private Button ok;
	@FXML
	private Button cancel;
	EventHandler<ActionEvent> okButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			try {
				newEntry = true;
				Element newElement;
				newFieldMap.clear();
				newElement = null;
				String key;
				String value = null;
				System.out.println("************AM OK***************");
				// System.out.println(fieldList.size());
				List<StructureItem> list = getFieldProps();
				DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
				DocumentBuilder build = dFact.newDocumentBuilder();
				Document doc = build.newDocument();
				
				Element header = doc.createElement("header");
				Element items = doc.createElement("items");
				String fileName = "";
				Element paf = doc.createElement("category");
				paf.setTextContent("PAF");
				Element type = doc.createElement("type");
				type.setTextContent("function");
				// header.setCategory(element1);
				header.appendChild(paf);
				header.appendChild(type);
				
				
/*				Element message = doc.createElement("message");
				Element header = doc.createElement("header");
				Element inputs = doc.createElement("inputs");
				inputs.setAttribute("minOccurs", "1");
				inputs.setAttribute("maxOccurs", "1");
				Element outputs = doc.createElement("outputs");
				outputs.setAttribute("minOccurs", "1");
				outputs.setAttribute("maxOccurs", "1");
*/	/*			String fileName = "";
	*/			String name = "";
	/*			Element paf = doc.createElement("category");
				paf.setTextContent("PAF");
				Element type = doc.createElement("type");
				type.setTextContent("function");
				// header.setCategory(element1);
	*/			
				header.appendChild(type);
				for (int i = 0; i < arrayList.size(); i++) {
					StructureItem item = list.get(i);
					key = ((Label) getNodeFromGridPane(grid, 0, i)).getText();
					System.out.println(key);
					Node node = getNodeFromGridPane(grid, 1, i);
					if (node instanceof TextField)
						value = ((TextField) node).getText();
					else if (node instanceof ComboBox) {
						if (!((ComboBox) node).getItems().isEmpty())
							value = ((ComboBox) node).getSelectionModel().getSelectedItem().toString();
					} else if (node instanceof TextArea) {
						value = ((TextArea) node).getText();
					}
					if (key.equals("Function Id")) {
						fileName = value.toLowerCase();
						fileName = fileName.substring(0, 1).toUpperCase() + fileName.substring(1);
						newFunctionMap.put(value, fileName);
						name = value;
					} else if (key.equals("Application")) {
						System.out.println("AM setting application");
						MainController.packageName = value;
						application = value;
					} else if (key.equals("Description")) {
						value = value.replace("\n", "&#xA;");
					}
					Element element2 = doc.createElement(item.getTag().replace("/", ""));
					element2.setTextContent(value);
					System.out.println("TAG:::" + item.getTag().replace("/", ""));
					System.out.println("VALue:  :: " + value);
					if (!value.isEmpty() && !item.getLabel().equals("Size")) {
						System.out.println("APpending in header: :" + element2.getTagName());
						header.appendChild(element2);
						newFieldMap.put(item.getTag().replace("/", ""), value);
					}
					// element.setAttribute(item.getTag().replace("/", ""),
					// value);
					
					// System.out.println(newFieldMap.get(key));
				}
				// element.setAttribute("category", "PAF");
				newFieldMap.put("category", "PAF");
				newElement = (Element) header;
				MainController.element = header;
				element = header;
				xmlName = fileName;
				MainController.xmlName = fileName;
				newElementMap.put(fileName, newElement);
				/*message.appendChild(header);
				message.appendChild(inputs);
				message.appendChild(outputs);
				newElement = (Element) message;
				MainController.element = message;
				element = message;*/
				Boolean available = false;
				System.out.println("old FUInciton Name : : "+oldFunctionName);
				System.out.println("new NAem : : "+name);
				if(!oldName.equals(name))
				{
					List<HashMap<String, TypeData>> typeList = MainController.bulkTypeMap.get(application);
				
				
				if (typeList != null)
					for (HashMap<String, TypeData> map : typeList) {
						if (map.containsKey(name)) {
							available = true;
							break;
						}
					}
				List<HashMap<String, FunctionData>> functionList = MainController.bulkFunctionMap.get(application);
				if (functionList != null && !available)
					for (HashMap<String, FunctionData> map : functionList) {
						if (map.containsKey(name)) {
							available = true;
							break;
						}
					}
				List<HashMap<String, ServiceData>> serviceList = MainController.bulkServiceMap.get(application);
				if (serviceList != null && !available)
					for (HashMap<String, ServiceData> map : serviceList) {
						if (map.containsKey(name)) {
							available = true;
							break;
						}
					}
				}
				if (available) {
					newEntry = false;
					Text text = new Text();
					text.setText("Block Already Exist!!!!");
					text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
					text.setX(50);
					text.setY(50);
					Group root = new Group(text);
					Scene scene = new Scene(root, 350, 100);
					Stage stage = new Stage();
					stage.setTitle("Warning");
					stage.setScene(scene);
					stage.show();
				} else {
					newEntry = true;
					Stage stage = (Stage) ok.getScene().getWindow();
					stage.close();
				}
			} catch (Exception e) {
				System.out.println("Am in Exception 95 in NEwType");
				e.printStackTrace();
			}
		}
	};
	EventHandler<ActionEvent> cancelButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			newEntry = false;
			System.out.println("AM Cancel");
			Stage stage = (Stage) cancel.getScene().getWindow();
			stage.close();
		}
	};

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		setElement();
		List<StructureItem> list = getFieldProps();
		arrayList.clear();
		for (int i = 0; i < list.size(); i++) {
			StructureItem item = list.get(i);
			String key = item.getTag().replace("/", "");
			System.out.println("AM : : " + list.get(i).id);
			System.out.println("KEY : : : :: "+key);
			System.out.println("AM : value : " + newFieldMap.get(key));

			arrayList.add(list.get(i).id);
			Label label = new Label(list.get(i).getLabel());
			// RowConstraints row=new RowConstraints();
			GridPane.setConstraints(label, 0, i);
			System.out.println("Labe  : : " + label.getText());
			grid.getChildren().add(label);
			if (label.getText().equals("Application")) {
				ComboBox<String> combo = new ComboBox<>(FXCollections.observableArrayList(MainController.packageList));
				// System.out.println("APP: : "+MainController.application);
				if (newFieldMap.containsKey(key))
					combo.getSelectionModel().select(newFieldMap.get(key));
				else if (MainController.application != null) {
					combo.getSelectionModel().select(MainController.application);
				} else
					combo.getSelectionModel().select(0);
				GridPane.setConstraints(combo, 1, i);
				grid.getChildren().add(combo);

			} else if (label.getText().equals("Description")) {
				TextArea itf = new TextArea();
				if (newFieldMap.containsKey(key))
					itf.setText((String) newFieldMap.get(key).replace("&#xA;", "\n"));
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
			} else if (label.getText().equals("Dated")) {
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				Date date = new Date();
				TextField itf = null;
				if (newFieldMap.containsKey(key))
					itf = new TextField(newFieldMap.get(key));
				else
					itf = new TextField(dateFormat.format(date));

				itf.setEditable(false);
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
			} else if (label.getText().equals("Size")) {

				TextField itf = new TextField();
				itf.setEditable(false);
				GridPane.setConstraints(itf, 1, i);
				grid.getChildren().add(itf);
			} else {
				TextField field = null;
				if (newFieldMap.containsKey(key))
					field = new TextField(newFieldMap.get(key));
				else
					field = new TextField();
				GridPane.setConstraints(field, 1, i);
				grid.getChildren().add(field);
			}
		}
		grid.add(ok, 0, list.size());
		allign();
		ok.setOnAction(okButtonHandler);
		cancel.setOnAction(cancelButtonHandler);
	}

	// Alligning the Grid
	public void allign() {
		for (Node n : grid.getChildren()) {
			if (n instanceof Button) {

			} else {
				if (n instanceof Control) {
					Control control = (Control) n;
					control.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
					control.setStyle("-fx-background-color: white; -fx-alignment: Left;");
				}
				if (n instanceof Pane) {
					Pane pane = (Pane) n;
					pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
					pane.setStyle("-fx-background-color: grey; -fx-alignment: center;");
				}
			}
		}

		grid.setStyle("-fx-background-color: grey; -fx-padding: 1; -fx-hgap: 1; -fx-vgap: 1;");

		grid.setSnapToPixel(false);
	}

	private Node getNodeFromGridPane(GridPane gridPane, int col, int row) {
		for (Node node : gridPane.getChildren()) {
			if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
				return node;
			}
		}
		return null;
	}

	public ObservableList<StructureItem> getFieldProps() {
		// System.out.println("Type Name : : :"+serviceName);
		// System.out.println("*******************************AM hERE");
		StructureData structureData = MapBean.getStructureMap().get("function");
		// System.out.println(structureData.getHeaderList());
		ObservableList<StructureItem> itemList = FXCollections.observableArrayList(structureData.getHeaderList());
		// System.out.println("AM : : : : : "+itemList);
		// for(StructureItem item:itemList)
		// System.out.println("Am : : : :"+item.getId());
		return itemList;
	}

	public void setElement() {
		System.out.println("inside set");
		List<HashMap<String, FunctionData>> functionMapList = MainController.bulkFunctionMap.get(MainController.application);
		// System.out.println(oldTypeName);
		for (HashMap<String, FunctionData> functionName : functionMapList) {
			Iterator i = null;
			boolean con = true;
			if (functionName != null) {
				i = functionName.entrySet().iterator();
				while (i.hasNext() && i != null) {
					Entry entry = (Entry) i.next();
					if (entry != null) {
						 System.out.println("********"+entry.getKey());
						if (entry.getKey().toString().equals(oldFunctionName)) {
							//\\ System.out.println(((TypeData)entry.getValue()).getSize());
							// System.out.println(((TypeData)entry.getValue()).getSize());
							FunctionData function = ((FunctionData) entry.getValue());
							Header header = ((FunctionData) entry.getValue()).getHeader();
							oldName =header.getAllElements().get("name");
							oldFunctionName = function.getFileName();
							newFieldMap = header.getAllElements();
							System.out.println(newFieldMap);
							con = false;
						}
					}
				}
			}
			if (!con)
				break;
		}
	}
}