package controller;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import application.MainApp;
import item.ItemBase;
import item.TypeData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import xml.UpdateMap;
import xml.UpdateXML;

/**
 * Inside the Type
 * Views the data inside the Type
 * view - InType.fxml
 * 
 * @author VJanarthanan
 */
public class InTypeController implements Initializable {
	public static String typeName;
	public static String packageName;
	public static List<HashMap<String, TypeData>> typeList;
	public static ObservableList<ItemBase> observableItemList;
	public static ObservableList<String> fieldTypeList = FXCollections.observableArrayList();
	public static HashMap<String, String> typeSizeMap = new HashMap<String, String>();
	public static HashMap<Integer, ItemBase> changeMap = new HashMap<Integer, ItemBase>();
	@FXML
	Label typeLabel;
	@FXML
	private TableView<HeaderList> topTable;
	@FXML
	private TableView<ItemBase> inputTable;
	@FXML
	private TableView<ItemBase> outputTable;
	@FXML
	private TableColumn<ItemBase, String> iname;
	@FXML
	private TableColumn<ItemBase, String> itype;
	@FXML
	private TableColumn<ItemBase, String> isize;
	@FXML
	private TableColumn<ItemBase, String> irequired;
	@FXML
	private TableColumn<ItemBase, String> imaxOccurs;
	@FXML
	private TableColumn<ItemBase, String> iprecision;
	@FXML
	private TableColumn<ItemBase, String> iTotalSize;
	@FXML
	private Button addNewB;
	@FXML
	private Button deleteB;
	@FXML
	private Button moveUpB;
	@FXML
	private Button moveDownB;

	public static String getTypeName() {
		return typeName;
	}

	public static void setTypeName(String typeName) {
		InTypeController.typeName = typeName;
	}

	public static List<HashMap<String, TypeData>> getTypeList() {
		return typeList;
	}

	public static void setTypeList(List<HashMap<String, TypeData>> typeList) {
		InTypeController.typeList = typeList;
	}

	public static String getPackageName() {
		return packageName;
	}

	public static void setPackageName(String packageName) {
		InTypeController.packageName = packageName;
	}

	EventHandler<ActionEvent> downButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// System.out.println("Am here");
			ItemBase item = inputTable.getSelectionModel().getSelectedItem();
			int index = inputTable.getSelectionModel().getSelectedIndex();
			changeMap.put(index, item);
			downButtonFunction(index, item);
			// System.out.println("index "+index);
			if (index < inputTable.getItems().size() - 1) {
				inputTable.getItems().add(index + 1, inputTable.getItems().remove(index));
				// select item at new position
				// System.out.println("size "+inputTable.getItems().size());
				inputTable.getSelectionModel().clearAndSelect(index + 1);
			}
			// System.out.println(item.getName());
			event.consume();
		}
	};
	EventHandler<ActionEvent> upButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// System.out.println("Am here");
			ItemBase item = inputTable.getSelectionModel().getSelectedItem();
			int index = inputTable.getSelectionModel().getSelectedIndex();
			upButtonFunction(index, item);
			// System.out.println("index "+index);
			if (index > 0) {
				inputTable.getItems().add(index - 1, inputTable.getItems().remove(index));
				// select item at new position
				// System.out.println("size "+inputTable.getItems().size());
				inputTable.getSelectionModel().clearAndSelect(index - 1);
			}
			// System.out.println(item.getName());
			event.consume();
		}
	};
	EventHandler<ActionEvent> addNewButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			//////////////// SUB WINDOW////////////////////
			Parent parent = null;
			try {
				parent = (Parent) FXMLLoader.load(getClass().getResource("/View/NewFieldType.fxml"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Stage stage = new Stage();
			// stage.initStyle(StageStyle.TRANSPARENT);
			stage.setTitle("New Field");
			stage.setScene(new Scene(parent));
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(MainApp.getStage());
			stage.setResizable(false);
			stage.showAndWait();
			//////////////// SUB WINDOW////////////////////
			System.out.println("add Operation");
			int index = inputTable.getSelectionModel().getSelectedIndex();
			System.out.println("INDEX: : : :" + index);
			if (NewFieldTypeController.newEntry)
				addButtonFunction(index);
			NewFieldTypeController.newEntry = false;
		}
	};
	EventHandler<ActionEvent> deleteButtonHandler = new EventHandler<ActionEvent>() {
		@Override
		public void handle(ActionEvent event) {
			// label.setText("Accepted");
			// System.out.println("Am here");
			ItemBase item = inputTable.getSelectionModel().getSelectedItem();
			int index = inputTable.getSelectionModel().getSelectedIndex();
			inputTable.getItems().remove(item);
			deleteButtonFunction(index, item);
			// upButtonFunction(index,item);
			// System.out.println("index "+index);
			// if(index>0){
			// inputTable.getItems().add(index-1,
			// inputTable.getItems().remove(index));
			// select item at new position
			// System.out.println("size "+inputTable.getItems().size());
			// System.out.println(item.getName());
			event.consume();
		}
	};

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		construct();
		addNewB.setOnAction(addNewButtonHandler);
		moveUpB.setOnAction(upButtonHandler);
		moveDownB.setOnAction(downButtonHandler);
		deleteB.setOnAction(deleteButtonHandler);
	}

	protected void editButtonFunction(int index) {
		// System.out.println("Am insdie func");
		System.out.println("INDEX : : : :: : " + index);
		HashMap<String, String> newFieldMap = new HashMap<String, String>();
		;
		Iterator i = null;
		if (EditFieldController.newFieldMap != null) {
			i = EditFieldController.newFieldMap.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				if (entry != null) {
					newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
				}
			}
		}
		HashMap<String, String> allAttributes = new HashMap<String, String>();
		if (EditFieldController.allAttributes != null) {
			i = EditFieldController.allAttributes.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				if (entry != null) {
					allAttributes.put((String) entry.getKey(), (String) entry.getValue());
				}
			}
		}
		ItemBase itemBase = new ItemBase();
		if (newFieldMap.get("Name") != null && !newFieldMap.get("Name").isEmpty()) {
			System.out.println("Am creating");
			itemBase.setName(newFieldMap.get("Name"));
			itemBase.setType(newFieldMap.get("Type"));
			itemBase.setSize(newFieldMap.get("Size"));
			itemBase.setRequired(newFieldMap.get("Required"));
			itemBase.setMaxOccurs(newFieldMap.get("maxOccurs"));
			itemBase.setPrecision(newFieldMap.get("Precision"));
			itemBase.setFormat(newFieldMap.get("MQ Format"));
			itemBase.setAllAttributes(allAttributes);
			int totalSize;
			if (itemBase.getFormat() != null && itemBase.getFormat().length() > 0) {
				totalSize = itemBase.getFormat().length();
			} else if (itemBase.getPrecision() != null && itemBase.getPrecision().length() > 0) {
				totalSize = Integer.parseInt(itemBase.getSize()) + Integer.parseInt(itemBase.getPrecision()) + 1;
			} else
				totalSize = Integer.parseInt(itemBase.getSize());
			itemBase.setTotalSize(totalSize + "");
			System.out.println("INXDEX : : : :" + index);
			observableItemList.remove(index);
			observableItemList.add(index, itemBase);
			int size = UpdateMap.addButtonTypeFunction(packageName, typeName, index, NewFieldTypeController.newFieldMap,
					itemBase, true);
			System.out.println("size" + size);
			UpdateXML.addButtonTypeFunction(packageName, typeName, index, size, true);
		}
	}

	protected void addButtonFunction(int index) {
		HashMap<String, String> newFieldMap = new HashMap<String, String>();
		;
		Iterator i = null;
		if (NewFieldTypeController.newFieldMap != null) {
			i = NewFieldTypeController.newFieldMap.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				if (entry != null) {
					newFieldMap.put((String) entry.getKey(), (String) entry.getValue());
				}
			}
		}
		HashMap<String, String> allAttributes = new HashMap<String, String>();
		if (NewFieldTypeController.allAttributes != null) {
			i = NewFieldTypeController.allAttributes.entrySet().iterator();
			while (i.hasNext() && i != null) {
				Entry entry = (Entry) i.next();
				if (entry != null) {
					allAttributes.put((String) entry.getKey(), (String) entry.getValue());
				}
			}
		}
		ItemBase itemBase = new ItemBase();
		if (newFieldMap.get("Name") != null && !newFieldMap.get("Name").isEmpty()) {
			itemBase.setName(newFieldMap.get("Name"));
			itemBase.setType(newFieldMap.get("Type"));
			itemBase.setSize(newFieldMap.get("Size"));
			itemBase.setRequired(newFieldMap.get("Required"));
			itemBase.setMaxOccurs(newFieldMap.get("maxOccurs"));
			itemBase.setPrecision(newFieldMap.get("Precision"));
			itemBase.setAllAttributes(allAttributes);
			itemBase.setFormat(newFieldMap.get("MQ Format"));
			int totalSize;
			if (itemBase.getFormat() != null && itemBase.getFormat().length() > 0) {
				totalSize = itemBase.getFormat().length();
			} else if (itemBase.getPrecision() != null && itemBase.getPrecision().length() > 0) {
				totalSize = Integer.parseInt(itemBase.getSize()) + Integer.parseInt(itemBase.getPrecision()) + 1;
			} else
				totalSize = Integer.parseInt(itemBase.getSize());
			itemBase.setTotalSize(totalSize + "");
			if (index < 0)
				observableItemList.add(itemBase);
			else
				observableItemList.add(index + 1, itemBase);
			int size = UpdateMap.addButtonTypeFunction(packageName, typeName, index, NewFieldTypeController.newFieldMap,
					itemBase, false);
			UpdateXML.addButtonTypeFunction(packageName, typeName, index, size, false);
			// inputTable.refresh();
		}
	}

	protected void deleteButtonFunction(int index, ItemBase item) {
		UpdateXML.moveButtonTypeFunction(packageName, typeName, index, "Delete");
		UpdateMap.moveButtonTypeFunction(packageName, typeName, index, item, "Delete");
	}

	protected void downButtonFunction(int index, ItemBase item) {
		System.out.println("index : : :: " + index + "listsize : :" + observableItemList.size());
		if (index < observableItemList.size() - 1) {
			System.out.println("Package Name : : " + packageName);
			System.out.println("Type Name : : : " + typeName);
			UpdateXML.moveButtonTypeFunction(packageName, typeName, index, "D");
			UpdateMap.moveButtonTypeFunction(packageName, typeName, index, item, "D");
		}
	}

	protected void upButtonFunction(int index, ItemBase item) {
		System.out.println("index : : :: " + index + "listsize : :" + observableItemList.size());
		if (index > 0) {
			System.out.println("Package Name : : " + packageName);
			System.out.println("Type Name : : : " + typeName);
			UpdateXML.moveButtonTypeFunction(packageName, typeName, index, "U");
			UpdateMap.moveButtonTypeFunction(packageName, typeName, index, item, "U");
		}
	}

	public void construct() {
		typeLabel.setText(typeName);
		iname.setCellValueFactory(new PropertyValueFactory<>("name"));
		itype.setCellValueFactory(new PropertyValueFactory<>("type"));
		isize.setCellValueFactory(new PropertyValueFactory<>("size"));
		irequired.setCellValueFactory(new PropertyValueFactory<>("required"));
		imaxOccurs.setCellValueFactory(new PropertyValueFactory<>("maxOccurs"));
		iprecision.setCellValueFactory(new PropertyValueFactory<>("precision"));
		iTotalSize.setCellValueFactory(new PropertyValueFactory<>("totalSize"));
		iname.setPrefWidth(200.0);
		itype.setPrefWidth(100.0);
		iname.setSortable(false);
		itype.setSortable(false);
		isize.setSortable(false);
		irequired.setSortable(false);
		imaxOccurs.setSortable(false);
		// System.out.println("Calling Input");
		// System.out.println(serviceList);
		// System.out.println(typeList);
		observableItemList = getInTypesList(typeList);
		inputTable.setItems(observableItemList);
		inputTable.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
					Node node = ((Node) event.getTarget()).getParent();
					TableRow row = null;
					if (node instanceof TableRow) {
						row = (TableRow) node;
					} else {
						// clicking on text part
						row = (TableRow) node.getParent();
					}
					// System.out.println(((ItemBase)row.getItem()).getName());
					editField(((ItemBase) row.getItem()));
				}
			}
		});
		// System.out.println("Calling Output");
		// System.out.println(outputServiceList);
	}

	protected void editField(ItemBase itemBase) {
		System.out.println(packageName);
		System.out.println(typeName);
		System.out.println(itemBase.getName());
		System.out.println(itemBase.getAllAttributes());
		//EditFieldController.newFieldMap.clear();
		EditFieldController.newFieldMap = itemBase.getAllAttributes();
		// System.out.println(itemBase.);
		Parent parent = null;
		try {
			parent = (Parent) FXMLLoader.load(getClass().getResource("/View/EditFieldType.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Stage stage = new Stage();
		// stage.initStyle(StageStyle.TRANSPARENT);
		stage.setTitle("Edit Field");
		stage.setScene(new Scene(parent));
		stage.initModality(Modality.WINDOW_MODAL);
		stage.initOwner(MainApp.getStage());
		stage.setResizable(false);
		stage.showAndWait();
		System.out.println("edit Operation");
		int index = inputTable.getSelectionModel().getSelectedIndex();
		System.out.println("INDEX: : : :" + index);
		if (EditFieldController.newEntry) {
			editButtonFunction(index);
			// UpdateMap.updateTypeField(packageName,typeName,index,EditFieldController.newFieldMap);
		}
		EditFieldController.newEntry = false;
	}

	public ObservableList<ItemBase> getInTypesList(List<HashMap<String, TypeData>> typeMapList) {
		fieldTypeList.clear();
		typeSizeMap.clear();
		// System.out.println("Service Name : : :"+serviceName);
		ObservableList<ItemBase> itemList = FXCollections.observableArrayList();
		if (typeMapList != null) {
			for (HashMap<String, TypeData> typeMap : typeMapList) {
				Iterator i = null;
				boolean con = true;
				if (typeMap != null) {
					i = typeMap.entrySet().iterator();
					while (i.hasNext() && i != null) {
						Entry entry = (Entry) i.next();
						if (entry != null)
							if (entry.getKey().toString().equals(typeName)) {
								// System.out.println(("*******"+((TypeData)
								// entry.getValue()).getSize()));
								if (((TypeData) entry.getValue()).getItemList() != null)
									for (ItemBase item : ((TypeData) entry.getValue()).getItemList()) {
										itemList.add(item);
									}
							} else {
								fieldTypeList.add(entry.getKey().toString());
								typeSizeMap.put(entry.getKey().toString(),
										((TypeData) entry.getValue()).getSize() + "");
							}
					}
				}
			}
			// HashMap<String,Object> hashMap=list.get
			// System.out.println(itemList.size());
			return itemList;
		} else
			return null;
	}
}