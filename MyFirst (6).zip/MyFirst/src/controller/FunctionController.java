package controller;

import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import controller.HeaderList;
import item.Header;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Function Main page - Shows all the Functions inside the Package
 * View - FunctionController.fxml
 * 
 * @author VJanarthanan
 */
public class FunctionController implements Initializable {
	public static HashMap<String, List<Header>> functionMap;
	public static String Package;
	@FXML
	Label application;
	@FXML
	private TableView<HeaderList> table;
	@FXML
	private TableColumn<Header, String> nameColumn;
	@FXML
	private TableColumn<Header, String> categoryColumn;
	@FXML
	private TableColumn<Header, String> datedColumn;
	@FXML
	private TableColumn<Header, String> authorCoulumn;

	public static HashMap<String, List<Header>> getFunctionMap() {
		return functionMap;
	}

	public static void setFunctionMap(HashMap<String, List<Header>> functionMap) {
		FunctionController.functionMap = functionMap;
	}

	public static String getPackage() {
		return Package;
	}

	public static void setPackage(String package1) {
		Package = package1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		application.setText(Package);
		// System.out.println(functionMap);
		nameColumn.setCellValueFactory(new PropertyValueFactory<Header, String>("name"));
		categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
		datedColumn.setCellValueFactory(new PropertyValueFactory<>("dated"));
		authorCoulumn.setCellValueFactory(new PropertyValueFactory<>("author"));
		// System.out.println("++++++++++++++++ssss+++: : : :" +
		// nameColumn.getCellData(2));
		table.setItems(getFunctionList());
		// System.out.println(getFunctionList());
		// System.out.println("+++++++++++++++++++: : : :" +
		// nameColumn.getCellData(2));
	}

	public ObservableList<HeaderList> getFunctionList() {
		// System.out.println("function Maop : : :: " + functionMap);
		List<Header> headerList = functionMap.get(Package);
		// System.out.println("LIST*******************************************"
		// + headerList.size());
		ObservableList<HeaderList> FunctionList = FXCollections.observableArrayList();
		for (Header header : headerList) {
			// System.out.println("::: : :" +
			// header.getName().getTextContent());
			HeaderList type = new HeaderList();
			type.setName(header.getName().getTextContent());
			if(header.getAuthor()!=null)
			type.setAuthor(header.getAuthor().getTextContent());
			type.setDated(header.getCreated().getTextContent());
			type.setCategory(header.getCategory().getTextContent());
			FunctionList.add(type);
		}
		return FunctionList;
	}
}