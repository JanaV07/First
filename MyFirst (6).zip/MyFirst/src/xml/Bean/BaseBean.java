package xml.Bean;

import java.util.HashMap;
import java.util.List;

import item.FunctionData;
import item.ItemBase;
import item.ServiceData;
import item.TypeData;
/**
*
* 
* @author VJanarthanan
*/
public class BaseBean {
public String id;
public String label;
public String selected;
public String visible;
public String header;
public String servlet_vo;
public String servlet_v6;
public String servlet_v7;
public String servlet_v8;
public String model;
public String onlyxmlapp;
public List<BaseBean> baseList;
public List<HashMap<String,Object>> headerList;
public List<HashMap<String,Object>> typesList;
/*public List<HashMap<String, List<ItemBase>>> functionInputlist;
public List<HashMap<String, List<ItemBase>>> functionOutputlist;
public List<HashMap<String, List<ItemBase>>> serviceInputlist;
public List<HashMap<String, List<ItemBase>>> serviceOutputlist;*/

public List<HashMap<String,TypeData>> typeMapList;
public List<HashMap<String,FunctionData>> functionMapList;
public List<HashMap<String,ServiceData>> serviceMapList;



public List<HashMap<String, FunctionData>> getFunctionMapList() {
	return functionMapList;
}
public void setFunctionMapList(List<HashMap<String, FunctionData>> functionMapList) {
	this.functionMapList = functionMapList;
}
public List<HashMap<String, ServiceData>> getServiceMapList() {
	return serviceMapList;
}
public void setServiceMapList(List<HashMap<String, ServiceData>> serviceMapList) {
	this.serviceMapList = serviceMapList;
}
public List<HashMap<String, TypeData>> getTypeMapList() {
	return typeMapList;
}
public void setTypeMapList(List<HashMap<String, TypeData>> typeMapList) {
	this.typeMapList = typeMapList;
}

public List<HashMap<String, Object>> getTypesList() {
	return typesList;
}
public void setTypesList(List<HashMap<String, Object>> typesList) {
	this.typesList = typesList;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}

public List getHeaderList() {
	return headerList;
}
public void setHeaderList(List headerList) {
	this.headerList = headerList;
}
public List<BaseBean> getBaseList() {
	return baseList;
}
public void setBaseList(List<BaseBean> baseList) {
	this.baseList = baseList;
}
public String getLabel() {
	return label;
}
public void setLabel(String label) {
	this.label = label;
}
public String getSelected() {
	return selected;
}
public void setSelected(String selected) {
	this.selected = selected;
}
public String getVisible() {
	return visible;
}
public void setVisible(String visible) {
	this.visible = visible;
}
public String getHeader() {
	return header;
}
public void setHeader(String header) {
	this.header = header;
}
public String getServlet_vo() {
	return servlet_vo;
}
public void setServlet_vo(String servlet_vo) {
	this.servlet_vo = servlet_vo;
}
public String getServlet_v6() {
	return servlet_v6;
}
public void setServlet_v6(String servlet_v6) {
	this.servlet_v6 = servlet_v6;
}
public String getServlet_v7() {
	return servlet_v7;
}
public void setServlet_v7(String servlet_v7) {
	this.servlet_v7 = servlet_v7;
}
public String getServlet_v8() {
	return servlet_v8;
}
public void setServlet_v8(String servlet_v8) {
	this.servlet_v8 = servlet_v8;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getOnlyxmlapp() {
	return onlyxmlapp;
}
public void setOnlyxmlapp(String onlyxmlapp) {
	this.onlyxmlapp = onlyxmlapp;
}
}
