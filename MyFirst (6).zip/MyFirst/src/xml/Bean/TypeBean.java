package xml.Bean;

import org.w3c.dom.Element;

public class TypeBean {
public static Element fieldSize;

}
