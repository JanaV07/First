package xml;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.sun.javafx.scene.traversal.TopMostTraversalEngine;
import item.FunctionData;
import item.Header;
import item.ItemBase;
import item.ServiceData;
import item.StructureData;
import item.StructureItem;
import item.TypeData;
import javafx.scene.control.TextField;
import xml.Bean.MapBean;

/**
 *
 * 
 * @author VJanarthanan
 */
public class ReadXML {
	@SuppressWarnings("unlikely-arg-type")
	public static HashMap<String, Object> readExistingStructure(File file) {
		HashMap<String, List<ItemBase>> functionInputMap = new HashMap<String, List<ItemBase>>();
		HashMap<String, List<ItemBase>> functionOutputMap = new HashMap<String, List<ItemBase>>();
		HashMap<String, List<ItemBase>> serviceInputMap = new HashMap<String, List<ItemBase>>();
		HashMap<String, List<ItemBase>> serviceOutputMap = new HashMap<String, List<ItemBase>>();
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		HashMap<String, TypeData> typeMap = new HashMap<String, TypeData>();
		HashMap<String, FunctionData> functionMap = new HashMap<String, FunctionData>();
		HashMap<String, ServiceData> serviceMap = new HashMap<String, ServiceData>();
		String key = file.getName();
		// System.out.println("filename : :
		// "+Arrays.asList(file.getName().split(".")));
		String extension = getFileExtension(file);
		boolean isType = false;
		boolean isFunction = false;
		boolean isService = false;
		if (extension.equals("xml") && !key.equals("Acceptandbookblockservice.xml")) {
			TypeData typeData = new TypeData();
			typeData.setFileName(key);
			FunctionData functionData = new FunctionData();
			functionData.setFileName(key);
			ServiceData serviceData = new ServiceData();
			serviceData.setFileName(key);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;
			Document doc = null;
			try {
				dBuilder = dbFactory.newDocumentBuilder();
				doc = dBuilder.parse(file);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("FILE NAMEEEEEE" + file.getName());
				System.out.println("Error in 28 ReadXML");
			}
			if (doc != null)
				doc.getDocumentElement().normalize();
			String root = doc.getDocumentElement().getNodeName();
			// System.out.println(root);
			NodeList nL = doc.getElementsByTagName(root);
			// System.out.println("key : : : "+key);
			for (int i = 0; i < nL.getLength(); i++) { // Execute only one time
				Node node = nL.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					// System.out.println("*******element***********");
					// System.out.println(element.getNodeName());
					// System.out.println("******************");
					List<Element> elements = getElements(element);
					String type = null;
					for (Element innerElement : elements) {
						// System.out.println("___________innerElement_________");
						// System.out.println(innerElement.getNodeName());
						// System.out.println("____________________");
						List<Element> inElements = getElements(innerElement);
						Header header = new Header();
						if (innerElement.getNodeName().equals("header")) {
							HashMap<String, String> allElements = new HashMap<String, String>();
							for (Element inElement : inElements) {
								if (inElement.getNodeName().equals("category"))
									header.setCategory(inElement);
								else if (inElement.getNodeName().equals("type")) {
									header.setType(inElement);
									type = inElement.getTextContent();
									if (type.equals("type"))
										isType = true;
									else if (type.equals("function"))
										isFunction = true;
									else if (type.equals("service"))
										isService = true;
								} else if (inElement.getNodeName().equals("name")) {
									header.setName(inElement);
									// System.out.println("KEY of hasMap : :
									// "+key);
									key = inElement.getTextContent(); // name of
																		// the
																		// file
									// System.out.println("key : : "+key);
								} else if (inElement.getNodeName().equals("application"))
									header.setApplication(inElement);
								else if (inElement.getNodeName().equals("created"))
									header.setCreated(inElement);
								else if (inElement.getNodeName().equals("author"))
									header.setAuthor(inElement);
								else if (inElement.getNodeName().equals("description"))
									header.setDescription(inElement);
								else if (inElement.getNodeName().equals("soapTag"))
									header.setSoapTag(inElement);
								else if (inElement.getNodeName().equals("tapClassName"))
									header.setTapClassName(inElement);
								// System.out.println(inElement.getNodeName() +
								// " = \"" + inElement.getTextContent() + "\"");
								allElements.put(inElement.getNodeName(), inElement.getTextContent());
							}
							header.setAllElements(allElements);
							// System.out.println("_ _ _
							// "+header.getType().getTextContent());
							// System.out.println("______________________");
							// System.out.println(header.getAllAttributes());
							// System.out.println("_______________________");
							if (isType)
								typeData.setHeader(header);
							else if (isFunction)
								functionData.setHeader(header);
							else
								serviceData.setHeader(header);
							hashMap.put(key, header);
						} else // GOes for item
						if (innerElement.getNodeName().equals("items")) {
							// List<ItemBase> typeItemList=new
							// ArrayList<ItemBase>();
							List<ItemBase> itemList = new ArrayList<ItemBase>();
							int size = 0;
							for (Element inElement : inElements) {
								int totalSize = 0;
								ItemBase item = new ItemBase();
								item.setName(inElement.getAttribute("name"));
								item.setType(inElement.getAttribute("type"));
								item.setSize(inElement.getAttribute("size"));
								item.setRequired(inElement.getAttribute("required"));
								item.setNillable(inElement.getAttribute("nillable"));
								item.setAttribute(inElement.getAttribute("attribute"));
								item.setDescription(inElement.getAttribute("description"));
								item.setFormat(inElement.getAttribute("format"));
								item.setPrecision(inElement.getAttribute("precision"));
								item.setMaxOccurs((inElement.getAttribute("maxOccurs")));
								item.setFormat(inElement.getAttribute("format"));
								HashMap<String, String> allAttributes = new HashMap<String, String>();
								NamedNodeMap named = inElement.getAttributes();
								for (int k = 0; k < named.getLength(); k++) {
									Node attr = named.item(k);
									// System.out.println(attr.getNodeName() + "
									// = \"" + attr.getNodeValue() + "\"");
									allAttributes.put(attr.getNodeName(), attr.getNodeValue());
								}
								item.setAllAttributes(allAttributes);
								// System.out.println(inElement.getAttribute("name"));
								if (item.getSize().length() > 0) {
									if (item.getFormat().length() > 0) {
										totalSize = item.getFormat().length();
									} else if (item.getPrecision().length() > 0) {
										totalSize = Integer.parseInt(item.getSize())
												+ Integer.parseInt(item.getPrecision()) + 1;
									} else
										totalSize = Integer.parseInt(item.getSize());
								}
								size = size + totalSize;
								item.setTotalSize(totalSize + "");
								itemList.add(item);
								//System.out.println("NAME :  :" + item.getName());
								//System.out.println("size : : " + item.getTotalSize());
								// typeItemList.add(item);
							}
							typeData.setItemList(itemList);
							//System.out.println("TOTOAL SIze: : " + size);
							typeData.setSize(size);
							// typeData.setHeader(header);
						} else // Fetching Input Items
						if (innerElement.getNodeName().equals("inputs") && type.equals("function")) {
							String minOccurs = innerElement.getAttribute("minOccurs");
							minOccurs = minOccurs.replace("*", "N");
							String maxOccurs = innerElement.getAttribute("maxOccurs");
							maxOccurs = maxOccurs.replace("*", "N");
							// System.out.println("OCCURS : :
							// "+minOccurs+".."+maxOccurs);
							// key = inElement.getTextContent();
							List<ItemBase> itemList = new ArrayList<ItemBase>();
							// System.out.println("Key : : :"+key);
							for (Element inElement : inElements) {
								ItemBase item = new ItemBase();
								item.setName(inElement.getAttribute("name"));
								item.setType(inElement.getAttribute("type"));
								item.setSize(inElement.getAttribute("size"));
								item.setRequired(inElement.getAttribute("required"));
								item.setNillable(inElement.getAttribute("nillable"));
								item.setAttribute(inElement.getAttribute("attribute"));
								item.setDescription(inElement.getAttribute("description"));
								item.setPrecision(inElement.getAttribute("precision"));
								item.setMaxOccurs((inElement.getAttribute("maxOccurs")));
								item.setFormat(inElement.getAttribute("format"));
								// System.out.println(inElement.getAttribute("name"));
								HashMap<String, String> allAttributes = new HashMap<String, String>();
								NamedNodeMap named = inElement.getAttributes();
								for (int k = 0; k < named.getLength(); k++) {
									Node attr = named.item(k);
									// System.out.println(attr.getNodeName() + "
									// = \"" + attr.getNodeValue() + "\"");
									allAttributes.put(attr.getNodeName(), attr.getNodeValue());
								}
								item.setAllAttributes(allAttributes);
								// System.out.println(inElement.getAttribute("name"));
								itemList.add(item);
							}
							functionInputMap.put(key, itemList);
							functionData.setInputItemList(itemList);
							functionData.setInputOccurs(minOccurs + ".." + maxOccurs);
							// System.out.println(itemList);
							// System.out.println("++++++++++++++++++++++++++++++");
						}
						// //Fetching Input Items -End
						else // FetchingOutputItems
						if (innerElement.getNodeName().equals("outputs") && type.equals("function")) {
							String minOccurs = innerElement.getAttribute("minOccurs");
							minOccurs = minOccurs.replace("*", "N");
							String maxOccurs = innerElement.getAttribute("maxOccurs");
							maxOccurs = maxOccurs.replace("*", "N");
							// key = inElement.getTextContent();
							List<ItemBase> outputItemList = new ArrayList<ItemBase>();
							// System.out.println("Key : : :"+key);
							for (Element inElement : inElements) {
								ItemBase item = new ItemBase();
								item.setName(inElement.getAttribute("name"));
								item.setType(inElement.getAttribute("type"));
								item.setSize(inElement.getAttribute("size"));
								item.setRequired(inElement.getAttribute("required"));
								item.setNillable(inElement.getAttribute("nillable"));
								item.setAttribute(inElement.getAttribute("attribute"));
								item.setDescription(inElement.getAttribute("description"));
								item.setPrecision(inElement.getAttribute("precision"));
								item.setMaxOccurs((inElement.getAttribute("maxOccurs")));
								item.setFormat(inElement.getAttribute("format"));
								// System.out.println(inElement.getAttribute("name"));
								HashMap<String, String> allAttributes = new HashMap<String, String>();
								NamedNodeMap named = inElement.getAttributes();
								for (int k = 0; k < named.getLength(); k++) {
									Node attr = named.item(k);
									// System.out.println(attr.getNodeName() + "
									// = \"" + attr.getNodeValue() + "\"");
									allAttributes.put(attr.getNodeName(), attr.getNodeValue());
								}
								item.setAllAttributes(allAttributes);
								// System.out.println(inElement.getAttribute("name"));
								outputItemList.add(item);
							}
							functionData.setOutputItemList(outputItemList);
							functionData.setOutputOccurs(minOccurs + ".." + maxOccurs);
							functionOutputMap.put(key, outputItemList);
							// System.out.println(itemList);
							// System.out.println("++++++++++++++++++++++++++++++");
						} else if (innerElement.getNodeName().equals("inputs") && type.equals("service")) {
							// key = inElement.getTextContent();
							List<ItemBase> itemList = new ArrayList<ItemBase>();
							// System.out.println("Key : : :"+key);
							for (Element inElement : inElements) {
								ItemBase item = new ItemBase();
								item.setName(inElement.getAttribute("name"));
								item.setType(inElement.getAttribute("type"));
								item.setSize(inElement.getAttribute("size"));
								item.setRequired(inElement.getAttribute("required"));
								item.setNillable(inElement.getAttribute("nillable"));
								item.setAttribute(inElement.getAttribute("attribute"));
								item.setDescription(inElement.getAttribute("description"));
								item.setFormat(inElement.getAttribute("format"));
								HashMap<String, String> allAttributes = new HashMap<String, String>();
								NamedNodeMap named = inElement.getAttributes();
								for (int k = 0; k < named.getLength(); k++) {
									Node attr = named.item(k);
									// System.out.println(attr.getNodeName() + "
									// = \"" + attr.getNodeValue() + "\"");
									allAttributes.put(attr.getNodeName(), attr.getNodeValue());
								}
								item.setAllAttributes(allAttributes);
								// System.out.println(inElement.getAttribute("name"));
								itemList.add(item);
							}
							serviceInputMap.put(key, itemList);
							serviceData.setInputItemList(itemList);
							// System.out.println(itemList);
							// System.out.println("++++++++++++++++++++++++++++++");
						} else if (innerElement.getNodeName().equals("outputs") && type.equals("service")) {
							List<ItemBase> outputItemList = new ArrayList<ItemBase>();
							// key = inElement.getTextContent();
							// System.out.println("Key : : :"+key);
							for (Element inElement : inElements) {
								ItemBase item = new ItemBase();
								item.setName(inElement.getAttribute("name"));
								item.setType(inElement.getAttribute("type"));
								item.setSize(inElement.getAttribute("size"));
								item.setRequired(inElement.getAttribute("required"));
								item.setNillable(inElement.getAttribute("nillable"));
								item.setAttribute(inElement.getAttribute("attribute"));
								item.setDescription(inElement.getAttribute("description"));
								item.setFormat(inElement.getAttribute("format"));
								// System.out.println(inElement.getAttribute("name"));
								HashMap<String, String> allAttributes = new HashMap<String, String>();
								NamedNodeMap named = inElement.getAttributes();
								for (int k = 0; k < named.getLength(); k++) {
									Node attr = named.item(k);
									// System.out.println(attr.getNodeName() + "
									// = \"" + attr.getNodeValue() + "\"");
									allAttributes.put(attr.getNodeName(), attr.getNodeValue());
								}
								item.setAllAttributes(allAttributes);
								outputItemList.add(item);
							}
							serviceOutputMap.put(key, outputItemList);
							serviceData.setOutputItemList(outputItemList);
							// System.out.println(itemList);
							// System.out.println("++++++++++++++++++++++++++++++");
						}
					} // End
					if (isType) {
						typeMap.put(key, typeData);
						// System.out.println(typeMap);
					} else if (isFunction) {
						functionMap.put(key, functionData);
						// System.out.println(functionMap);
					} else if (isService)
						serviceMap.put(key, serviceData);
				}
			}
			if (typeMap.isEmpty()) {
				typeMap = null;
			}
			if (functionMap.isEmpty())
				functionMap = null;
			if (serviceMap.isEmpty())
				serviceMap = null;
			if (functionInputMap.isEmpty()) {
				functionInputMap = null;
			}
			if (functionOutputMap.isEmpty()) {
				functionOutputMap = null;
			}
			if (serviceInputMap.isEmpty()) {
				serviceInputMap = null;
			}
			if (serviceOutputMap.isEmpty()) {
				serviceOutputMap = null;
			}
			MapBean.setTypeMap(typeMap);
			MapBean.setFunctionMap(functionMap);
			MapBean.setServiceMap(serviceMap);
			return hashMap;
		}
		return null;
	}

	public static void readStructures() {
		File typesFile = new File("src/Resources/MetaData/xmllinkStructures.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(typesFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println("Root element :" +
		// doc.getDocumentElement().getNodeName());
		NodeList nL = doc.getElementsByTagName(root);
		HashMap<String, StructureData> structureMap = new HashMap<String, StructureData>();
		for (int i = 0; i < nL.getLength(); i++) {
			// System.out.println(i);
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				for (Element innerElement : getElements(element)) {
					for (Element type : getElements(innerElement)) {
						String key = type.getAttribute("id");
						// System.out.println("***********key*"+key);
						List<Element> inElements = getElements(type);
						StructureData data = new StructureData();
						for (Element typeElement : inElements) {
							// System.out.println("************"+typeElement.getNodeName());
							if (typeElement.getNodeName().equals("header")) {
								List<Element> innerTypeElements = getElements(typeElement);
								List<StructureItem> structureItemList = new ArrayList<StructureItem>();
								for (Element inElement : innerTypeElements) {
									StructureItem structureItem = new StructureItem();
									// System.out.println(inElement.getNodeName());
									structureItem.setId(inElement.getAttribute("id"));
									structureItem.setLabel(inElement.getAttribute("label"));
									structureItem.setListSubItem(inElement.getAttribute("listSubItem"));
									structureItem.setRequired(inElement.getAttribute("required"));
									structureItem.setState(inElement.getAttribute("state"));
									structureItem.setTag(inElement.getAttribute("tag"));
									structureItem.setType(inElement.getAttribute("type"));
									structureItem.setValidChars(inElement.getAttribute("validChars"));
									structureItem.setValue(new TextField(""));
									// System.out.println(structureItem.getId());
									structureItemList.add(structureItem);
								}
								data.setHeaderList(structureItemList);
							} else if (typeElement.getNodeName().equals("detail")) {
								List<Element> innerTypeElements = getElements(typeElement);
								List<StructureItem> structureItemList = new ArrayList<StructureItem>();
								for (Element inElement : innerTypeElements) {
									StructureItem structureItem = new StructureItem();
									// System.out.println(inElement.getNodeName());
									structureItem.setId(inElement.getAttribute("id"));
									structureItem.setLabel(inElement.getAttribute("label"));
									structureItem.setListSubItem(inElement.getAttribute("listSubItem"));
									structureItem.setRequired(inElement.getAttribute("required"));
									structureItem.setState(inElement.getAttribute("state"));
									structureItem.setTag(inElement.getAttribute("tag"));
									structureItem.setType(inElement.getAttribute("type"));
									structureItem.setValidChars(inElement.getAttribute("validChars"));
									structureItem.setValue(new TextField(""));
									// System.out.println(structureItem.getId());
									structureItemList.add(structureItem);
								}
								data.setDetailList(structureItemList);
							}
						}
						// System.out.println("Am DATA
						// Header"+data.getHeaderList());
						// System.out.println("Am details :
						// :"+data.getDetailList());
						structureMap.put(key, data);
					}
				}
			}
		} // End of loop
		MapBean.setStructureMap(structureMap);
	}

	/// REading DataTypes
	public static void readTypes() throws ParserConfigurationException, SAXException, IOException {
		// System.out.println("Reading TYpes....");
		File typesFile = new File("src/Resources/MetaData/xmllinkTypes.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(typesFile);
		doc.getDocumentElement().normalize();
		String root = doc.getDocumentElement().getNodeName();
		// System.out.println("Root element :" +
		// doc.getDocumentElement().getNodeName());
		NodeList nL = doc.getElementsByTagName("item");
		// System.out.println(nL.getLength());
		HashMap<String, HashMap<String, Element>> dataTypeMap = new HashMap<String, HashMap<String, Element>>();
		for (int i = 0; i < nL.getLength(); i++) {
			Node node = nL.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE
					&& !node.getParentNode().getNodeName().toString().equals("format")
					&& !node.getParentNode().getNodeName().toString().equals("plheader")) {
				// System.out.println(node.getParentNode().getNodeName());
				Element element = (Element) node;
				List<Element> dddd = getElements(element);
				// System.out.println("****************************");
				String key = element.getAttribute("id");
				// System.out.println(key);
				HashMap<String, Element> dataElementMap = new HashMap<String, Element>();
				// List<Element> dataTypeList = new ArrayList<Element>();
				for (Element ele : dddd) {
					dataElementMap.put(ele.getNodeName(), ele);
					// dataTypeList.add(ele);
					// System.out.println("ELEmenet : : "+ele.getNodeName());
				}
				dataTypeMap.put(key, dataElementMap); // Map
														// contains(DataTypeName,Elements)
				// List<Element> dd = getInnerElements("format", element);
				/*
				 * for (Element ele : dd) {
				 * System.out.println("Inner: : :"+ele.getNodeName()); }
				 */
			}
		}
		MapBean.setDataTypeMap(dataTypeMap);
	}

	public static List<Element> getElements(Element element) {
		List<Element> elementList = new ArrayList<Element>();
		NodeList inner = element.getChildNodes();
		// List dd1=getInnerElements("item", element);
		for (int k = 0; k < inner.getLength(); k++) {
			Node n = inner.item(k);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				Element innerEle = (Element) n;
				elementList.add(innerEle);
				// System.out.println(innerEle.getNodeName());
			}
		}
		return elementList;
	}

	private static List<Element> getInnerElements(String tag, Element element) {
		List<Element> elementList = new ArrayList<Element>();
		// System.out.println(element.getNodeName());
		NodeList subList = (NodeList) element.getElementsByTagName(tag);
		// System.out.println(subList.getLength());
		for (int j = 0; j < subList.getLength(); j++) {
			Node n = subList.item(j);
			if (n.getNodeType() == Node.ELEMENT_NODE) {
				NodeList nsub = n.getChildNodes();
				// System.out.println(nsub.getLength());
				for (int k = 0; k < nsub.getLength(); k++) {
					Node n1 = nsub.item(k);
					if (n1.getNodeType() == Node.ELEMENT_NODE) {
						Element innerEle = (Element) n1;
						elementList.add(innerEle);
						// System.out.println("*****" + innerEle.getNodeName());
					}
				}
			}
		}
		return elementList;
	}

	public static String getValue(String tag, Element element) {
		NodeList nodes = element.getElementsByTagName(tag).item(0).getChildNodes();
		Node node = (Node) nodes.item(0);
		return node.getNodeValue();
	}

	public static String getFileExtension(File file) {
		String name = file.getName();
		try {
			return name.substring(name.lastIndexOf(".") + 1);
		} catch (Exception e) {
			return "";
		}
	}

	private static String stripExtension(String str) {
		if (str == null)
			return null;
		int pos = str.lastIndexOf(".");
		if (pos == -1)
			return str;
		return str.substring(0, pos);
	}
}