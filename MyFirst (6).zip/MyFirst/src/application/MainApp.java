package application;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.sun.javafx.application.LauncherImpl;
import javafx.application.Application;
import javafx.application.Preloader;
import javafx.application.Preloader.ProgressNotification;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.stage.Stage;
import xml.ReadXML;


/**
* Beginning of the Application
* This will initiate the Structure Construction of existing Packages According to the xmllinkApplications.xml 
* Inbuilt Data Types to maintain are constructed using the xmllinktypes.xml 
* 
* 
* 
* @author VJanarthanan
*/
public class MainApp extends Application {
	public static Stage stage;
	public static Boolean start = false;
	Image icon = new Image(getClass().getResourceAsStream("/Resources/2.png"), 75, 75, false, false);
	public static Stage getStage() {
		return stage;
	}
	public static void setStage(Stage stage) {
		MainApp.stage = stage;
	}
	public static double percent = 0;
	public static String progress = "";
	public double getPercent() {
		return percent;
	}
	public void setPercent(double percent) {
		ProgressNotification pn = new ProgressNotification(percent);
		LauncherImpl.notifyPreloader(this, pn);
		MainApp.percent = percent;
	}
	@Override
	public void init() throws Exception { // 6
		// //System.out.println(MyApplication.STEP() + "MyApplication#init
		// (doing some heavy lifting), thread: " +
		// Thread.currentThread().getName());
		// System.out.println("BEFORE");
		MainController.sampleTree = new TreeView();
		MainController.constructStructure();
		readDataType();
		// System.out.println("AFTER");
	}
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/View/Base.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Message Explorer");
			primaryStage.getIcons().add(icon);
			primaryStage.setScene(scene);
			primaryStage.setMaximized(true);
			MainApp.setStage(primaryStage);
			// System.out.println("Going to show");
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		JFXPanel fxPanel = new JFXPanel();
		ReadXML.readStructures();
		readDataType();
		start = true;
		LauncherImpl.launchApplication(MainApp.class, MyPreloader.class, args);
	}
	private static void readDataType() {
		try {
			ReadXML.readTypes();
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
	}
}