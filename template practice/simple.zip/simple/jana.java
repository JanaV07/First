Hello World!  Welcome to Velocity!
3
 HashedMap hashmap=new HashedMap();
  HashedMap hashmap1=null;
   HashedMap hashmap2=null;
    HashedMap hashmap3=null;
ArrayList list=null;
hashmap1=new HashedMap();
 hashmap2=new HashedMap();
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("11",list);
11
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("12",list);
12
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("13",list);
13
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("14",list);
14
hashmap1.put("16",list);
16
 hashmap2=new HashedMap();
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("11",list);
11
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("12",list);
12
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("13",list);
13
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("14",list);
14
hashmap1.put("17",list);
17
 hashmap2=new HashedMap();
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("11",list);
11
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("12",list);
12
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("13",list);
13
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("14",list);
14
hashmap1.put("18",list);
18
hashmap.put("21",list);
21
hashmap1=new HashedMap();
 hashmap2=new HashedMap();
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("11",list);
11
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("12",list);
12
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("13",list);
13
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("14",list);
14
hashmap1.put("16",list);
16
 hashmap2=new HashedMap();
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("11",list);
11
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("12",list);
12
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("13",list);
13
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("14",list);
14
hashmap1.put("17",list);
17
 hashmap2=new HashedMap();
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("11",list);
11
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("12",list);
12
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("13",list);
13
 hashmap3=new HashedMap();
list=new ArrayList();
list.add(6 1)
list.add(6 2)
hashmap3.put("6",list);
6=[6 1, 6 2]
6

list=new ArrayList();
list.add(7 1)
list.add(7 2)
hashmap3.put("7",list);
7=[7 1, 7 2]
7

list=new ArrayList();
list.add(8 1)
list.add(8 2)
hashmap3.put("8",list);
8=[8 1, 8 2]
8

hashmap2.put("14",list);
14
hashmap1.put("18",list);
18
hashmap.put("22",list);
22
hashmap1=new HashedMap();
hashmap.put("first",list);
first
